
'use client'
import { useState } from 'react'
import { Copy, Check, FileText, Zap, Code, Target, BarChart3, Users, Settings, Crown } from 'lucide-react'
import AuthHeader from '@/components/auth-header'

const promptCategories = [
  {
    id: 'specification-driven',
    title: 'Specification-Driven Prompting',
    icon: FileText,
    color: 'from-blue-500 to-indigo-500',
    description: 'Six-element framework for precise, professional results',
    templates: [
      {
        name: 'Complete 6-Element Template',
        description: 'Master template with all six specification elements',
        prompt: `[OBJECTIVE]: [Clearly state what you want to achieve]

[SCOPE]: [Define boundaries, what's included/excluded]

[DELIVERABLE]: [Specify exact format and content of output]

[CONSTRAINTS]: [List limitations, requirements, restrictions]

[CONTEXT]: [Provide background information and relevant details]

[SUCCESS CRITERIA]: [Define how to measure successful completion]

[YOUR SPECIFIC REQUEST HERE]`
      },
      {
        name: 'Business Strategy Template',
        description: 'Specification framework optimized for strategic planning',
        prompt: `OBJECTIVE: Develop comprehensive business strategy for [SITUATION]
SCOPE: [Time horizon], [Market segments], [Business units]
DELIVERABLE: Strategic plan document with executive summary, detailed strategy, financial projections, implementation roadmap
CONSTRAINTS: Budget of $[AMOUNT], timeline of [TIMEFRAME], regulatory requirements, competitive landscape
CONTEXT: [Company background], [Market conditions], [Current challenges], [Available resources]
SUCCESS CRITERIA: [Specific metrics], [Approval criteria], [Implementation milestones]

Analyze the situation and provide the complete strategic plan.`
      },
      {
        name: 'Problem-Solving Template',
        description: 'Systematic approach to complex business problems',
        prompt: `OBJECTIVE: Solve [SPECIFIC PROBLEM] and provide actionable solution
SCOPE: [Affected departments/processes], [Impact boundaries], [Stakeholder groups]
DELIVERABLE: Problem analysis, root cause identification, solution recommendations with implementation steps
CONSTRAINTS: [Time limitations], [Budget constraints], [Resource availability], [Organizational limitations]
CONTEXT: [Problem background], [Previous attempts], [Current impact], [Stakeholder perspectives]
SUCCESS CRITERIA: [Problem resolution metrics], [Success indicators], [Acceptance criteria]

Provide comprehensive problem analysis and solution strategy.`
      }
    ]
  },
  {
    id: 'think-hard',
    title: '"Think Hard" Activation',
    description: 'Unlock GPT-5\'s deepest reasoning for complex challenges',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500',
    templates: [
      {
        name: 'Crisis Management Template',
        description: 'For urgent, high-stakes business situations',
        prompt: `Think hard about this critical situation:

CRISIS: [Describe the urgent situation]
IMPACT: [Business/financial/operational impact]
TIMELINE: [How much time to resolve]
STAKEHOLDERS: [Who is affected/involved]
CONSTRAINTS: [Limitations and restrictions]
RISKS: [Potential consequences if not handled well]

I need comprehensive crisis management strategy including:
1. Immediate actions (next 24-48 hours)
2. Short-term stabilization plan
3. Long-term recovery strategy
4. Communication plan for stakeholders
5. Risk mitigation measures
6. Lessons learned and prevention

This is mission-critical - provide your most thorough analysis.`
      },
      {
        name: 'Strategic Decision Template',
        description: 'For complex decisions requiring deep analysis',
        prompt: `Think hard about this strategic decision:

DECISION: [What needs to be decided]
OPTIONS: [Available alternatives]
STAKES: [What's at risk/what can be gained]
TIMEFRAME: [Decision timeline]
STAKEHOLDERS: [Who is impacted by the decision]
UNKNOWNS: [Key uncertainties and information gaps]

Provide comprehensive analysis including:
- Thorough evaluation of each option
- Risk/benefit analysis with probabilities
- Scenario planning for different outcomes
- Stakeholder impact assessment
- Implementation considerations
- Recommendation with detailed reasoning

This decision will shape our future - give me your deepest insights.`
      },
      {
        name: 'Innovation Challenge Template',
        description: 'For breakthrough thinking and creative solutions',
        prompt: `Think hard about this innovation challenge:

CHALLENGE: [Innovation problem or opportunity]
CURRENT STATE: [What exists today]
DESIRED OUTCOME: [What success looks like]
CONSTRAINTS: [Technical, financial, market limitations]
PRECEDENTS: [What others have tried]
RESOURCES: [Available capabilities and assets]

I need breakthrough thinking that goes beyond conventional approaches:
1. Challenge fundamental assumptions
2. Explore unconventional solutions
3. Identify breakthrough opportunities
4. Consider system-level changes
5. Propose novel approaches
6. Assess feasibility and impact

Push the boundaries of conventional thinking - what's truly possible?`
      }
    ]
  },
  {
    id: 'canvas-integration',
    title: 'Canvas + Memory Integration',
    description: 'Build persistent, evolving knowledge systems',
    icon: Code,
    color: 'from-green-500 to-teal-500',
    templates: [
      {
        name: 'Knowledge Base Creation',
        description: 'Create persistent knowledge systems that grow over time',
        prompt: `Create a Canvas document for [KNOWLEDGE DOMAIN]:

TITLE: [Descriptive title for the knowledge base]
PURPOSE: [What this knowledge base will accomplish]
SCOPE: [What topics/areas it will cover]
UPDATE FREQUENCY: [How often it should be refreshed]

Please create sections for:
1. [Section 1 - Key concepts and definitions]
2. [Section 2 - Current state analysis]
3. [Section 3 - Trends and developments]
4. [Section 4 - Best practices and lessons learned]
5. [Section 5 - Action items and next steps]
6. [Section 6 - Resources and references]

MEMORY INTEGRATION:
- Use Memory to recall related discussions from previous sessions
- Update this Canvas whenever new relevant information is shared
- Make this a living document that evolves with new insights
- Include confidence levels and source attribution

Initialize with: [Starting information or recent developments]`
      },
      {
        name: 'Project Management Canvas',
        description: 'Persistent project tracking and evolution',
        prompt: `Create a Canvas for project: "[PROJECT NAME]"

PROJECT OVERVIEW:
- Objective: [Project goals]
- Timeline: [Start and end dates]
- Budget: [Financial constraints]
- Stakeholders: [Key people involved]

Canvas Sections:
1. Project Charter & Objectives
2. Current Status & Progress
3. Key Milestones & Timeline
4. Risk Register & Mitigation
5. Resource Allocation & Budget
6. Stakeholder Communication
7. Lessons Learned & Adaptations
8. Next Actions & Decisions

MEMORY INSTRUCTIONS:
- Remember all project discussions and decisions
- Update status automatically based on our conversations
- Track changes and evolution over time
- Alert me to potential issues based on historical patterns

Start with current project status: [Current situation]`
      }
    ]
  },
  {
    id: 'artifact-driven',
    title: 'Artifact-Driven Prompting',
    description: 'Demand tangible deliverables with proof of work',
    icon: Target,
    color: 'from-purple-500 to-pink-500',
    templates: [
      {
        name: 'Comprehensive Analysis Template',
        description: 'Request complete analysis with multiple deliverables',
        prompt: `I need comprehensive analysis on [TOPIC] with complete artifacts:

ANALYSIS SCOPE: [What needs to be analyzed]
BUSINESS CONTEXT: [Why this analysis is needed]
TIMELINE: [When results are needed]
AUDIENCE: [Who will use these results]

REQUIRED ARTIFACTS:
1. Executive Summary (2-page overview)
2. Detailed Analysis Report (15-20 pages)
3. Data Visualization Dashboard
4. Financial Impact Model (Excel/spreadsheet)
5. Risk Assessment Matrix
6. Implementation Roadmap
7. Success Metrics Framework
8. Stakeholder Communication Plan
9. Resource Requirements Summary
10. Appendices with supporting data

Each artifact must be:
- Immediately usable and professional quality
- Data-driven with sources and methodology
- Executive-presentation ready
- Customizable for different scenarios
- Include confidence levels and assumptions

Provide complete, actionable deliverables that demonstrate thorough analysis.`
      },
      {
        name: 'Strategic Planning Artifacts',
        description: 'Complete strategic planning deliverable package',
        prompt: `Create comprehensive strategic planning package for [INITIATIVE]:

STRATEGIC CONTEXT: [Business situation and opportunity]
PLANNING HORIZON: [Time period being planned]
INVESTMENT LEVEL: [Available resources]
SUCCESS DEFINITION: [What victory looks like]

DELIVERABLE ARTIFACTS:
1. Strategic Vision & Mission Statement
2. Market Analysis & Competitive Landscape
3. SWOT Analysis with Strategic Implications  
4. Strategic Objectives & Key Results (OKRs)
5. Initiative Portfolio & Prioritization
6. Resource Allocation & Budget Plan
7. Implementation Timeline with Milestones
8. Risk Management & Contingency Plans
9. Performance Metrics & KPI Dashboard
10. Communication & Change Management Plan

QUALITY STANDARDS:
- Board-presentation ready
- Actionable with specific next steps
- Quantified wherever possible
- Risk-assessed with mitigation strategies
- Aligned with organizational capabilities

Deliver complete strategic planning suite that can be immediately implemented.`
      }
    ]
  },
  {
    id: 'business-roles',
    title: 'Business Role Templates',
    description: 'Specialized prompts for different business functions',
    icon: Users,
    color: 'from-indigo-500 to-purple-500',
    templates: [
      {
        name: 'Marketing Executive Template',
        description: 'Strategic marketing analysis and planning',
        prompt: `As a seasoned Marketing Executive, analyze [MARKETING CHALLENGE]:

MARKET CONTEXT: [Industry, competitive landscape, customer segments]
BUSINESS GOALS: [Revenue targets, growth objectives, brand goals]
CURRENT SITUATION: [Marketing performance, channels, team capabilities]
CONSTRAINTS: [Budget limitations, timeline, regulatory requirements]

Provide executive-level marketing strategy including:
1. Market opportunity assessment with TAM/SAM/SOM
2. Customer segmentation and persona development
3. Competitive positioning and differentiation strategy
4. Multi-channel marketing mix with budget allocation
5. Customer acquisition and retention strategies
6. Brand positioning and messaging framework
7. Marketing technology stack recommendations
8. Performance metrics and ROI measurement
9. Team structure and capability requirements
10. Implementation roadmap with quick wins

Focus on strategies that drive measurable business growth and competitive advantage.`
      },
      {
        name: 'Sales Leader Template',
        description: 'Sales strategy and performance optimization',
        prompt: `As an experienced Sales Leader, develop strategy for [SALES CHALLENGE]:

SALES CONTEXT: [Market size, deal types, sales cycle, competition]
PERFORMANCE GAPS: [Current vs. target performance, specific issues]
TEAM SITUATION: [Sales team size, experience, territories, tools]
BUSINESS PRESSURE: [Revenue targets, timeline, stakeholder expectations]

Provide comprehensive sales strategy covering:
1. Sales process optimization and methodology
2. Territory planning and coverage model
3. Lead generation and pipeline development
4. Sales enablement and training programs
5. Compensation and incentive structure
6. Sales technology and CRM optimization
7. Performance management and coaching
8. Competitive positioning and battle cards
9. Customer success and expansion strategies
10. Sales forecasting and pipeline management

Emphasize strategies that accelerate revenue growth and improve win rates.`
      },
      {
        name: 'Operations Executive Template',
        description: 'Operational efficiency and process optimization',
        prompt: `As a senior Operations Executive, optimize [OPERATIONAL CHALLENGE]:

OPERATIONAL CONTEXT: [Current processes, systems, team structure, performance metrics]
EFFICIENCY GAPS: [Where operations are falling short, bottlenecks, waste areas]
RESOURCE CONSTRAINTS: [Budget, staffing, technology, time limitations]
BUSINESS IMPACT: [How operational issues affect business performance]

Develop comprehensive operational strategy including:
1. Process mapping and optimization opportunities
2. Technology and automation recommendations
3. Resource allocation and capacity planning
4. Quality management and continuous improvement
5. Supply chain and vendor management optimization
6. Performance metrics and KPI framework
7. Change management and team development
8. Risk management and business continuity
9. Cost optimization and efficiency gains
10. Scaling strategies for growth

Focus on solutions that improve efficiency, reduce costs, and enable scalable growth.`
      }
    ]
  },
  {
    id: 'advanced-techniques',
    title: 'Advanced GPT-5 Techniques',
    description: 'Cutting-edge prompting strategies for power users',
    icon: Settings,
    color: 'from-red-500 to-orange-500',
    templates: [
      {
        name: 'Multi-Perspective Analysis',
        description: 'Get multiple expert viewpoints simultaneously',
        prompt: `I need multiple expert perspectives on [COMPLEX ISSUE]:

SITUATION: [Describe the complex situation or decision]
STAKEHOLDERS: [Who is affected or involved]
IMPLICATIONS: [Why this matters and potential impacts]
CONSTRAINTS: [Limitations and requirements]

Please provide analysis from these expert perspectives:
1. [Expert Type 1] - Focus on [their primary concerns]
2. [Expert Type 2] - Focus on [their primary concerns]  
3. [Expert Type 3] - Focus on [their primary concerns]
4. [Expert Type 4] - Focus on [their primary concerns]
5. [Expert Type 5] - Focus on [their primary concerns]

For each perspective, provide:
- Their primary concerns and priorities
- Their analysis of the situation
- Their recommended approach
- Risks they would highlight
- Success metrics they would use

Conclude with synthesis of insights and integrated recommendations.`
      },
      {
        name: 'Scenario Planning Template',
        description: 'Comprehensive future scenario analysis',
        prompt: `Develop scenario planning analysis for [STRATEGIC SITUATION]:

BASE CASE ASSUMPTIONS: [Current trajectory and likely outcomes]
KEY UNCERTAINTIES: [Major variables that could change]
TIME HORIZON: [Planning period]
DECISION CONTEXT: [What decisions this will inform]

Create four scenarios:

SCENARIO 1: Optimistic Case
- Key assumptions: [Best-case variables]
- Probability: [Estimated likelihood]
- Implications: [What this means for business]
- Strategic responses: [How to capitalize]

SCENARIO 2: Pessimistic Case  
- Key assumptions: [Worst-case variables]
- Probability: [Estimated likelihood]
- Implications: [Risks and challenges]
- Strategic responses: [How to mitigate]

SCENARIO 3: Wild Card Case
- Key assumptions: [Unexpected disruptions]
- Probability: [Estimated likelihood] 
- Implications: [Game-changing impacts]
- Strategic responses: [How to adapt]

SCENARIO 4: Status Quo Plus
- Key assumptions: [Incremental changes]
- Probability: [Estimated likelihood]
- Implications: [Gradual evolution]
- Strategic responses: [How to stay competitive]

Provide strategic recommendations that work across multiple scenarios.`
      }
    ]
  }
]

export default function PromptTemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState('specification-driven')
  const [selectedTemplate, setSelectedTemplate] = useState(0)
  const [copiedTemplate, setCopiedTemplate] = useState<string | null>(null)

  const currentCategory = promptCategories.find(cat => cat.id === selectedCategory)!
  const currentTemplate = currentCategory.templates[selectedTemplate]

  const copyToClipboard = (text: string, templateName: string) => {
    navigator.clipboard.writeText(text)
    setCopiedTemplate(templateName)
    setTimeout(() => setCopiedTemplate(null), 2000)
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        <AuthHeader />
        
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">Universal Prompt Templates</h1>
          <p className="text-xl text-gray-300">Master GPT-5 with proven prompt frameworks and templates</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Category Selection */}
          <div className="lg:col-span-1">
            <h3 className="text-xl font-semibold text-white mb-4">Template Categories</h3>
            <div className="space-y-2">
              {promptCategories.map((category) => {
                const IconComponent = category.icon
                return (
                  <button
                    key={category.id}
                    onClick={() => {
                      setSelectedCategory(category.id)
                      setSelectedTemplate(0)
                    }}
                    className={`w-full text-left p-4 rounded-lg transition-all ${
                      selectedCategory === category.id 
                        ? `bg-gradient-to-r ${category.color} text-white shadow-lg` 
                        : 'bg-white/10 text-gray-300 hover:bg-white/15'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <IconComponent className="h-6 w-6 mt-1 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-sm">{category.title}</div>
                        <div className="text-xs opacity-90 mt-1">{category.description}</div>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Template Content */}
          <div className="lg:col-span-3">
            <div className="bg-white/5 rounded-lg p-6">
              {/* Category Header */}
              <div className="flex items-center space-x-3 mb-6">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${currentCategory.color}`}>
                  <currentCategory.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{currentCategory.title}</h2>
                  <p className="text-gray-400">{currentCategory.description}</p>
                </div>
              </div>

              {/* Template Tabs */}
              <div className="flex flex-wrap gap-2 mb-6">
                {currentCategory.templates.map((template, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedTemplate(index)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      selectedTemplate === index
                        ? 'bg-orange-500 text-white'
                        : 'bg-white/10 text-gray-300 hover:bg-white/15'
                    }`}
                  >
                    {template.name}
                  </button>
                ))}
              </div>

              {/* Template Details */}
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-semibold text-white">{currentTemplate.name}</h3>
                    <button
                      onClick={() => copyToClipboard(currentTemplate.prompt, currentTemplate.name)}
                      className="flex items-center space-x-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors"
                    >
                      {copiedTemplate === currentTemplate.name ? (
                        <Check className="h-4 w-4 text-white" />
                      ) : (
                        <Copy className="h-4 w-4 text-white" />
                      )}
                      <span className="text-white text-sm">
                        {copiedTemplate === currentTemplate.name ? 'Copied!' : 'Copy Template'}
                      </span>
                    </button>
                  </div>
                  <p className="text-gray-300 mb-4">{currentTemplate.description}</p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-orange-300 mb-3">Template</h4>
                  <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
                    <pre className="text-gray-200 text-sm whitespace-pre-wrap font-mono">
                      {currentTemplate.prompt}
                    </pre>
                  </div>
                </div>

                <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Target className="h-5 w-5 text-blue-400 mt-1" />
                    <div>
                      <div className="font-semibold text-blue-300 mb-1">Usage Tips</div>
                      <div className="text-blue-200 text-sm">
                        {selectedCategory === 'specification-driven' && 
                          'Replace bracketed placeholders with your specific requirements. The six-element structure ensures comprehensive, professional results.'}
                        {selectedCategory === 'think-hard' && 
                          'Use for complex, high-stakes situations requiring deep analysis. The "Think hard" activation unlocks GPT-5\'s most sophisticated reasoning.'}
                        {selectedCategory === 'canvas-integration' && 
                          'These templates create persistent documents that evolve over time. Perfect for ongoing projects and knowledge management.'}
                        {selectedCategory === 'artifact-driven' && 
                          'Demand specific deliverables and proof of work. Results in comprehensive analysis packages ready for executive presentation.'}
                        {selectedCategory === 'business-roles' && 
                          'Tailored for specific business functions. Use the role-specific lens to get targeted, actionable recommendations.'}
                        {selectedCategory === 'advanced-techniques' && 
                          'Power user techniques for complex analysis. Combine multiple approaches for comprehensive strategic insights.'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-16 pt-8 border-t border-gray-700">
          <p className="text-xs text-gray-400">© 2025 Growth Partner Pros. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  )
}
