

import Link from 'next/link';
import { BookOpen, Presentation, FileText, Lightbulb, Play, Library, Users, ArrowRight } from 'lucide-react';
import AuthHeader from '@/components/auth-header';

export default function HomePage() {
  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        <AuthHeader />
        {/* Header */}
        <div className="text-center mb-16">
          <div className="mb-6">
            <h1 className="text-6xl font-bold text-white mb-4">GPT-5 Executive Mastery Course</h1>
            <p className="text-3xl text-orange-300 font-semibold mb-2">Advanced Capabilities for Business Leaders</p>
            <p className="text-xl text-gray-300">Comprehensive Learning Platform</p>
          </div>
          
          <div className="bg-gradient-to-r from-orange-500/20 to-teal-500/20 rounded-lg p-6 max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-white mb-3">Leap Ahead of 99% of ChatGPT Users</h2>
            <p className="text-xl text-gray-200">Master advanced techniques, build business applications, and lead AI transformation</p>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Presentation Access */}
          <Link href="/pages/1?total=25" className="group">
            <div className="bg-gradient-to-br from-orange-500/10 to-orange-600/20 hover:from-orange-500/20 hover:to-orange-600/30 border border-orange-500/30 rounded-lg p-8 h-full transition-all duration-300 hover:shadow-2xl">
              <div className="flex items-center mb-6">
                <div className="bg-orange-500 p-3 rounded-lg mr-4">
                  <Presentation className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-white mb-2">Course Presentation</h3>
                  <p className="text-lg text-gray-300">25 Interactive Slides</p>
                </div>
              </div>
              <p className="text-gray-200 mb-4">Access the live presentation slides with facilitator guides, timing information, and interactive content for the complete 13-hour course experience.</p>
              <div className="flex items-center text-orange-300 group-hover:text-orange-200 transition-colors">
                <span className="font-semibold">Start Presentation</span>
                <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>

          {/* Participant Resources */}
          <Link href="/resources" className="group">
            <div className="bg-gradient-to-br from-teal-500/10 to-teal-600/20 hover:from-teal-500/20 hover:to-teal-600/30 border border-teal-500/30 rounded-lg p-8 h-full transition-all duration-300 hover:shadow-2xl">
              <div className="flex items-center mb-6">
                <div className="bg-teal-500 p-3 rounded-lg mr-4">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-white mb-2">Participant Resources</h3>
                  <p className="text-lg text-gray-300">Comprehensive Materials</p>
                </div>
              </div>
              <p className="text-gray-200 mb-4">Complete guidebook, ready-to-use prompts, worksheets, examples, and reference materials for mastering GPT-5 advanced techniques.</p>
              <div className="flex items-center text-teal-300 group-hover:text-teal-200 transition-colors">
                <span className="font-semibold">Access Resources</span>
                <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>
        </div>

        {/* Quick Access Menu */}
        <div className="border-t border-gray-600 pt-12">
          <h2 className="text-3xl font-bold text-center text-white mb-10">Complete Resource Library</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            <Link href="/guidebook" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-blue-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">Participant Guidebook</span>
            </Link>

            <Link href="/prompt-templates" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-green-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">Prompt Templates</span>
            </Link>

            <Link href="/use-cases" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-purple-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <Users className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">Business Use Cases</span>
            </Link>

            <Link href="/wow-demos" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-red-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <Play className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">WOW Demos</span>
            </Link>

            <Link href="/exercises" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-yellow-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <Lightbulb className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">Exercises & Worksheets</span>
            </Link>

            <Link href="/reference" className="group flex flex-col items-center p-4 rounded-lg hover:bg-white/5 transition-colors">
              <div className="bg-indigo-500 p-3 rounded-lg mb-3 group-hover:scale-110 transition-transform">
                <Library className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-medium text-center">Resource Library</span>
            </Link>
          </div>
        </div>

        {/* Course Overview */}
        <div className="mt-16 bg-white/5 rounded-lg p-8">
          <h2 className="text-3xl font-bold text-white mb-6">Course Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="text-center p-4">
              <div className="text-4xl font-bold text-orange-300 mb-2">6</div>
              <div className="text-white font-semibold mb-1">Modules</div>
              <div className="text-gray-400 text-sm">Comprehensive curriculum</div>
            </div>
            <div className="text-center p-4">
              <div className="text-4xl font-bold text-teal-300 mb-2">13</div>
              <div className="text-white font-semibold mb-1">Hours</div>
              <div className="text-gray-400 text-sm">Live virtual delivery</div>
            </div>
            <div className="text-center p-4">
              <div className="text-4xl font-bold text-blue-300 mb-2">25</div>
              <div className="text-white font-semibold mb-1">Slides</div>
              <div className="text-gray-400 text-sm">Interactive presentation</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 pt-8 border-t border-gray-600">
          <p className="text-gray-300">© 2025 Growth Partner Pros. All Rights Reserved.</p>
          <p className="text-gray-400 mt-2">Advanced GPT-5 Training for Business Leaders</p>
        </div>
      </div>
    </div>
  );
}
