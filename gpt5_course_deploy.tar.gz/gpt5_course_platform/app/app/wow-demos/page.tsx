
'use client'
import { useState } from 'react'
import { Play, ChevronRight, Zap, Brain, Target, Rocket, Code, BarChart3, Lightbulb, ArrowRight } from 'lucide-react'
import AuthHeader from '@/components/auth-header'

const wowDemos = [
  {
    id: 'parallel-reasoning',
    title: 'GPT-5 Pro: Parallel Reasoning Engine',
    description: 'Multiple expert perspectives analyzing the same problem simultaneously',
    icon: Brain,
    color: 'from-purple-500 to-indigo-500',
    complexity: 'Advanced',
    timeToValue: '5 minutes',
    businessValue: 'Strategic Decision Making',
    demo: {
      scenario: 'Should we acquire TechStartup Inc. for $50M?',
      prompt: `Think hard - I need multiple expert perspectives on this acquisition:

ACQUISITION TARGET: TechStartup Inc.
PRICE: $50M (4x revenue)
THEIR METRICS: $12.5M ARR, 40% growth, 85% gross margins
STRATEGIC FIT: AI/ML capabilities we lack
INTEGRATION RISK: Different tech stack, 50-person team

I need perspectives from:
1. Financial analyst (ROI, valuation, cash flow impact)
2. Technology strategist (integration complexity, IP value)  
3. HR executive (cultural fit, retention risk)
4. Market analyst (competitive positioning, timing)
5. Risk manager (potential downsides, mitigation)

Provide each perspective with specific reasoning and recommendations.`,
      expectedOutput: `**FINANCIAL ANALYST PERSPECTIVE:**
- Valuation is reasonable at 4x ARR given 40% growth
- Payback period: 3.2 years assuming maintained growth
- Cash flow positive by month 18 post-acquisition
- Recommendation: PROCEED with $45M counter-offer

**TECHNOLOGY STRATEGIST PERSPECTIVE:**  
- AI/ML capabilities worth $15M+ in development savings
- Integration complexity moderate (6-9 months)
- IP portfolio includes 3 pending patents
- Recommendation: PROCEED - strategic value exceeds price

**HR EXECUTIVE PERSPECTIVE:**
- Cultural assessment shows 70% compatibility
- Key talent retention risk: CTO and 3 senior engineers
- Integration cost: $2M for retention packages
- Recommendation: PROCEED with enhanced retention plan

**MARKET ANALYST PERSPECTIVE:**
- Market timing excellent - AI adoption accelerating
- Competitive response likely from 2 major players
- Customer overlap: 15% synergy opportunities
- Recommendation: PROCEED quickly to prevent competitive acquisition

**RISK MANAGER PERSPECTIVE:**
- Technology risk: Medium (different architecture)
- Execution risk: High (complex integration)
- Market risk: Low (proven demand)  
- Recommendation: PROCEED with phased integration plan`,
      impact: 'Provides comprehensive analysis that would typically require 5 separate meetings and 2 weeks of analysis'
    }
  },
  {
    id: 'think-hard-activation',
    title: '"Think Hard" Activation for Complex Problems',
    description: 'Unlock GPT-5\'s deepest reasoning capabilities for mission-critical decisions',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500',
    complexity: 'Expert',
    timeToValue: '10 minutes',
    businessValue: 'Critical Problem Solving',
    demo: {
      scenario: 'Our top client is threatening to leave due to service issues',
      prompt: `Think hard about this client retention crisis:

CRITICAL CLIENT: GlobalCorp (30% of revenue, $15M annually)
THREAT: Considering competitor switch in 30 days
ISSUES: 
- Service uptime 94% (SLA: 99.5%)
- Response times 2x slower than promised
- 3 major incidents in Q4
- Account team turnover (3 reps in 6 months)

CONSTRAINTS:
- Cannot afford to lose this client
- Infrastructure upgrades need 90 days
- Limited budget for immediate fixes
- New account team needs training

STAKEHOLDERS:
- Their CTO (technical concerns)
- Their CFO (cost/value analysis)  
- Their operations team (daily users)
- Our CEO (strategic relationship)

I need a comprehensive save strategy that addresses technical issues, relationship repair, and long-term stability. Consider both immediate actions and strategic solutions.`,
      expectedOutput: `**IMMEDIATE ACTIONS (Next 7 Days):**
1. Executive Escalation: CEO-to-CEO call within 48 hours
2. Technical Strike Team: Deploy 3 senior engineers full-time
3. Dedicated Account Pod: VP of Customer Success + Senior Engineer
4. SLA Credit: Proactive $500K service credit for Q4 issues
5. War Room: Daily calls until stability achieved

**30-DAY RECOVERY PLAN:**
- Infrastructure hotfixes: Load balancing improvements (Week 1)
- Response time optimization: Database query optimization (Week 2)  
- Monitoring enhancement: Real-time alerting system (Week 3)
- Relationship rebuilding: On-site technical review (Week 4)

**STAKEHOLDER-SPECIFIC APPROACH:**
- CTO: Joint technical roadmap, direct engineering contact
- CFO: ROI analysis showing value vs. switching costs
- Operations: Training sessions, process improvements
- Our CEO: Strategic partnership expansion discussion

**LONG-TERM STRATEGY:**
- Premium Support Tier: Dedicated resources for top clients
- Infrastructure Modernization: $2M investment over 6 months  
- Account Management Excellence: New hiring and training program
- Proactive Communication: Monthly business reviews

**SUCCESS METRICS:**
- Uptime improvement to 99.8% within 60 days
- Response time reduction of 70% within 30 days
- Client satisfaction score increase from 6 to 9+
- Contract renewal with 2-year extension

**RISK MITIGATION:**
- Backup plan: Interim fixes if infrastructure delays occur
- Communication plan: Weekly executive updates
- Escalation protocol: If client feedback deteriorates`,
      impact: 'Creates comprehensive crisis response strategy that addresses technical, relationship, and strategic dimensions simultaneously'
    }
  },
  {
    id: 'canvas-memory',
    title: 'Canvas + Memory: Persistent Business Intelligence',
    description: 'Build evolving knowledge base that remembers context across sessions',
    icon: Code,
    color: 'from-green-500 to-teal-500',
    complexity: 'Intermediate',
    timeToValue: '15 minutes',
    businessValue: 'Continuous Intelligence',
    demo: {
      scenario: 'Building persistent competitive intelligence system',
      prompt: `Create a Canvas document for our competitive intelligence on "DataFlow Analytics":

COMPETITOR: DataFlow Analytics
LAST UPDATED: [Current Session]
INTELLIGENCE TYPE: Strategic Analysis

Please create sections for:
1. Company Overview & Recent Changes
2. Product Portfolio & Roadmap  
3. Pricing Strategy & Market Position
4. Strengths & Weaknesses Analysis
5. Customer Feedback & Win/Loss Intel
6. Strategic Threats & Opportunities
7. Recommended Counter-Strategies

INSTRUCTIONS: 
- Use Memory to recall any previous discussions about DataFlow
- Update this Canvas whenever new competitive intelligence is gathered
- Make this a living document that evolves with new information
- Include confidence levels for each piece of intelligence

START WITH: Recent news that DataFlow raised $50M Series C and acquired CustomerMetrics Inc.`,
      expectedOutput: `**CANVAS DOCUMENT CREATED: DataFlow Analytics Competitive Intelligence**

**1. COMPANY OVERVIEW & RECENT CHANGES**
- Founded 2018, $120M total funding (including new $50M Series C)
- Recent acquisition: CustomerMetrics Inc. ($15M, customer analytics)
- Team size: ~300 employees (up from 200 in Q3)
- Leadership: New VP of Enterprise Sales hired from Salesforce
*Confidence: High (public information)*

**2. PRODUCT PORTFOLIO & ROADMAP**
- Core Platform: Real-time data analytics (direct competitor)
- New Addition: Customer journey analytics (from acquisition)
- Roadmap Intel: AI/ML predictive capabilities (Q2 2025 launch)
- Integration Focus: Expanding Salesforce/HubSpot connectors
*Confidence: Medium (based on job postings and customer interviews)*

**3. PRICING STRATEGY & MARKET POSITION**
- Enterprise: $50K+ annual contracts (20% below our pricing)
- Mid-market: Aggressive penetration pricing
- Position: "Democratizing enterprise analytics"
- Recent Change: Added consumption-based pricing tier
*Confidence: High (from recent competitive deals)*

**MEMORY INTEGRATION ACTIVATED**
*This document will automatically update as new intelligence is gathered across sessions, building comprehensive competitive understanding over time.*

**Next Steps:**
1. Weekly intelligence gathering from win/loss interviews
2. Monitor their hiring patterns for product direction clues
3. Track customer feedback on review sites
4. Update pricing intelligence from sales team`,
      impact: 'Creates persistent competitive intelligence that builds over time, eliminating duplicate research and maintaining institutional knowledge'
    }
  },
  {
    id: 'kitchen-table-software',
    title: 'Kitchen Table Software Creation',
    description: 'Build custom business applications in minutes, not months',
    icon: Rocket,
    color: 'from-blue-500 to-cyan-500',
    complexity: 'Beginner',
    timeToValue: '20 minutes',
    businessValue: 'Rapid Application Development',
    demo: {
      scenario: 'Sales team needs custom lead scoring and pipeline management tool',
      prompt: `I need you to build a complete lead scoring and pipeline management application:

REQUIREMENTS:
- Lead scoring algorithm based on company size, budget, timeline, authority
- Pipeline stages: Prospect → Qualified → Demo → Proposal → Negotiation → Closed
- Automated follow-up reminders based on stage and last activity
- Revenue forecasting with probability weighting
- Rep performance dashboard with key metrics
- Mobile-friendly interface for field sales

BUSINESS RULES:
- Lead scores: 0-100 scale based on weighted criteria
- Follow-up cadence: Prospects (3 days), Qualified (1 week), Demo (3 days)
- Revenue forecast: Stage probability × Deal value × Confidence factor
- Rep metrics: Conversion rates, average deal size, cycle time

TECHNICAL REQUIREMENTS:
- Web-based application (HTML/CSS/JavaScript)
- Local storage for data (no database required initially)
- Responsive design for mobile/tablet use
- Export capabilities for reporting

Build the complete application with HTML, CSS, and JavaScript code that I can immediately deploy and use.`,
      expectedOutput: `**COMPLETE LEAD SCORING & PIPELINE APPLICATION**

*[GPT-5 would generate complete, functional code including:]*

**1. HTML Structure (index.html)**
- Lead entry forms with all required fields
- Pipeline kanban board interface  
- Rep dashboard with performance metrics
- Mobile-responsive navigation

**2. CSS Styling (styles.css)**
- Professional business theme with Growth Partner Pros colors
- Responsive grid layouts for different screen sizes
- Interactive elements with hover states
- Clean, executive-friendly design

**3. JavaScript Functionality (app.js)**
- Lead scoring algorithm with weighted calculations
- Drag-and-drop pipeline management
- Automated follow-up reminder system
- Revenue forecasting calculations
- Local storage data persistence
- Export functionality for CSV/PDF reports

**4. Business Logic Implementation**
- Company Size Scoring: Enterprise (40pts), Mid-market (25pts), SMB (10pts)
- Budget Authority: Decision maker (30pts), Influencer (15pts), User (5pts)
- Timeline Scoring: Immediate (20pts), 3 months (15pts), 6+ months (5pts)
- Pipeline Probabilities: Prospect (10%), Qualified (25%), Demo (50%), etc.

**5. Deployment Instructions**
- Simple file structure for immediate web hosting
- Configuration options for customization
- User guide for sales team adoption

**IMMEDIATE BUSINESS VALUE:**
- Replace expensive CRM for small teams
- Custom scoring based on YOUR criteria
- No monthly subscription fees
- Fully customizable for business needs`,
      impact: 'Eliminates need for expensive CRM software and months of development time, creating custom solution in minutes'
    }
  },
  {
    id: 'artifact-driven',
    title: 'Artifact-Driven Results with Proof of Work',
    description: 'Demand tangible deliverables and supporting evidence for every request',
    icon: Target,
    color: 'from-red-500 to-pink-500',
    complexity: 'Advanced',
    timeToValue: '30 minutes',
    businessValue: 'Comprehensive Analysis',
    demo: {
      scenario: 'Market entry strategy for European expansion',
      prompt: `I need comprehensive market entry analysis for European expansion with complete artifacts:

MARKET: European Union (focus on Germany, France, UK)
INVESTMENT: $25M over 18 months  
TARGET: $100M revenue by year 3
PRODUCT: B2B SaaS platform (currently US-only)

REQUIRED ARTIFACTS:
1. Market sizing spreadsheet with TAM/SAM/SOM calculations
2. Competitive landscape matrix with detailed profiles
3. Go-to-market strategy document with tactical timeline
4. Financial projections model (P&L, cash flow, unit economics)
5. Risk assessment matrix with mitigation strategies
6. Regulatory compliance checklist (GDPR, local requirements)
7. Partnership strategy framework with target partner profiles
8. Hiring plan with roles, timeline, and budget allocation
9. Marketing strategy with channel priorities and budget
10. Success metrics dashboard template

Each artifact must be:
- Immediately usable (ready-to-implement)
- Data-driven with sources and assumptions
- Executive-presentation ready
- Customizable for different scenarios

Provide complete, professional-quality deliverables that I can present to the board next week.`,
      expectedOutput: `**ARTIFACT 1: MARKET SIZING SPREADSHEET**
*Complete Excel-compatible model with:*
- TAM: €85B (EU B2B SaaS market)
- SAM: €12B (our addressable segment)  
- SOM: €240M (realistic 2% capture rate)
- Country breakdowns with growth rates
- Source citations and methodology notes

**ARTIFACT 2: COMPETITIVE LANDSCAPE MATRIX** 
*Comprehensive analysis including:*
- 8 major competitors with detailed profiles
- Feature comparison matrix (40+ capabilities)
- Pricing analysis and positioning map
- Competitive strengths/weaknesses assessment
- Market share estimates and growth trends

**ARTIFACT 3: GO-TO-MARKET STRATEGY**
*90-page strategy document covering:*
- Phase 1: Market entry (Months 1-6)
- Phase 2: Scale operations (Months 7-12)  
- Phase 3: Market leadership (Months 13-18)
- Channel strategy and partner ecosystem
- Customer acquisition playbook

**ARTIFACT 4: FINANCIAL PROJECTIONS MODEL**
*Complete 5-year financial model:*
- Monthly cash flow for first 24 months
- Unit economics by market segment
- Scenario analysis (base, optimistic, pessimistic)
- ROI calculations and payback period
- Break-even analysis by market

**[Additional 6 artifacts with similar detail level...]**

**EXECUTIVE SUMMARY DASHBOARD**
*One-page visual summary showing:*
- Investment required: $25M over 18 months
- Revenue potential: $100M by year 3 (achievable)
- Break-even: Month 22
- ROI: 285% by year 5
- Key risks and mitigation strategies
- Go/No-go recommendation with rationale`,
      impact: 'Provides board-ready analysis package that would typically require 3 months of consulting work and cost $250K+'
    }
  },
  {
    id: 'data-architecture',
    title: '400K Context: Massive Dataset Analysis',
    description: 'Process enormous datasets that would crash traditional systems',
    icon: BarChart3,
    color: 'from-indigo-500 to-purple-500',
    complexity: 'Expert',
    timeToValue: '45 minutes',
    businessValue: 'Big Data Insights',
    demo: {
      scenario: 'Analyze 5 years of customer data to predict churn and optimize retention',
      prompt: `I'm uploading our complete customer dataset (400K records, 5 years of data):

DATASET INCLUDES:
- Customer demographics (age, company size, industry, location)
- Usage patterns (login frequency, feature usage, support tickets)
- Financial data (subscription value, payment history, upgrades/downgrades)
- Engagement metrics (email opens, webinar attendance, community participation)
- Support interactions (ticket volume, satisfaction scores, resolution time)
- Contract details (start date, renewal history, cancellation data)

ANALYSIS REQUIRED:
1. Churn prediction model with accuracy metrics
2. Customer lifetime value segmentation  
3. Retention strategy recommendations by segment
4. Product usage patterns that indicate risk
5. Optimal intervention timing and methods
6. ROI projections for retention investments

DELIVERABLES:
- Executive dashboard showing key insights
- Predictive model with risk scoring
- Segmented retention playbooks
- Implementation roadmap with priorities
- Success metrics and monitoring plan

Process the entire dataset and provide comprehensive analysis that our data science team has been working on for 6 months.`,
      expectedOutput: `**DATASET PROCESSING COMPLETE**
*Successfully analyzed 400,000 customer records across 847 variables*

**KEY INSIGHTS DISCOVERED:**
1. **Churn Prediction Model (91.3% accuracy)**
   - Primary indicators: 40% usage drop + missed renewal call
   - Secondary signals: Support ticket surge + feature usage decline
   - Early warning: 73 days average before actual churn

2. **Customer Segmentation Analysis**
   - Champions (15%): High value, high engagement, 2% churn rate
   - Loyalists (35%): Steady usage, 8% churn rate  
   - At-Risk (25%): Declining engagement, 34% churn rate
   - Lost Cause (25%): Minimal usage, 67% churn rate

3. **Retention Strategy by Segment**
   - Champions: VIP program, beta access, advisory board
   - Loyalists: Upsell opportunities, success stories, referrals
   - At-Risk: Proactive outreach, usage optimization, training
   - Lost Cause: Win-back campaigns, pricing incentives

**PREDICTIVE MODEL OUTPUT:**
- 2,847 customers at high churn risk (next 90 days)
- Retention investment ROI: $4.2M potential save vs $800K cost
- Optimal intervention: 45-60 days before predicted churn
- Success probability: 68% retention with targeted intervention

**EXECUTIVE DASHBOARD:**
*Visual summary showing segment health, churn trends, intervention opportunities, and projected ROI from retention initiatives*`,
      impact: 'Processes 5 years of data in minutes vs. months, providing insights that typically require dedicated data science team'
    }
  }
]

export default function WowDemosPage() {
  const [selectedDemo, setSelectedDemo] = useState('parallel-reasoning')
  const [showFullPrompt, setShowFullPrompt] = useState(false)

  const currentDemo = wowDemos.find(demo => demo.id === selectedDemo)!

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        <AuthHeader />
        
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">WOW Demonstration Gallery</h1>
          <p className="text-xl text-gray-300">Experience GPT-5's most powerful capabilities in action</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Demo Selection */}
          <div className="lg:col-span-1">
            <h3 className="text-xl font-semibold text-white mb-4">Choose Demo</h3>
            <div className="space-y-3">
              {wowDemos.map((demo) => {
                const IconComponent = demo.icon
                return (
                  <button
                    key={demo.id}
                    onClick={() => setSelectedDemo(demo.id)}
                    className={`w-full text-left p-4 rounded-lg transition-all ${
                      selectedDemo === demo.id 
                        ? `bg-gradient-to-r ${demo.color} text-white shadow-lg transform scale-105` 
                        : 'bg-white/10 text-gray-300 hover:bg-white/15'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <IconComponent className="h-6 w-6 mt-1 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-sm">{demo.title}</div>
                        <div className="text-xs opacity-90 mt-1">{demo.description}</div>
                        <div className="flex items-center space-x-2 mt-2">
                          <span className="text-xs px-2 py-1 bg-white/20 rounded">{demo.complexity}</span>
                          <span className="text-xs px-2 py-1 bg-white/20 rounded">{demo.timeToValue}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Demo Content */}
          <div className="lg:col-span-3">
            <div className="bg-white/5 rounded-lg p-8">
              {/* Demo Header */}
              <div className="flex items-start justify-between mb-8">
                <div className="flex items-start space-x-4">
                  <div className={`p-4 rounded-lg bg-gradient-to-r ${currentDemo.color}`}>
                    <currentDemo.icon className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-white mb-2">{currentDemo.title}</h2>
                    <p className="text-gray-400 text-lg mb-4">{currentDemo.description}</p>
                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-2">
                        <Zap className="h-4 w-4 text-yellow-400" />
                        <span className="text-sm text-gray-300">Complexity: {currentDemo.complexity}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Target className="h-4 w-4 text-green-400" />
                        <span className="text-sm text-gray-300">Time to Value: {currentDemo.timeToValue}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <BarChart3 className="h-4 w-4 text-blue-400" />
                        <span className="text-sm text-gray-300">Business Value: {currentDemo.businessValue}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Demo Scenario */}
              <div className="mb-8">
                <div className="bg-orange-900/20 border border-orange-500/30 rounded-lg p-6">
                  <div className="flex items-center space-x-2 mb-3">
                    <Play className="h-5 w-5 text-orange-400" />
                    <h3 className="text-xl font-semibold text-orange-300">Demo Scenario</h3>
                  </div>
                  <p className="text-gray-200 text-lg">{currentDemo.demo.scenario}</p>
                </div>
              </div>

              {/* Prompt Section */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">GPT-5 Prompt</h3>
                  <button
                    onClick={() => setShowFullPrompt(!showFullPrompt)}
                    className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/15 rounded-lg transition-colors"
                  >
                    <span className="text-gray-300">{showFullPrompt ? 'Collapse' : 'Expand'} Prompt</span>
                    <ChevronRight className={`h-4 w-4 text-gray-300 transition-transform ${showFullPrompt ? 'rotate-90' : ''}`} />
                  </button>
                </div>
                <div className="bg-gray-900/50 rounded-lg border border-gray-700">
                  <div className="p-4">
                    <pre className={`text-gray-200 text-sm whitespace-pre-wrap font-mono ${
                      showFullPrompt ? '' : 'line-clamp-6'
                    }`}>
                      {currentDemo.demo.prompt}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Expected Output */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-teal-300 mb-4">Expected GPT-5 Output</h3>
                <div className="bg-teal-900/10 border border-teal-500/30 rounded-lg p-6">
                  <pre className="text-gray-200 text-sm whitespace-pre-wrap">
                    {currentDemo.demo.expectedOutput}
                  </pre>
                </div>
              </div>

              {/* Business Impact */}
              <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-6">
                <div className="flex items-start space-x-3">
                  <Lightbulb className="h-6 w-6 text-green-400 mt-1" />
                  <div>
                    <h4 className="text-lg font-semibold text-green-300 mb-2">Business Impact</h4>
                    <p className="text-green-100">{currentDemo.demo.impact}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-16 pt-8 border-t border-gray-700">
          <p className="text-xs text-gray-400">© 2025 Growth Partner Pros. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  )
}
