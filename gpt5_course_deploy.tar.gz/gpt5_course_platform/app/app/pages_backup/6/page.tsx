
import Image from 'next/image';

export default function Slide6() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Block 1: Module Header */}
        <div className="flex-none text-center mb-8">
          <div className="gradient-accent p-4 rounded-lg inline-block mb-4">
            <h1 className="text-6xl font-bold text-white">Module 2</h1>
          </div>
          <h2 className="text-7xl font-bold mb-4 text-white">Advanced Prompting & Specification Writing</h2>
          <p className="text-3xl text-gray-300 mb-2">2.5 Hours</p>
          <p className="text-4xl text-orange-300 font-bold">From Conversations to Specifications</p>
        </div>

        {/* Main Content Grid */}
        <div className="flex-1 grid grid-cols-[3fr_1fr] gap-8 min-h-0">
          
          {/* Left Column */}
          <div className="flex flex-col gap-8 min-h-0">
            
            {/* Block 2: Paradigm Shift */}
            <div className="bg-white/10 p-6 rounded-lg border border-gray-500/50 flex-shrink">
              <h3 className="text-4xl font-bold text-white mb-4 text-center">A Paradigm Shift in Communication</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-red-500/10 p-4 rounded-lg">
                  <h4 className="text-2xl font-bold text-red-300 mb-2">Old Way: Conversational</h4>
                  <p className="text-xl text-gray-300 italic">"Can you help me analyze our sales data?"</p>
                </div>
                <div className="bg-green-500/10 p-4 rounded-lg">
                  <h4 className="text-2xl font-bold text-green-300 mb-2">New Way: Specification</h4>
                  <p className="text-xl text-gray-300 italic">"Analyze Q3 sales data for top 3 growth opportunities. Deliver: Exec summary, data tables, 90-day roadmap."</p>
                </div>
              </div>
               <p className="text-center text-yellow-300 mt-4 text-2xl font-semibold">Specifications prevent ambiguity and ensure focused results.</p>
            </div>

            {/* Block 3: Master Framework */}
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 p-6 rounded-lg border border-gray-500/50 flex-1 min-h-0">
              <h3 className="text-4xl font-bold text-white mb-4 text-center">The 6-Element Specification Template</h3>
              <div className="grid grid-cols-2 grid-rows-3 gap-x-6 gap-y-4 text-2xl">
                <p><span className="font-bold text-cyan-300">1. TASK:</span> Define the core objective.</p>
                <p><span className="font-bold text-cyan-300">2. DELIVERABLE:</span> Format, length, audience.</p>
                <p><span className="font-bold text-cyan-300">3. ASSUMPTIONS:</span> Specify knowns & unknowns.</p>
                <p><span className="font-bold text-cyan-300">4. NON-GOALS:</span> Define constraints.</p>
                <p><span className="font-bold text-cyan-300">5. TOOLS:</span> Specify allowed resources.</p>
                <p><span className="font-bold text-cyan-300">6. ACCEPTANCE:</span> Define success criteria.</p>
              </div>
               <p className="text-center text-gray-200 mt-4 text-2xl">This template transforms mediocre results into executive-quality outputs.</p>
            </div>

          </div>

          {/* Block 4: Facilitator Guide (Right Column) */}
          <div className="facilitator-notes">
            <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
            <div className="space-y-4 text-base">
              <div>
                <h4 className="font-semibold text-orange-200">Timing: 30 minutes</h4>
                <p className="text-gray-200">Focus on the "why" behind specs.</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Demo Setup:</h4>
                <p className="text-gray-200">Prepare a real before/after example.</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Live Demo:</h4>
                <p className="text-gray-200">Transform a participant's prompt using the 6-element framework.</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Key Message:</h4>
                <p className="text-gray-200 font-bold">"Specifications are contracts with AI, not conversations."</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Transition:</h4>
                <p className="text-gray-200">"Next, we'll deep dive into each element."</p>
              </div>
            </div>
          </div>

        </div>

        {/* Block 5: Footer */}
        <div className="flex-none flex justify-between items-center mt-8 text-base text-gray-400">
          <div className="flex items-center space-x-4">
            <Image 
              src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
              alt="Growth Partner Pros Logo" 
              width={50} 
              height={50}
              className="rounded"
            />
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 2: Specification Framework • 30 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
