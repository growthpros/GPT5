

import Image from 'next/image';

export default function Slide15() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-4">
          <div className="gradient-accent p-3 rounded-lg inline-block mb-3">
            <h1 className="text-5xl font-bold text-white">Module 4</h1>
          </div>
          <h2 className="text-6xl font-bold mb-2 text-white">Business Application Deep Dive</h2>
          <p className="text-2xl text-gray-300 mb-1">3 Hours</p>
          <p className="text-3xl teal-accent font-semibold">High-Impact Use Cases for Executives</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-4 min-h-0">
          {/* Application Framework */}
          <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 border border-gray-500/50 p-4 rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4 text-center">GPT-5 Pro vs Standard: Strategic Decision Matrix</h2>
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white/10 p-4 rounded">
                <h3 className="text-2xl font-bold text-yellow-300 mb-2">GPT-5 Pro Applications</h3>
                <p className="text-lg text-gray-200 mb-3">For critical tasks needing parallel reasoning & high accuracy.</p>
                <div className="space-y-1 text-base text-blue-200">
                  <p>• Financial modeling & analysis</p>
                  <p>• Legal due diligence</p>
                  <p>• Technical architecture decisions</p>
                </div>
              </div>
              <div className="bg-white/10 p-4 rounded">
                <h3 className="text-2xl font-bold text-green-300 mb-2">Standard GPT-5 Applications</h3>
                <p className="text-lg text-gray-200 mb-3">For speed, creativity, and general business tasks.</p>
                <div className="space-y-1 text-base text-green-200">
                  <p>• Customer success analysis</p>
                  <p>• Sales optimization & marketing</p>
                  <p>• Project management</p>
                </div>
              </div>
            </div>
            <div className="gradient-accent p-3 rounded text-center mt-4">
              <h3 className="text-xl font-bold text-white">Cost-Benefit Rule: Use Pro when errors cost &gt;10x the model price.</h3>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[3fr_1fr] gap-4 min-h-0">
            {/* High-Value Pro Applications */}
            <div className="space-y-3">
              <h2 className="text-3xl font-bold text-white">GPT-5 Pro: Parallel Reasoning Excellence</h2>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-3 rounded">
                  <h3 className="text-xl font-bold text-blue-300 mb-1">Financial Modeling</h3>
                  <p className="text-sm text-gray-200">Parse financial statements for comprehensive analysis.</p>
                </div>
                <div className="bg-red-500/20 border-l-4 border-red-500 p-3 rounded">
                  <h3 className="text-xl font-bold text-red-300 mb-1">Legal Analysis</h3>
                  <p className="text-sm text-gray-200">Apply legal frameworks to large document sets.</p>
                </div>
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-3 rounded">
                  <h3 className="text-xl font-bold text-purple-300 mb-1">Strategic Planning</h3>
                  <p className="text-sm text-gray-200">Process market, competitive, and internal data.</p>
                </div>
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-3 rounded">
                  <h3 className="text-xl font-bold text-orange-300 mb-1">Risk Assessment</h3>
                  <p className="text-sm text-gray-200">Identify hidden risks with multi-dimensional analysis.</p>
                </div>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-xl font-bold mb-3 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <h4 className="font-semibold text-orange-200">Timing: 45 mins</h4>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Demo:</h4>
                  <p className="text-gray-200">Show Pro vs. Standard on a complex financial dataset.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Key Message:</h4>
                  <p className="text-gray-200 font-semibold">Pro is qualitatively different, not just an upgrade.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-3 text-base text-gray-400">
          <div className="flex items-center space-x-4">
            <Image 
              src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
              alt="Growth Partner Pros Logo" 
              width={40} 
              height={40}
              className="rounded"
            />
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 4: Business Applications Framework • 45 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
