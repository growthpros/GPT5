

import Image from 'next/image';

export default function Slide18() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-4">
          <h1 className="text-5xl font-bold text-white mb-2">
            Standard GPT-5: High-Volume Business Applications
          </h1>
          <p className="text-3xl text-gray-300">Optimal Speed & Cost for Daily Operations</p>
        </div>

        {/* Main Content - 3 rows for applications */}
        <div className="flex-1 grid grid-rows-3 gap-4">
          {/* Customer Success Application */}
          <div className="bg-green-500/20 border border-green-500/50 p-4 rounded-lg flex flex-col">
            <h2 className="text-2xl font-bold text-green-300 mb-2">Customer Success & Voice of Customer Analysis</h2>
            <div className="grid grid-cols-3 gap-4 flex-1">
              <div>
                <h3 className="text-xl font-bold text-green-200 mb-1">Processing Power:</h3>
                <p className="text-base text-gray-200">Analyze thousands of customer interactions (tickets, surveys) for key patterns.</p>
              </div>
              <div>
                <h3 className="text-xl font-bold text-green-200 mb-1">Business Value:</h3>
                <ul className="space-y-1 text-base text-gray-200">
                  <li>- Proactively identify product issues</li>
                  <li>- Discover upsell opportunities</li>
                  <li>- Predict churn risk from interactions</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-green-200 mb-1">Implementation:</h3>
                <p className="text-base text-gray-200 mb-2">Monthly analysis of 10k+ tickets reveals top pain points and generates recommendations.</p>
                <div className="gradient-accent p-2 rounded mt-auto">
                  <p className="text-white font-bold text-base">ROI: Reduces churn 15-20% via proactive issue identification.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sales Optimization Application */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-4 rounded-lg flex flex-col">
            <h2 className="text-2xl font-bold text-blue-300 mb-2">Sales & Deal Management Optimization</h2>
            <div className="grid grid-cols-3 gap-4 flex-1">
              <div>
                <h3 className="text-xl font-bold text-blue-200 mb-1">Processing Power:</h3>
                <p className="text-base text-gray-200">Analyze deal patterns, proposal success, and team performance from large datasets.</p>
              </div>
              <div>
                <h3 className="text-xl font-bold text-blue-200 mb-1">Business Value:</h3>
                <ul className="space-y-1 text-base text-gray-200">
                  <li>- Identify winning proposal traits</li>
                  <li>- Optimize sales territories & quotas</li>
                  <li>- Predict deal closure probability</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-blue-200 mb-1">Implementation:</h3>
                <p className="text-base text-gray-200 mb-2">Quarterly analysis of 500+ deals shows technical depth boosts close rate by 23%.</p>
                <div className="gradient-accent p-2 rounded mt-auto">
                  <p className="text-white font-bold text-base">ROI: Increases close rate 10-15% and shortens sales cycle.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Marketing Strategy Application */}
          <div className="bg-purple-500/20 border border-purple-500/50 p-4 rounded-lg flex flex-col">
            <h2 className="text-2xl font-bold text-purple-300 mb-2">Marketing Strategy & Content Optimization</h2>
            <div className="grid grid-cols-3 gap-4 flex-1">
              <div>
                <h3 className="text-xl font-bold text-purple-200 mb-1">Processing Power:</h3>
                <p className="text-base text-gray-200">Analyze campaign performance, engagement, and content effectiveness across channels.</p>
              </div>
              <div>
                <h3 className="text-xl font-bold text-purple-200 mb-1">Business Value:</h3>
                <ul className="space-y-1 text-base text-gray-200">
                  <li>- Optimize content via engagement data</li>
                  <li>- Identify top audience segments</li>
                  <li>- Generate multi-channel strategies</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-purple-200 mb-1">Implementation:</h3>
                <p className="text-base text-gray-200 mb-2">Analysis shows educational content drives 3x more qualified leads than promotions.</p>
                <div className="gradient-accent p-2 rounded mt-auto">
                  <p className="text-white font-bold text-base">ROI: Improves campaign ROI 25-30% with data-driven optimization.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-4 text-base text-gray-400">
          <div className="flex items-center space-x-2">
            <Image 
              src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
              alt="Growth Partner Pros Logo" 
              width={40} 
              height={40}
              className="rounded"
            />
            <span className="text-sm">© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="text-sm">
            Module 4: Standard GPT-5 Applications • 30 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
