

import Image from 'next/image';

export default function Slide9() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-6xl font-bold text-white mb-4">
            Live Prompt Transformation Workshop
          </h1>
          <p className="text-3xl text-gray-300">Transform Real Business Prompts Using the 6-Element Framework</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-6 min-h-0">
          {/* Transformation Examples */}
          <div className="bg-gradient-to-r from-red-500/20 to-green-500/20 border border-gray-500/50 p-6 rounded-lg flex flex-col">
            <h2 className="text-3xl font-bold text-white mb-4 text-center">Executive Prompt Transformation</h2>
            
            <div className="grid grid-cols-1 gap-4 flex-1">
              <div className="bg-red-500/20 border-l-4 border-red-500 p-4 rounded">
                <h3 className="text-2xl font-bold text-red-300 mb-2">❌ BEFORE</h3>
                <div className="bg-gray-800 p-3 rounded">
                  <p className="text-xl text-gray-200 italic">"Analyze our sales performance and tell me what to do about it."</p>
                </div>
              </div>

              <div className="bg-green-500/20 border-l-4 border-green-500 p-4 rounded flex flex-col">
                <h3 className="text-2xl font-bold text-green-300 mb-2">✅ AFTER</h3>
                <div className="bg-gray-800 p-3 rounded flex-1">
                  <div className="text-base text-gray-200 space-y-1">
                    <p><span className="text-blue-300 font-bold">TASK:</span> Analyze Q3 sales for top 3 improvement areas.</p>
                    <p><span className="text-purple-300 font-bold">DELIVERABLE:</span> Brief, data viz, & 90-day action plan.</p>
                    <p><span className="text-green-300 font-bold">ASSUMPTIONS:</span> B2B segment only; compare vs Q2 & Q3.</p>
                    <p><span className="text-orange-300 font-bold">NON-GOALS:</span> Exclude competitor analysis.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="gradient-accent p-3 rounded text-center mt-4">
              <h3 className="text-2xl font-bold text-white">Result: 10x improvement in output quality and usability</h3>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-6 min-h-0">
            {/* Prompt Template Library */}
            <div className="flex flex-col space-y-2 min-h-0 bg-gray-900/50 border border-gray-500/50 p-6 rounded-lg">
              <h2 className="text-3xl font-bold teal-accent">Executive Prompt Templates</h2>
              <div className="grid grid-cols-2 gap-3 flex-1">
                <div className="space-y-2">
                  <div className="bg-blue-500/20 border-l-4 border-blue-500 p-3 rounded"><h3 className="text-xl font-bold text-blue-300">Financial Analysis</h3></div>
                  <div className="bg-purple-500/20 border-l-4 border-purple-500 p-3 rounded"><h3 className="text-xl font-bold text-purple-300">Market Research</h3></div>
                </div>
                <div className="space-y-2">
                  <div className="bg-green-500/20 border-l-4 border-green-500 p-3 rounded"><h3 className="text-xl font-bold text-green-300">Strategic Planning</h3></div>
                  <div className="bg-orange-500/20 border-l-4 border-orange-500 p-3 rounded"><h3 className="text-xl font-bold text-orange-300">Operations Review</h3></div>
                </div>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="bg-gray-900/50 border border-gray-500/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold mb-3 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-2 text-base">
                <p><span className="font-semibold text-orange-200">Timing:</span> 40 minutes</p>
                <p><span className="font-semibold text-orange-200">Format:</span> Interactive exercise</p>
                <p><span className="font-semibold text-orange-200">Steps:</span> Collect, Transform, Refine</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-4 text-base text-gray-400">
          <div className="flex items-center space-x-4">
            <Image 
              src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
              alt="Growth Partner Pros Logo" 
              width={40} 
              height={40}
              className="rounded"
            />
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 2: Prompt Transformation • 40 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
