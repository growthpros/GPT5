

import Image from 'next/image';

export default function Slide8() {
  return (
    <div className="slide-container">
      <div className="grid grid-cols-[3fr_1fr] gap-6 h-full">
        {/* Left Column */}
        <div className="flex flex-col gap-4 min-h-0">
          {/* Header */}
          <div className="flex-none text-center">
            <h1 className="text-5xl font-bold text-white mb-1">
              Artifact-Driven Prompting
            </h1>
            <p className="text-3xl text-gray-300">Prove Your Work: Demand Evidence from AI</p>
          </div>

          {/* Content Grid */}
          <div className="grid grid-rows-2 gap-4 flex-1 min-h-0">
            {/* Artifact Concept */}
            <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-lg flex flex-col justify-center min-h-0">
              <h2 className="text-3xl font-bold text-blue-300 mb-3">The Verification Principle</h2>
              <p className="text-xl text-gray-200 mb-3">
                Always demand AI to prove its work with supporting materials.
              </p>
              <ul className="space-y-2 text-lg text-gray-300">
                <li><span className="font-semibold text-yellow-300">Analogy:</span> Require consultants to show their methodology.</li>
                <li><span className="font-semibold text-green-300">Impact:</span> Forces AI to be more thorough and accurate.</li>
                <li><span className="font-semibold text-orange-300">Benefit:</span> Provides a clear audit trail for business decisions.</li>
                <li><span className="font-semibold text-teal-300">Rule:</span> Mandate artifacts in every specification.</li>
              </ul>
            </div>

            {/* Artifact Examples */}
            <div className="min-h-0">
              <h2 className="text-3xl font-bold teal-accent mb-3">Types of Business Artifacts to Demand</h2>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-purple-300">Python Workbooks</h3>
                  <p className="text-sm text-gray-200">Statistical analysis, calculations, and assumptions.</p>
                </div>
                <div className="bg-red-500/20 border-l-4 border-red-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-red-300">Data Sources</h3>
                  <p className="text-sm text-gray-200">Specific sources and dates for all cited information.</p>
                </div>
                <div className="bg-green-500/20 border-l-4 border-green-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-green-300">Rubrics</h3>
                  <p className="text-sm text-gray-200">Plain English criteria used to evaluate options.</p>
                </div>
                <div className="bg-teal-500/20 border-l-4 border-teal-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-teal-300">Methodology</h3>
                  <p className="text-sm text-gray-200">Step-by-step process to reach conclusions.</p>
                </div>
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-blue-300">Personas</h3>
                  <p className="text-sm text-gray-200">Customer profiles from market analysis.</p>
                </div>
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-2 rounded">
                  <h3 className="text-lg font-bold text-orange-300">Decision Trees</h3>
                  <p className="text-sm text-gray-200">Logic frameworks behind recommendations.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Facilitator Guide */}
        <div className="facilitator-notes">
          <h3 className="text-xl font-bold mb-3 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-2 text-sm">
            <div>
              <h4 className="font-semibold text-orange-200">Timing: 35 minutes</h4>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Demo Setup:</h4>
              <p className="text-gray-200">Prompts with vs. without artifacts.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Live Comparison:</h4>
              <p className="text-gray-200">Show dramatic quality difference.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Before Example:</h4>
              <p className="text-gray-200">Basic analysis, conclusions only.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">After Example:</h4>
              <p className="text-gray-200">Analysis with workbook, rubrics, etc.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Interactive Element:</h4>
              <p className="text-gray-200 italic">"Which would you trust for a board presentation?"</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Key Message:</h4>
              <p className="text-gray-200 font-semibold">Artifacts make AI a transparent partner.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-3 text-base text-gray-400">
        <div className="flex items-center space-x-4">
          <Image 
            src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
            alt="Growth Partner Pros Logo" 
            width={40} 
            height={40}
            className="rounded"
          />
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 2: Artifact-Driven Prompting • 35 minutes
        </div>
      </div>
    </div>
  );
}
