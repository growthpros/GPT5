

import Image from 'next/image';

export default function Slide20() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none gradient-accent p-4 rounded-lg text-center mb-4">
          <h1 className="text-4xl font-bold text-white mb-1">Module 4: Business Applications Complete</h1>
          <p className="text-xl text-white">Participants can now identify optimal GPT-5 applications for their business</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-4 min-h-0">
          {/* Application Summary */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-4 rounded-lg">
            <h2 className="text-3xl font-bold text-blue-300 mb-3 text-center">Applications Mastered</h2>
            <div className="grid grid-cols-2 gap-x-6">
              <div>
                <h3 className="text-2xl font-bold text-yellow-300 mb-2">GPT-5 Pro:</h3>
                <ul className="space-y-1 text-lg text-gray-200">
                  <li>✅ Financial modeling & analysis</li>
                  <li>✅ Legal due diligence</li>
                  <li>✅ Strategic market analysis</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-green-300 mb-2">Standard GPT-5:</h3>
                <ul className="space-y-1 text-lg text-gray-200">
                  <li>✅ Customer success optimization</li>
                  <li>✅ Sales & deal management</li>
                  <li>✅ Marketing & content strategy</li>
                </ul>
              </div>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-3">
              <div className="gradient-accent p-3 rounded text-center">
                <h3 className="text-xl font-bold text-white mb-1">Selection Framework</h3>
                <p className="text-sm text-white">Make data-driven decisions on Pro vs. Standard.</p>
              </div>
              <div className="gradient-accent p-3 rounded text-center">
                <h3 className="text-xl font-bold text-white mb-1">Business Impact</h3>
                <p className="text-sm text-white">40-60% improvement in analysis quality & speed.</p>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-4 min-h-0">
            {/* Implementation Planning Exercise */}
            <div className="flex flex-col space-y-3">
              <h2 className="text-3xl font-bold teal-accent">Develop Your AI Application Strategy</h2>
              
              <div className="flex-1 grid grid-rows-4 gap-2">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-2 rounded">
                  <h3 className="text-xl font-bold text-green-300">Step 1: Identify Top 3 Applications</h3>
                  <p className="text-sm text-gray-200">Select 3 applications aligned with business priorities.</p>
                </div>
                
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-2 rounded">
                  <h3 className="text-xl font-bold text-blue-300">Step 2: Pro vs Standard Matrix</h3>
                  <p className="text-sm text-gray-200">Apply the decision framework to each application.</p>
                </div>
                
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-2 rounded">
                  <h3 className="text-xl font-bold text-purple-300">Step 3: Create Implementation Timeline</h3>
                  <p className="text-sm text-gray-200">Draft a 90-day rollout plan with pilot phase and metrics.</p>
                </div>
                
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-2 rounded">
                  <h3 className="text-xl font-bold text-orange-300">Step 4: Estimate ROI</h3>
                  <p className="text-sm text-gray-200">Calculate expected time savings and business impact.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="gradient-accent p-2 rounded text-center">
                  <h3 className="text-lg font-bold text-white">Deliverable:</h3>
                  <p className="text-sm text-white">AI transformation roadmap</p>
                </div>
                <div className="gradient-accent p-2 rounded text-center">
                  <h3 className="text-lg font-bold text-white">Group Sharing:</h3>
                  <p className="text-sm text-white">3-min strategy presentation</p>
                </div>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-xl font-bold mb-2 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-2 text-sm text-gray-200">
                <div>
                  <h4 className="font-semibold text-orange-200">Timing: 35 minutes</h4>
                  <p>20 min planning, 15 min feedback.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Support:</h4>
                  <p>Provide application & ROI templates.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Common Challenges:</h4>
                  <p>Over-planning & underestimating change.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Success Criteria:</h4>
                  <p className="font-semibold">Clear 90-day plan with a pilot app.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-3 text-base text-gray-400">
          <div className="flex items-center space-x-4">
            <Image 
              src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
              alt="Growth Partner Pros Logo" 
              width={40} 
              height={40}
              className="rounded"
            />
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 4 Complete • Break: 15 minutes • Module 5: Kitchen Table Software
          </div>
        </div>
      </div>
    </div>
  );
}
