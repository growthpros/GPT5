
import Image from 'next/image';

export default function Slide17() {
  return (
    <div className="slide-container flex flex-col h-full">
      <div className="grid grid-cols-[2fr_1fr] grid-rows-[1fr_1fr] gap-6 flex-grow min-h-0">
        {/* Strategic Analysis Application */}
        <div className="bg-purple-500/20 border border-purple-500/50 p-6 rounded-lg flex flex-col min-h-0">
          <h2 className="text-3xl font-bold text-purple-300 mb-3">Strategic Market Analysis</h2>
          <div className="space-y-2 text-xl text-gray-200 flex-grow flex flex-col">
            <div>
              <h3 className="text-2xl font-bold text-purple-200 mb-1">Multi-Source Processing:</h3>
              <p>Analyze customer interviews, surveys, competitor profiles, and internal data simultaneously.</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-purple-200 mb-1">Parallel Lenses:</h3>
              <p>Apply market entry, positioning, and risk assessment frameworks in parallel.</p>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded">
              <h3 className="text-xl font-bold text-yellow-300 mb-1">Example:</h3>
              <p>Analyze 50+ interviews & 12 competitor profiles for an optimal entry strategy.</p>
            </div>
            <div className="gradient-accent p-3 rounded mt-auto">
              <h3 className="text-xl font-bold text-white mb-1">Strategic Deliverables:</h3>
              <ul className="list-disc list-inside text-white text-base">
                <li>Market entry strategy with 3 scenarios</li>
                <li>Competitive positioning recommendations</li>
                <li>90-day execution roadmap</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Technical Architecture Application */}
        <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg flex flex-col min-h-0">
          <h2 className="text-3xl font-bold text-blue-300 mb-3">Technical Architecture</h2>
          <div className="space-y-2 text-xl text-gray-200 flex-grow flex flex-col">
            <div>
              <h3 className="text-2xl font-bold text-blue-200 mb-1">Multi-Perspective Analysis:</h3>
              <p>Evaluate system design for performance, security, scalability, and maintainability.</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-blue-200 mb-1">Parallel Evaluation:</h3>
              <p>Apply architectural patterns & security frameworks across large codebases.</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-blue-200 mb-1">Technical Value:</h3>
              <ul className="list-disc list-inside text-base">
                <li>Identifies multi-dimensional architectural debt.</li>
                <li>Finds security vulnerabilities in system design.</li>
              </ul>
            </div>
            <div className="gradient-accent p-3 rounded mt-auto">
              <h3 className="text-xl font-bold text-white mb-1">Executive Impact:</h3>
              <p className="text-white text-base">Reduces technical risk and accelerates development.</p>
            </div>
          </div>
        </div>

        {/* Comprehensive Facilitator Guide */}
        <div className="facilitator-notes row-span-2 flex flex-col min-h-0">
          <h3 className="text-2xl font-bold mb-3 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-3 text-base flex-grow flex flex-col">
            <p><span className="font-semibold text-orange-200">Total Timing:</span> 50 minutes (25 min each)</p>
            
            <div className="bg-purple-500/20 p-3 rounded">
              <h4 className="font-semibold text-purple-300 mb-1">Strategic Demo:</h4>
              <ul className="list-disc list-inside text-gray-200">
                <li>Prepare market entry scenario with customer & competitor data.</li>
                <li>Show parallel reasoning and generate recommendations.</li>
              </ul>
            </div>
            
            <div className="bg-blue-500/20 p-3 rounded">
              <h4 className="font-semibold text-blue-300 mb-1">Technical Demo:</h4>
              <ul className="list-disc list-inside text-gray-200">
                <li>Prepare a simplified codebase analysis scenario.</li>
                <li>Demonstrate parallel evaluation and risk assessment.</li>
              </ul>
            </div>
            
            <div className="mt-auto">
              <h4 className="font-semibold text-orange-200 mb-1">Key Messages:</h4>
              <ul className="list-disc list-inside text-gray-200">
                <li>Strategic: Reveal market opportunities others miss.</li>
                <li>Technical: Prevent costly architectural mistakes.</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-orange-200">Transition:</h4>
              <p className="text-gray-200">Next, we'll cover customer success applications.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-4 text-base text-gray-400">
        <div className="flex items-center space-x-4">
          <Image 
            src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
            alt="Growth Partner Pros Logo" 
            width={50} 
            height={50}
            className="rounded"
          />
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 4: Strategic & Technical Applications • 50 minutes
        </div>
      </div>
    </div>
  );
}
