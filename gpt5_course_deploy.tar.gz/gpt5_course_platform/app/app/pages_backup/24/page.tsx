

import Image from 'next/image';

export default function Slide24() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-5xl font-bold text-white mb-4">
            Module 5: Hands-On Application Building
          </h1>
          <p className="text-3xl text-gray-300 mb-2">45 minutes</p>
          <p className="text-4xl teal-accent font-semibold">Build a functional business application with your own data</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-6 min-h-0">
          {/* Practice Overview */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg">
            <h2 className="text-4xl font-bold text-blue-300 mb-3">Practice Session Purpose</h2>
            <p className="text-2xl text-gray-200 mb-4">Transform your business challenge into a functional software application.</p>
            
            <div className="grid grid-cols-3 gap-6">
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-2">Materials Needed:</h3>
                <ul className="space-y-1 text-xl text-gray-200">
                  <li>• A business process to improve</li>
                  <li>• Clear app requirements</li>
                  <li>• GPT-5 access</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-2">Success Criteria:</h3>
                <ul className="space-y-1 text-xl text-gray-200">
                  <li>• Functional app for a real need</li>
                  <li>• Understand the building process</li>
                  <li>• Confidence to build more apps</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-2">Take-Home Value:</h3>
                <p className="text-xl text-gray-200">Leave with a working application and templates for future projects.</p>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[1fr_1fr] gap-6 min-h-0">
            {/* Building Exercise */}
            <div className="flex flex-col space-y-4">
              <h2 className="text-4xl font-bold teal-accent">Individual Application Building Workshop</h2>
              
              <div className="flex-1 space-y-3">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-3 rounded">
                  <h3 className="text-2xl font-bold text-green-300">Step 1: Identify Problem (10 min)</h3>
                  <p className="text-lg text-gray-300">Task: Choose a specific business challenge to solve.</p>
                </div>

                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-3 rounded">
                  <h3 className="text-2xl font-bold text-blue-300">Step 2: Define Requirements (10 min)</h3>
                  <p className="text-lg text-gray-300">Task: List application features and UI needs.</p>
                </div>

                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-3 rounded">
                  <h3 className="text-2xl font-bold text-purple-300">Step 3: Build Application (20 min)</h3>
                  <p className="text-lg text-gray-300">Task: Use GPT-5 to generate the application code.</p>
                </div>

                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-3 rounded">
                  <h3 className="text-2xl font-bold text-orange-300">Step 4: Test & Refine (5 min)</h3>
                  <p className="text-lg text-gray-300">Task: Test the app and make improvements.</p>
                </div>
              </div>

              <div className="gradient-accent p-4 rounded text-center">
                <p className="text-xl text-white">
                  <span className="font-bold">Deliverable:</span> A functional business app, followed by a 5-min group showcase.
                </p>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes bg-gray-800/50 p-6 rounded-lg">
              <h3 className="text-3xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-3 text-lg text-gray-200">
                <p><span className="font-semibold text-orange-200">Timing:</span> 45 mins total with showcase.</p>
                <p><span className="font-semibold text-orange-200">Approach:</span> Circulate to provide individual guidance.</p>
                <div>
                  <h4 className="font-semibold text-orange-200 mb-1">Common Challenges:</h4>
                  <ul className="list-disc list-inside text-base space-y-1 pl-2">
                    <li>Problems too complex for the time</li>
                    <li>Technical anxiety or perfectionism</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200 mb-1">Success Support:</h4>
                  <ul className="list-disc list-inside text-base space-y-1 pl-2">
                    <li>Provide simple application templates</li>
                    <li>Encourage iteration over perfection</li>
                    <li>Emphasize business value over technical elegance</li>
                  </ul>
                </div>
                <p><span className="font-semibold text-orange-200">Troubleshooting:</span> Have backup apps ready if participants struggle.</p>
                <p><span className="font-semibold text-orange-200">Showcase:</span> Keep demos to 2-3 minutes each for time management.</p>
                <p className="font-semibold text-gray-100">Celebrate every functional application, regardless of complexity!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
