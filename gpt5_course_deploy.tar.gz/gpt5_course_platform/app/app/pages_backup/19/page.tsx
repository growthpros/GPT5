
import Image from 'next/image';

export default function Slide19() {
  return (
    <div className="slide-container">
      <div className="grid grid-cols-[3fr_1fr] grid-rows-[auto_auto_1fr] gap-4 h-full min-h-0">
        {/* Product Development Application */}
        <div className="col-span-2 bg-green-500/20 border border-green-500/50 p-4 rounded-lg min-h-0">
          <h2 className="text-4xl font-bold text-green-300 mb-3">Product Development & Requirements</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="min-w-0">
              <h3 className="text-2xl font-bold text-green-200 mb-2">Core Capabilities:</h3>
              <p className="text-lg text-gray-200 mb-2">Generate PRDs, analyze user feedback, create technical specs, and develop prototypes.</p>
              <ul className="space-y-1 text-lg text-gray-200">
                <li>• Convert interviews to requirements</li>
                <li>• Analyze feature usage patterns</li>
              </ul>
            </div>
            <div className="min-w-0">
              <div className="bg-yellow-500/20 p-3 rounded mb-3">
                <h3 className="text-xl font-bold text-yellow-300 mb-1">Example:</h3>
                <p className="text-lg text-gray-200">Analyzes 2,000+ feedback items to generate a prioritized feature roadmap.</p>
              </div>
              
              <div className="gradient-accent p-3 rounded">
                <h3 className="text-xl font-bold text-white mb-1">Impact:</h3>
                <p className="text-lg text-white">Reduces product planning time by 50% and improves requirement quality.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Operations Management Application */}
        <div className="col-span-2 bg-orange-500/20 border border-orange-500/50 p-4 rounded-lg min-h-0">
          <h2 className="text-4xl font-bold text-orange-300 mb-3">Operations & Process Optimization</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="min-w-0">
              <h3 className="text-2xl font-bold text-orange-200 mb-2">Core Capabilities:</h3>
              <p className="text-lg text-gray-200 mb-2">Analyze workflows, find bottlenecks, optimize resources, and suggest improvements.</p>
              <ul className="space-y-1 text-lg text-gray-200">
                <li>• Analyze workflow efficiency</li>
                <li>• Identify process bottlenecks</li>
              </ul>
            </div>
            <div className="min-w-0">
              <div className="bg-yellow-500/20 p-3 rounded mb-3">
                <h3 className="text-xl font-bold text-yellow-300 mb-1">Example:</h3>
                <p className="text-lg text-gray-200">Workflow analysis reduces response time by 40% by fixing bottlenecks.</p>
              </div>
              
              <div className="gradient-accent p-3 rounded">
                <h3 className="text-xl font-bold text-white mb-1">Impact:</h3>
                <p className="text-lg text-white">Improves efficiency by 20-30%, cutting costs and improving service quality.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Decision Framework */}
        <div className="space-y-3 min-h-0 flex flex-col">
          <h2 className="text-3xl font-bold text-white">GPT-5 Pro vs Standard</h2>
          
          <div className="bg-yellow-500/20 border border-yellow-500/50 p-3 rounded">
            <h3 className="text-xl font-bold text-yellow-300 mb-1">Use Pro When:</h3>
            <ul className="space-y-1 text-lg text-gray-200">
              <li>• Cost of error is high</li>
              <li>• High-risk, critical decisions</li>
            </ul>
          </div>

          <div className="bg-green-500/20 border border-green-500/50 p-3 rounded">
            <h3 className="text-xl font-bold text-green-300 mb-1">Use Standard When:</h3>
            <ul className="space-y-1 text-lg text-gray-200">
              <li>• High-volume, routine tasks</li>
              <li>• Creative content generation</li>
            </ul>
          </div>

          <div className="gradient-accent p-3 rounded text-center mt-auto">
            <h3 className="text-lg font-bold text-white mb-1">Guidance:</h3>
            <p className="text-base text-white">Start with Standard, escalate to Pro for critical analysis.</p>
          </div>
        </div>

        {/* Facilitator Guide */}
        <div className="facilitator-notes min-h-0 flex flex-col">
          <h3 className="text-xl font-bold mb-2 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-2 text-sm flex-grow flex flex-col">
            <div>
              <h4 className="font-bold text-orange-200">Timing: 40 minutes</h4>
              <ul className="list-disc list-inside">
                <li>Product Demo (15m)</li>
                <li>Operations Demo (15m)</li>
                <li>Framework Exercise (10m)</li>
              </ul>
            </div>
            <div className="mt-auto">
              <h4 className="font-bold text-orange-200">Key Takeaways:</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Standard for most business apps.</li>
                <li>Pro for critical, high-risk decisions.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-3 text-base text-gray-400">
        <div className="flex items-center space-x-4">
          <Image 
            src="https://cdn.abacus.ai/images/768a78cf-edff-48a9-acc1-c21a8ba76093.png" 
            alt="Growth Partner Pros Logo" 
            width={40} 
            height={40}
            className="rounded"
          />
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 4: Product & Operations Applications • 40 minutes
        </div>
      </div>
    </div>
  );
}
