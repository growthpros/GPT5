


export default function Slide12() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-6xl font-bold text-white mb-4">
            Canvas + Memory Integration
          </h1>
          <p className="text-4xl text-gray-300">Version Control for AI Work & Persistent Business Context</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_auto_1fr] gap-6 min-h-0">
          {/* Canvas Capabilities */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg">
            <h2 className="text-4xl font-bold text-blue-300 mb-4">Canvas: AI-Powered Document Collaboration</h2>
            <div className="grid grid-cols-2 gap-x-6">
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-3">Key Features:</h3>
                <ul className="space-y-2 text-2xl text-gray-200">
                  <li>• Real-time AI collaboration</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-3">Business Use Cases:</h3>
                <ul className="space-y-2 text-2xl text-gray-200">
                  <li>• Strategic planning</li>
                </ul>
              </div>
            </div>
            <div className="gradient-accent p-3 rounded mt-4 text-center">
              <p className="text-2xl font-bold text-white">Competitive Advantage: Rapid, context-aware iteration</p>
            </div>
          </div>

          {/* Memory Integration */}
          <div className="bg-purple-500/20 border border-purple-500/50 p-6 rounded-lg">
            <h2 className="text-4xl font-bold text-purple-300 mb-4">Memory: Persistent AI Business Context</h2>
            <div className="grid grid-cols-2 gap-x-6">
              <div>
                <h3 className="text-2xl font-bold text-purple-200 mb-3">Persistent Context:</h3>
                <ul className="space-y-2 text-2xl text-gray-200">
                  <li>• Learns company terminology & style</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-purple-200 mb-3">Cross-Session Benefits:</h3>
                <ul className="space-y-2 text-2xl text-gray-200">
                  <li>• Consistent quality, no re-explaining</li>
                </ul>
              </div>
            </div>
            <div className="gradient-accent p-3 rounded mt-4 text-center">
              <p className="text-2xl font-bold text-white">Enterprise Value: Institutional knowledge that grows over time</p>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-6 min-h-0">
            {/* Collaborative Workflow */}
            <div className="flex flex-col space-y-4">
              <h2 className="text-4xl font-bold teal-accent">AI Collaboration Workflow</h2>
              <div className="flex-1 space-y-2">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-2 rounded"><p className="text-base text-gray-200"><strong>1. Initialize:</strong> AI generates a draft from a business objective.</p></div>
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-2 rounded"><p className="text-base text-gray-200"><strong>2. Refine:</strong> Executive provides feedback for AI revision.</p></div>
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-2 rounded"><p className="text-base text-gray-200"><strong>3. Finalize:</strong> Iterate with AI until the output is executive-ready.</p></div>
                <div className="bg-teal-500/20 border-l-4 border-teal-500 p-2 rounded"><p className="text-base text-gray-200"><strong>4. Memorize:</strong> Memory captures preferences for future work.</p></div>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-4 text-lg">
                <div><h4 className="font-semibold text-orange-200">Timing:</h4><p>35 minutes</p></div>
                <div><h4 className="font-semibold text-orange-200">Key Takeaway:</h4><p className="font-semibold">AI becomes a long-term partner that learns and grows with you.</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
