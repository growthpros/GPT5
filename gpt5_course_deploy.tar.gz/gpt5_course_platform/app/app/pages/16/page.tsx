


export default function Slide16() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-6xl font-bold text-white mb-4">
            Financial Modeling &amp; Legal Analysis
          </h1>
          <p className="text-4xl text-gray-300">Where Parallel Reasoning Delivers Maximum ROI</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-2 gap-6 min-h-0">
          {/* Top Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-6 min-h-0">
            {/* Financial Application Deep Dive */}
            <div className="bg-green-500/20 border border-green-500/50 p-6 rounded-lg flex flex-col">
              <h2 className="text-3xl font-bold text-green-300 mb-4">Executive Financial Analysis with GPT-5 Pro</h2>
              <div className="space-y-3 text-2xl text-gray-200 flex-1 flex flex-col">
                <p><strong className="font-bold text-green-200">Parallel Processing:</strong> Analyze income statements, balance sheets, and cash flow simultaneously.</p>
                <p><strong className="font-bold text-green-200">Unique Value:</strong> Identifies cross-statement inconsistencies missed by sequential analysis.</p>
                <div className="bg-yellow-500/20 p-3 rounded">
                  <p><strong className="font-bold text-yellow-300">Example:</strong> Q3 analysis shows revenue growth but poor cash flow. Pro catches both instantly.</p>
                </div>
                <div>
                  <strong className="font-bold text-green-200">Key Deliverables:</strong>
                  <ul className="list-disc list-inside text-2xl">
                    <li>Comprehensive financial health assessment</li>
                    <li>Risk identification with quantified impact</li>
                  </ul>
                </div>
                <div className="gradient-accent p-3 rounded text-center mt-auto">
                  <p className="text-xl font-bold text-white">Time Savings: Reduces analysis from days to hours, improving accuracy.</p>
                </div>
              </div>
            </div>

            {/* Financial Demo Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-xl font-bold mb-3 text-orange-300">Financial Demo Guide</h3>
              <div className="space-y-3 text-base">
                <div><h4 className="font-semibold text-orange-200">Timing:</h4><p>25 minutes</p></div>
                <div><h4 className="font-semibold text-orange-200">Materials:</h4><p>Anonymized financial statements.</p></div>
                <div>
                  <h4 className="font-semibold text-orange-200">Demo Process:</h4>
                  <ul className="list-disc list-inside">
                    <li>Upload financial data</li>
                    <li>Show parallel reasoning & insights</li>
                    <li>Generate executive summary</li>
                  </ul>
                </div>
                <div><h4 className="font-semibold text-orange-200">Interactive:</h4><p>Ask CFOs what they&apos;d miss with sequential analysis.</p></div>
                <div><h4 className="font-semibold text-orange-200">Key Insight:</h4><p>Analyzes more completely, not just faster.</p></div>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-6 min-h-0">
            {/* Legal Application Deep Dive */}
            <div className="bg-red-500/20 border border-red-500/50 p-6 rounded-lg flex flex-col">
              <h2 className="text-3xl font-bold text-red-300 mb-4">Legal Due Diligence with Parallel Reasoning</h2>
              <div className="space-y-3 text-2xl text-gray-200 flex-1 flex flex-col">
                <p><strong className="font-bold text-red-200">Parallel Processing:</strong> Review contract terms, compliance, and risks across documents simultaneously.</p>
                <p><strong className="font-bold text-red-200">Unique Value:</strong> Catches cross-document inconsistencies missed by sequential review.</p>
                <div className="bg-yellow-500/20 p-3 rounded">
                  <p><strong className="font-bold text-yellow-300">Example:</strong> M&A due diligence on 200+ contracts, flagging risks and unusual terms instantly.</p>
                </div>
                <div>
                  <strong className="font-bold text-red-200">Key Deliverables:</strong>
                  <ul className="list-disc list-inside text-2xl">
                    <li>Comprehensive risk assessment matrix</li>
                    <li>Compliance gap analysis</li>
                  </ul>
                </div>
                <div className="gradient-accent p-3 rounded text-center mt-auto">
                  <p className="text-xl font-bold text-white">Risk Mitigation: Reduces costly legal oversights in post-deal discoveries.</p>
                </div>
              </div>
            </div>

            {/* Legal Demo Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-xl font-bold mb-3 text-orange-300">Legal Demo Guide</h3>
              <div className="space-y-3 text-base">
                <div><h4 className="font-semibold text-orange-200">Timing:</h4><p>25 minutes</p></div>
                <div><h4 className="font-semibold text-orange-200">Materials:</h4><p>Sample contract collection for simulation.</p></div>
                <div>
                  <h4 className="font-semibold text-orange-200">Demo Process:</h4>
                  <ul className="list-disc list-inside">
                    <li>Process multiple contracts simultaneously</li>
                    <li>Demonstrate risk identification</li>
                    <li>Generate compliance summary</li>
                  </ul>
                </div>
                <div><h4 className="font-semibold text-orange-200">Interactive:</h4><p>Ask legal leaders about current review processes.</p></div>
                <div><h4 className="font-semibold text-orange-200">ROI Calculation:</h4><p>Estimate time and risk reduction value.</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
