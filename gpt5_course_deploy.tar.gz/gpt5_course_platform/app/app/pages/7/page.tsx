


export default function Slide7() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-6xl font-bold text-white mb-4">
            Precision Prompting Framework
          </h1>
          <p className="text-4xl text-orange-300 font-bold">From Vague Requests to Professional Specifications</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-cols-[3fr_1fr] gap-8 min-h-0">
          {/* Left Column */}
          <div className="flex flex-col space-y-6">
            {/* Framework Overview */}
            <div className="bg-slate-800/50 border border-slate-700 p-6 rounded-lg flex-none">
              <h2 className="text-4xl font-bold text-blue-300 mb-4">The SPEC Framework</h2>
              <div className="grid grid-cols-4 gap-4 text-center">
                <div className="gradient-accent p-3 rounded">
                  <h3 className="text-xl font-bold text-white mb-1">S</h3>
                  <p className="text-base text-white">Situation</p>
                </div>
                <div className="gradient-accent p-3 rounded">
                  <h3 className="text-xl font-bold text-white mb-1">P</h3>
                  <p className="text-base text-white">Purpose</p>
                </div>
                <div className="gradient-accent p-3 rounded">
                  <h3 className="text-xl font-bold text-white mb-1">E</h3>
                  <p className="text-base text-white">Expectations</p>
                </div>
                <div className="gradient-accent p-3 rounded">
                  <h3 className="text-xl font-bold text-white mb-1">C</h3>
                  <p className="text-base text-white">Constraints</p>
                </div>
              </div>
              <p className="text-2xl text-gray-200 mt-4 text-center">
                Every professional prompt needs these four elements.
              </p>
            </div>

            {/* Before and After Examples */}
            <div className="grid grid-cols-2 gap-6 flex-1 min-h-0">
              <div className="bg-red-500/20 border-l-4 border-red-500 p-6 rounded-lg">
                <h2 className="text-3xl font-bold text-red-300 mb-4">❌ Vague Request</h2>
                <div className="bg-gray-800/50 p-4 rounded mb-4">
                  <p className="text-xl text-gray-200 italic">"Help me analyze our customer satisfaction data"</p>
                </div>
                <div className="space-y-2 text-lg text-gray-200">
                  <p><span className="font-semibold text-red-300">Missing:</span> Context, goals, format, timeline</p>
                  <p><span className="font-semibold text-red-300">Result:</span> Generic response requiring multiple follow-ups</p>
                  <p><span className="font-semibold text-red-300">Business Risk:</span> Wasted time, poor insights</p>
                </div>
              </div>

              <div className="bg-green-500/20 border-l-4 border-green-500 p-6 rounded-lg">
                <h2 className="text-3xl font-bold text-green-300 mb-4">✅ Professional Specification</h2>
                <div className="bg-gray-800/50 p-4 rounded mb-4 text-lg">
                  <p className="text-green-200">
                    <span className="font-semibold">[S]</span> Q3 customer satisfaction dropped 12%<br/>
                    <span className="font-semibold">[P]</span> Identify root causes for board presentation<br/>
                    <span className="font-semibold">[E]</span> Executive summary + data analysis + recommendations<br/>
                    <span className="font-semibold">[C]</span> 3 pages max, focus on actionable insights
                  </p>
                </div>
                <div className="space-y-2 text-lg text-gray-200">
                  <p><span className="font-semibold text-green-300">Result:</span> Board-ready analysis in one response</p>
                  <p><span className="font-semibold text-green-300">Business Value:</span> Professional output, no revisions</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Facilitator Guide */}
          <div className="facilitator-notes">
            <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
            <div className="space-y-4 text-base">
              <div>
                <h4 className="font-semibold text-orange-200">Timing: 30 minutes</h4>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Teaching Approach:</h4>
                <p className="text-gray-200">Live demonstration of framework application</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Interactive Element:</h4>
                <p className="text-gray-200">Participants transform their own vague prompts using SPEC</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Executive Connection:</h4>
                <p className="text-gray-200 italic">"You wouldn't brief your team vaguely—don't brief AI vaguely either."</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Practice Setup:</h4>
                <p className="text-gray-200">15-min breakout: Apply SPEC to real business challenges</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Success Metric:</h4>
                <p className="text-gray-200">Each participant creates one professional specification</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-6 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 2: Precision Prompting • 30 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
