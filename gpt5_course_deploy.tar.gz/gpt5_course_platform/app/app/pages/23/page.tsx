


export default function Slide23() {
  return (
    <div className="slide-container">
      <div className="grid grid-cols-[2fr_1fr] gap-8 h-full">
        {/* Left Column */}
        <div className="flex flex-col min-h-0">
          {/* Title */}
          <div className="flex-none text-center mb-6">
            <h1 className="text-6xl font-bold text-white mb-4">
              Software Application Categories
            </h1>
            <p className="text-4xl text-gray-300">Functional Business Apps You Can Build Today</p>
          </div>

          {/* 2x3 Grid for Categories */}
          <div className="grid grid-cols-2 grid-rows-3 gap-4 flex-1">
            {/* Project Management */}
            <div className="bg-blue-500/20 border border-blue-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-blue-300 mb-3">Project Management</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Interactive Gantt charts</li>
                <li>• Resource allocation dashboards</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-blue-200 font-semibold">Business Value: Replace expensive PM software</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 30-60 mins</p>
              </div>
            </div>

            {/* Data Visualization */}
            <div className="bg-purple-500/20 border border-purple-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-purple-300 mb-3">Data Visualization</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Executive dashboards</li>
                <li>• KPI tracking systems</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-purple-200 font-semibold">Business Value: Turn static reports into interactive BI</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 45-90 mins</p>
              </div>
            </div>

            {/* Process Automation */}
            <div className="bg-green-500/20 border border-green-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-green-300 mb-3">Process Automation</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Approval workflow systems</li>
                <li>• Compliance checklists</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-green-200 font-semibold">Business Value: Streamline manual processes</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 60-120 mins</p>
              </div>
            </div>

            {/* Team Collaboration */}
            <div className="bg-orange-500/20 border border-orange-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-orange-300 mb-3">Team Collaboration</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Meeting management tools</li>
                <li>• Knowledge sharing platforms</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-orange-200 font-semibold">Business Value: Enhance team productivity</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 45-75 mins</p>
              </div>
            </div>

            {/* Performance Tracking */}
            <div className="bg-red-500/20 border border-red-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-red-300 mb-3">Performance Tracking</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Goal monitoring systems</li>
                <li>• Progress reporting apps</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-red-200 font-semibold">Business Value: Automate performance management</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 30-60 mins</p>
              </div>
            </div>

            {/* Customer Management */}
            <div className="bg-teal-500/20 border border-teal-500/50 p-4 rounded-lg flex flex-col">
              <h3 className="text-3xl font-bold text-teal-300 mb-3">Customer Management</h3>
              <ul className="space-y-2 text-2xl text-gray-200 mb-4">
                <li>• Client interaction trackers</li>
                <li>• Feedback collection systems</li>
              </ul>
              <div className="bg-white/10 p-2 rounded mt-auto">
                <p className="text-base text-teal-200 font-semibold">Business Value: Purpose-built CRM tools</p>
                <p className="text-base text-gray-300 mt-1">Time to Build: 60-90 mins</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Facilitator Guide */}
        <div className="facilitator-notes">
          <h3 className="text-3xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-4 text-xl">
            <div>
              <h4 className="font-semibold text-orange-200">Timing: 35 minutes</h4>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Presentation Approach:</h4>
              <p className="text-gray-200">Briefly introduce each category, allowing for questions.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Interactive Elements:</h4>
              <ul className="space-y-1 text-gray-200">
                <li>• Ask which categories are most interesting.</li>
                <li>• Discuss automating current manual processes.</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Template Distribution:</h4>
              <p className="text-gray-200">Provide take-home templates for each category.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Practical Focus:</h4>
              <p className="text-gray-200">Emphasize these are real, functional business apps.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Common Questions:</h4>
              <ul className="space-y-1 text-gray-200">
                <li>• "How do I maintain these applications?"</li>
                <li>• "What about data security?"</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Next Slide Setup:</h4>
              <p className="text-gray-200">Prepare for hands-on building exercise.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
