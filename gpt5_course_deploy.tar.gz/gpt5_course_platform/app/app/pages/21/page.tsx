

export default function Slide21() {
  return (
    <div className="slide-container flex flex-col h-full">
      <div className="grid grid-cols-[3fr_1fr] grid-rows-[auto_1fr] gap-8 flex-grow min-h-0">
        {/* Module Header */}
        <div className="col-span-2 text-center">
          <div className="gradient-accent p-3 rounded-lg inline-block mb-4">
            <h1 className="text-5xl font-bold text-white">Module 5</h1>
          </div>
          <h2 className="text-6xl font-bold mb-2 text-white">Kitchen Table Software Revolution</h2>
          <p className="text-3xl text-gray-300 mb-2">2 Hours</p>
          <p className="text-4xl teal-accent font-semibold">Building Business Applications Without IT</p>
        </div>

        {/* Left Column: Main Content */}
        <div className="space-y-6 flex flex-col min-h-0">
          {/* Revolution Concept */}
          <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-gray-500/50 p-6 rounded-lg">
            <h2 className="text-4xl font-bold text-yellow-300 mb-4">The "Kitchen Table Software" Revolution</h2>
            <p className="text-2xl text-gray-200 mb-4">
              Executives building their own functional business applications using natural language.
            </p>
            <div className="space-y-4 text-2xl">
              <div className="bg-white/10 p-4 rounded">
                <h3 className="font-bold text-orange-300 mb-1">Paradigm Shift:</h3>
                <p>From requesting IT development to creating solutions directly.</p>
              </div>
              <div className="bg-white/10 p-4 rounded">
                <h3 className="font-bold text-green-300 mb-1">New Capability:</h3>
                <p>GPT-5 enables rapid application prototyping and deployment.</p>
              </div>
            </div>
          </div>
          
          {/* Revolution Details */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg flex-grow">
            <h3 className="text-3xl font-bold text-blue-300 mb-3">Key Capabilities & Impact</h3>
            <ul className="space-y-3 text-2xl text-gray-200">
              <li><span className="font-semibold text-purple-300">Technical Reality:</span> Generate complete web apps with minimal technical input.</li>
              <li><span className="font-semibold text-green-300">Development Speed:</span> Create applications in hours, not weeks.</li>
              <li><span className="font-semibold text-red-300">Quality Level:</span> Professional-grade applications, not just prototypes.</li>
              <li><span className="font-semibold text-yellow-300">Advantage:</span> Move faster than competitors dependent on traditional IT.</li>
            </ul>
          </div>
        </div>

        {/* Right Column: Facilitator Guide */}
        <div className="facilitator-notes bg-gray-800/50 p-6 rounded-lg flex flex-col space-y-4 min-h-0">
          <h3 className="text-3xl font-bold text-orange-300 text-center">Facilitator Guide</h3>
          <div className="space-y-4 text-2xl text-gray-200">
            <div>
              <h4 className="font-semibold text-orange-200">Timing:</h4>
              <p>30 minutes</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Audience Prep:</h4>
              <p>Address skepticism about non-technical users building software.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Demo Setup:</h4>
              <p>Prepare a live demo of building a simple business app (e.g., project dashboard).</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Key Message:</h4>
              <p>Focus on business problem-solving, not programming.</p>
            </div>
             <div>
              <h4 className="font-semibold text-orange-200">Engagement:</h4>
              <p>Ask participants about business apps they wish they had.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-auto pt-4 text-base text-gray-400">
        <div className="flex items-center">
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 5: Kitchen Table Software Introduction • 30 minutes
        </div>
      </div>
    </div>
  );
}
