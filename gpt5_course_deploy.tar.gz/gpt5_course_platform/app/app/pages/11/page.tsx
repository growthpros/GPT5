

export default function Slide11() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <div className="gradient-accent p-4 rounded-lg inline-block mb-4">
            <h1 className="text-6xl font-bold text-white">Module 3</h1>
          </div>
          <h2 className="text-7xl font-bold mb-2 text-white">Data Architecture & Canvas Integration</h2>
          <p className="text-3xl text-gray-300 mb-2">2 Hours</p>
          <p className="text-4xl teal-accent font-semibold">Preparing Your Business for AI Excellence</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-6 min-h-0">
          {/* Context Revolution */}
          <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-gray-500/50 p-6 rounded-lg">
            <h2 className="text-5xl font-bold text-white mb-4 text-center">GPT-5's 400,000 Token Context Window</h2>
            <div className="grid grid-cols-3 gap-6 text-center">
              <div className="bg-white/10 p-4 rounded">
                <h3 className="text-2xl font-bold text-blue-300 mb-2">Business Translation</h3>
                <p className="text-base text-gray-200">Process entire reports, project docs, or market research in one query.</p>
              </div>
              <div className="bg-white/10 p-4 rounded">
                <h3 className="text-2xl font-bold text-red-300 mb-2">New Scale</h3>
                <p className="text-base text-gray-200">From 4-8 pages (Old AI) to over 200+ pages with GPT-5.</p>
              </div>
              <div className="bg-white/10 p-4 rounded">
                <h3 className="text-2xl font-bold text-purple-300 mb-2">Strategic Advantage</h3>
                <p className="text-base text-gray-200">Clean data architecture provides an exponential advantage.</p>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[3fr_1fr] gap-6 min-h-0">
            {/* Data Architecture Principles */}
            <div className="space-y-4 flex flex-col">
              <h2 className="text-4xl font-bold teal-accent">Data Architecture Principles</h2>
              
              <div className="grid grid-cols-2 gap-4 flex-1">
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-blue-300 mb-2">1: Multi-Dimensional</h3>
                  <p className="text-base text-gray-200">Present data from multiple perspectives (risk, growth, competitive).</p>
                </div>
                
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-purple-300 mb-2">2: Format Optimization</h3>
                  <p className="text-base text-gray-200">Use markdown or CSV for optimal AI processing.</p>
                </div>
                
                <div className="bg-green-500/20 border-l-4 border-green-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-green-300 mb-2">3: Cross-Referencing</h3>
                  <p className="text-base text-gray-200">Include temporal changes and relational connections.</p>
                </div>
                
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-orange-300 mb-2">4: Context Encoding</h3>
                  <p className="text-base text-gray-200">Embed business context, assumptions, and frameworks.</p>
                </div>
              </div>

              <div className="gradient-accent p-4 rounded-lg text-center">
                <h3 className="text-3xl font-bold text-white">Business Impact: Clean data enables executive-level AI insights.</h3>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes bg-gray-800/50 p-4 rounded-lg">
              <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-3 text-base">
                <p><span className="font-semibold text-orange-200">Timing:</span> 30 mins</p>
                <p><span className="font-semibold text-orange-200">Demo:</span> Contrast messy vs. clean data processing.</p>
                <p><span className="font-semibold text-orange-200">Interaction:</span> Ask about their largest business docs.</p>
                <p><span className="font-semibold text-orange-200">Key Message:</span> Data structure is a high-ROI investment.</p>
                <p><span className="font-semibold text-orange-200">Transition:</span> Next: Canvas and Memory for collaboration.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-4 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 3: Data Architecture • 30 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
