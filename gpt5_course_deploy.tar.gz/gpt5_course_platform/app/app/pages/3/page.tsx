


export default function Slide3() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-7xl font-bold mb-4 text-white">
            GPT-5's Multi-Model Architecture
          </h1>
          <p className="text-4xl text-orange-300 font-bold mb-2">Revolutionary Parallel Processing System</p>
          <p className="text-2xl text-gray-300">Understanding the Technical Foundation</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-cols-[2fr_1fr] gap-8 min-h-0">
          {/* Left Column */}
          <div className="flex flex-col space-y-6">
            {/* Architecture Overview */}
            <div className="bg-slate-800/50 border border-slate-700 p-6 rounded-lg flex-none">
              <h2 className="text-4xl font-bold text-blue-300 mb-4">Architecture Breakthrough</h2>
              <p className="text-2xl text-gray-200 mb-4">
                GPT-5 runs multiple specialized models simultaneously, not sequentially.
              </p>
              <div className="grid grid-cols-2 gap-4 text-xl">
                <div className="text-green-300">
                  <span className="font-semibold">Old Way (GPT-4):</span>
                  <p className="text-gray-200">Single model processes everything.</p>
                </div>
                <div className="text-orange-300">
                  <span className="font-semibold">New Way (GPT-5):</span>
                  <p className="text-gray-200">Specialized models work in parallel.</p>
                </div>
              </div>
            </div>

            {/* Business Impact */}
            <div className="bg-purple-500/20 border border-purple-500/50 p-6 rounded-lg flex-1 min-h-0">
              <h2 className="text-4xl font-bold text-purple-300 mb-4">Business Impact</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-2xl font-bold text-yellow-300 mb-2">Standard GPT-5:</h3>
                  <ul className="space-y-2 text-xl text-gray-200">
                    <li>• 2x faster than GPT-4</li>
                    <li>• Better accuracy on complex tasks</li>
                    <li>• Handles larger context windows</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-green-300 mb-2">GPT-5 Pro:</h3>
                  <ul className="space-y-2 text-xl text-gray-200">
                    <li>• Advanced reasoning capabilities</li>
                    <li>• Multi-step problem solving</li>
                    <li>• Professional-grade analysis</li>
                  </ul>
                </div>
              </div>
              <div className="gradient-accent p-4 rounded mt-4">
                <p className="text-2xl font-bold text-white text-center">
                  Executive Insight: This isn't just an upgrade—it's a new category of AI
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Facilitator Guide */}
          <div className="facilitator-notes">
            <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
            <div className="space-y-4 text-base">
              <div>
                <h4 className="font-semibold text-orange-200">Timing: 20 minutes</h4>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Key Talking Points:</h4>
                <ul className="text-gray-200 space-y-1">
                  <li>• Emphasize "parallel processing" analogy</li>
                  <li>• Connect to business efficiency gains</li>
                  <li>• Address "Is this really different?"</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Demo Preparation:</h4>
                <p className="text-gray-200">Show same complex task on GPT-4 vs GPT-5</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Executive Hook:</h4>
                <p className="text-gray-200 italic">"Think of it like upgrading from a single-core to a multi-core processor for AI."</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Transition:</h4>
                <p className="text-gray-200">Next, we'll see how to activate these capabilities.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-6 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 1: Architecture Overview • 20 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
