


export default function Slide5() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-4">
          <h1 className="text-5xl font-bold mb-2 text-white">
            Module 1: Hands-On Practice
          </h1>
          <p className="text-3xl text-gray-300 mb-2">30 minutes</p>
          <p className="text-4xl teal-accent font-semibold">Master Model Routing & Activation</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-4 min-h-0">
          {/* Practice Overview */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-4 rounded-lg">
            <h2 className="text-4xl font-bold text-blue-300 mb-3">Practice Overview</h2>
            <div className="grid grid-cols-3 gap-4 text-xl text-gray-200">
              <div>
                <h3 className="font-semibold text-blue-200 mb-1">Instructions:</h3>
                <p>Practice routing techniques with your own business scenarios.</p>
              </div>
              <div>
                <h3 className="font-semibold text-blue-200 mb-1">Materials Needed:</h3>
                <ul className="space-y-1">
                  <li>• Access to GPT-5</li>
                  <li>• Your business problem</li>
                  <li>• Provided template</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-blue-200 mb-1">Success Criteria:</h3>
                <p>Successfully route queries and activate thinking mode.</p>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[1fr_1fr] gap-6 min-h-0">
            {/* Practice Exercises */}
            <div className="flex flex-col space-y-4">
              <h2 className="text-4xl font-bold teal-accent">Practice Exercises</h2>
              
              <div className="flex-grow flex flex-col space-y-4">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-green-300 mb-1">Exercise 1: Model Routing</h3>
                  <p className="text-xl text-gray-200">Transform prompt into specification.</p>
                </div>

                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-purple-300 mb-1">Exercise 2: Thinking Mode</h3>
                  <p className="text-xl text-gray-200">Use 'think hard' for complex analysis.</p>
                </div>

                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-orange-300 mb-1">Exercise 3: Pro vs Standard</h3>
                  <p className="text-xl text-gray-200">Test the same prompt on both versions.</p>
                </div>
              </div>

              <div className="gradient-accent p-4 rounded-lg">
                <h3 className="text-2xl font-bold text-white mb-1">Deliverable:</h3>
                <p className="text-xl text-white">Document performance differences & report key insights.</p>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="facilitator-notes">
              <h3 className="text-2xl font-bold mb-3 text-orange-300">Facilitator Guide</h3>
              <div className="space-y-3 text-base">
                <div>
                  <h4 className="font-semibold text-orange-200">Timing Breakdown:</h4>
                  <ul className="text-gray-200">
                    <li>• 5 min: Setup, 20 min: Practice, 5 min: Share</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Facilitator Role:</h4>
                  <p className="text-gray-200">Circulate in breakout rooms to assist.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Common Issues:</h4>
                  <ul className="text-gray-200">
                    <li>• Reverting to old prompting habits</li>
                    <li>• Confusion on Pro vs. Standard use cases</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Troubleshooting:</h4>
                  <p className="text-gray-200">Provide template examples for reference.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Module 1 Wrap:</h4>
                  <p className="text-gray-200 font-semibold">Key takeaway: GPT-5 requires a new approach.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-4 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 1 Complete • Module 2 Starting
          </div>
        </div>
      </div>
    </div>
  );
}
