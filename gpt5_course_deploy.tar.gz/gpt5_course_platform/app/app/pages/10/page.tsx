

export default function Slide10() {
  return (
    <div className="slide-container">
      <div className="grid grid-cols-[2fr_1fr] grid-rows-[auto_1fr] gap-6 h-full">
        {/* Module Completion */}
        <div className="col-span-2 gradient-accent p-6 rounded-lg text-center">
          <h1 className="text-5xl font-bold text-white mb-4">Module 2: Advanced Prompting Complete</h1>
          <div className="grid grid-cols-4 gap-4 text-white">
            <div>
              <h3 className="text-xl font-bold mb-2">✅ Mastered</h3>
              <p className="text-lg">6-element framework</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">✅ Learned</h3>
              <p className="text-lg">Artifact-driven prompting</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">✅ Transformed</h3>
              <p className="text-lg">Real business prompts</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">✅ Built</h3>
              <p className="text-lg">Personal prompt library</p>
            </div>
          </div>
          <div className="mt-4 bg-white/20 p-4 rounded">
            <h3 className="text-2xl font-bold text-yellow-300 mb-2">Readiness Check</h3>
            <p className="text-xl text-white">Participants should now think in specifications, not conversations.</p>
          </div>
        </div>

        {/* Organizational Strategy */}
        <div className="space-y-4 min-h-0 flex flex-col">
          <h2 className="text-4xl font-bold teal-accent">Building Organizational Prompt Libraries</h2>
          
          <div className="space-y-3 flex-grow">
            <div className="bg-blue-500/20 border-l-4 border-blue-500 p-3 rounded">
              <h3 className="text-xl font-bold text-blue-300 mb-1">Step 1: Document</h3>
              <p className="text-lg text-gray-200">Document successful prompts with business context.</p>
            </div>
            
            <div className="bg-purple-500/20 border-l-4 border-purple-500 p-3 rounded">
              <h3 className="text-xl font-bold text-purple-300 mb-1">Step 2: Share</h3>
              <p className="text-lg text-gray-200">Share proven templates across departments.</p>
            </div>
            
            <div className="bg-green-500/20 border-l-4 border-green-500 p-3 rounded">
              <h3 className="text-xl font-bold text-green-300 mb-1">Step 3: Review</h3>
              <p className="text-lg text-gray-200">Establish a quality review process for new prompts.</p>
            </div>
            
            <div className="bg-orange-500/20 border-l-4 border-orange-500 p-3 rounded">
              <h3 className="text-xl font-bold text-orange-300 mb-1">Step 4: Improve</h3>
              <p className="text-lg text-gray-200">Create a feedback loop for continuous improvement.</p>
            </div>
          </div>

          <div className="gradient-accent p-4 rounded mt-auto">
            <h3 className="text-2xl font-bold text-white mb-2">Business Case</h3>
            <p className="text-xl text-white">Shared prompt libraries lead to 3x faster AI adoption.</p>
          </div>
        </div>

        {/* Facilitator Guide */}
        <div className="facilitator-notes min-h-0">
          <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-4 text-base">
            <div>
              <h4 className="font-semibold text-orange-200">Timing: 30 minutes total</h4>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-2">Completion Activities:</h4>
              <ul className="space-y-1 text-gray-200">
                <li>• Review key concepts (10 min)</li>
                <li>• Organizational planning (15 min)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-2">Planning Exercise:</h4>
              <p className="text-gray-200">Outline your team's prompt library strategy.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-2">Transition to Module 3:</h4>
              <p className="text-gray-200">Prepare your data architecture for GPT-5's full potential.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-4 text-base text-gray-400">
        <div className="flex items-center">
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 2 Complete • Break: 15 minutes • Module 3: Data Architecture
        </div>
      </div>
    </div>
  );
}
