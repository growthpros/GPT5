


export default function Slide1() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <p className="text-2xl mb-2 text-gray-300">Welcome to the Executive's Guide to</p>
          <h1 className="text-8xl font-bold mb-4 text-white leading-tight">
            Mastering GPT-5
          </h1>
          <p className="text-5xl mb-4 text-orange-300 font-bold">
            Advanced Capabilities for Business Leaders
          </p>
          <p className="text-3xl text-gray-300">13-Hour Comprehensive Course • Live Virtual Delivery</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col justify-center items-center space-y-6">
          <div className="gradient-accent p-6 rounded-lg text-center">
            <h2 className="text-6xl font-bold text-white mb-4">
              Leap Ahead of 99% of ChatGPT Users
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-6 max-w-4xl text-center">
            <div className="text-2xl text-gray-200 space-y-3">
              <p>✓ Master GPT-5's unique multi-model architecture</p>
              <p>✓ Transform from conversations to specifications</p>
              <p>✓ Build business applications without IT</p>
              <p>✓ Lead AI transformation in your organization</p>
              <p>✓ Gain competitive advantages others don't understand</p>
            </div>
          </div>

          <div className="text-center">
            <p className="text-3xl font-semibold teal-accent mb-2">Target Audience</p>
            <p className="text-2xl text-gray-300">Business Executives • Department Leaders • Strategic Decision Makers</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-6 text-base text-gray-400">
          <div className="flex items-center">
            <span className="text-gray-300">© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Introduction & Setup • 5 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
