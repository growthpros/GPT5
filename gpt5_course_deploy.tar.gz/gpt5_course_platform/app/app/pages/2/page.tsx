

export default function Slide2() {
  return (
    <div className="slide-container">
      <div className="grid grid-cols-[2fr_1fr] gap-8 h-full">
        {/* Main Content */}
        <div className="flex flex-col justify-between">
          <div className="text-center mb-8">
            <div className="gradient-accent p-4 rounded-lg inline-block mb-4">
              <h1 className="text-6xl font-bold text-white">Module 1</h1>
            </div>
            <h2 className="text-7xl font-bold mb-4 text-white">GPT-5 Architecture Mastery</h2>
            <p className="text-4xl text-gray-300 mb-2">2 Hours</p>
            <p className="text-5xl teal-accent font-semibold">Understanding the Multi-Model Revolution</p>
          </div>

          <div className="space-y-6">
            <div className="bg-red-500/20 border-l-4 border-red-500 p-6 rounded">
              <h3 className="text-4xl font-bold mb-4 text-red-300">Revolutionary Architecture Insight</h3>
              <p className="text-3xl font-semibold mb-4 text-white">
                GPT-5 is NOT a single model - it's multiple models bundled together
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="text-2xl text-gray-200 space-y-3">
                <p>• Each query routes to different specialized models</p>
                <p>• Performance varies dramatically based on routing</p>
                <p>• Success requires learning to route queries effectively</p>
                <p>• Can be both best AND worst performing depending on approach</p>
              </div>
            </div>

            <div className="gradient-accent p-4 rounded-lg">
              <h4 className="text-3xl font-bold text-white mb-2">Core Challenge</h4>
              <p className="text-2xl text-white">Teams must master query routing to unlock GPT-5's potential</p>
            </div>

            <div className="bg-green-500/20 border border-green-500/50 p-4 rounded-lg">
              <h4 className="text-2xl font-bold text-green-300 mb-2">Critical Unlock</h4>
              <p className="text-xl text-green-200">
                Tell the model to <span className="font-bold">'think hard'</span> for complex problems - this invokes thinking mode
              </p>
            </div>
          </div>
        </div>

        {/* Facilitator Guide */}
        <div className="facilitator-notes">
          <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
          <div className="space-y-4 text-base">
            <div>
              <h4 className="font-semibold text-orange-200">Timing: 30 minutes</h4>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-2">Delivery Notes:</h4>
              <ul className="space-y-1 text-gray-200">
                <li>• Share screen showing GPT-5 interface</li>
                <li>• Demonstrate routing concept with live example</li>
                <li>• Use 'think hard' command in real-time</li>
                <li>• Poll audience: Who has noticed performance variations?</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-2">Talk Track:</h4>
              <p className="text-gray-200 italic">
                "How many of you have had GPT-5 give you amazing results one day and disappointing results the next? 
                That's because you're accidentally routing to different models."
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Transition:</h4>
              <p className="text-gray-200">Next: Live demonstration of model routing techniques</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-4 text-base text-gray-400">
        <div className="flex items-center">
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 1: Architecture Mastery • 30 minutes
        </div>
      </div>
    </div>
  );
}
