


export default function Slide13() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-5xl font-bold text-white mb-4">
            Module 3: Data Architecture Practice Session
          </h1>
          <p className="text-3xl text-gray-300 mb-2">45 minutes</p>
          <p className="text-4xl teal-accent font-semibold">Transform business data and master Canvas workflows</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_1fr] gap-6 min-h-0">
          {/* Practice Overview */}
          <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg">
            <h2 className="text-4xl font-bold text-blue-300 mb-4">Practice Session Purpose</h2>
            <p className="text-2xl text-gray-200 mb-4">Apply data architecture principles to real business scenarios.</p>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-3">Materials Provided:</h3>
                <ul className="space-y-2 text-xl text-gray-200">
                  <li>• Data structure templates</li>
                  <li>• Canvas workflow guides</li>
                  <li>• Memory setup checklist</li>
                  <li>• Business scenario examples</li>
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-200 mb-3">Expected Outcomes:</h3>
                <ul className="space-y-2 text-xl text-gray-200">
                  <li>• Optimized data structure for GPT-5</li>
                  <li>• Functional Canvas workflow</li>
                  <li>• Personalized Memory settings</li>
                  <li>• Measurable AI output improvement</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[1fr_1fr] gap-6 min-h-0">
            {/* Structured Exercises */}
            <div className="flex flex-col space-y-4">
              <h2 className="text-4xl font-bold teal-accent">Practice Exercises</h2>
              
              <div className="flex-1 flex flex-col gap-4">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-green-300 mb-1">Exercise 1: Data Optimization (20m)</h3>
                  <p className="text-lg text-gray-300">
                    <span className="font-semibold">Task:</span> Restructure a document using the multi-dimensional framework.
                  </p>
                  <p className="text-base text-white/80 mt-2">Deliverable: Dataset optimized for 400K token processing.</p>
                </div>

                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-purple-300 mb-1">Exercise 2: Canvas Setup (15m)</h3>
                  <p className="text-lg text-gray-300">
                    <span className="font-semibold">Task:</span> Create a Canvas for a recurring business process.
                  </p>
                  <p className="text-base text-white/80 mt-2">Deliverable: Canvas workflow for executive documents.</p>
                </div>

                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-4 rounded">
                  <h3 className="text-2xl font-bold text-orange-300 mb-1">Exercise 3: Memory Config (10m)</h3>
                  <p className="text-lg text-gray-300">
                    <span className="font-semibold">Task:</span> Configure Memory with business-specific context.
                  </p>
                  <p className="text-base text-white/80 mt-2">Deliverable: AI assistant personalized with business context.</p>
                </div>
              </div>
            </div>

            {/* Facilitator Guide */}
            <div className="flex flex-col space-y-4">
              <h3 className="text-2xl font-bold text-orange-300">Facilitator Guide</h3>
              <div className="flex-1 flex flex-col gap-4 text-base text-gray-200">
                <div>
                  <h4 className="font-semibold text-orange-200">Timing Breakdown:</h4>
                  <p>5m Setup, 20m Data optimization, 15m Canvas, 10m Memory config.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Facilitation Approach:</h4>
                  <p>Use breakout rooms with facilitator check-ins.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Common Challenges:</h4>
                  <p>Underestimating data structure, Canvas vs. regular chat confusion.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Troubleshooting:</h4>
                   <p>Provide templates for reference and show before/after results.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Quality Check & Wrap-up:</h4>
                  <p>Verify measurable improvement in AI output, then share key insights.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
