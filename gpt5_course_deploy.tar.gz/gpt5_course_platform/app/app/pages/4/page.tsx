


export default function Slide4() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-6xl font-bold mb-4 text-white">
            Activating GPT-5's Advanced Capabilities
          </h1>
          <p className="text-3xl text-orange-300 font-bold mb-2">From Basic Prompts to Specification-Driven AI</p>
          <p className="text-2xl text-gray-300">The Executive's New Paradigm</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-cols-[3fr_1fr] gap-8 min-h-0">
          {/* Left Column */}
          <div className="flex flex-col space-y-6">
            {/* Old vs New Approach */}
            <div className="grid grid-cols-2 gap-6 flex-none">
              <div className="bg-red-500/20 border-l-4 border-red-500 p-6 rounded-lg">
                <h2 className="text-3xl font-bold text-red-300 mb-4">❌ Old Approach (GPT-4)</h2>
                <div className="space-y-3 text-xl text-gray-200">
                  <p><span className="font-semibold">Method:</span> Conversational prompts</p>
                  <p><span className="font-semibold">Example:</span> "Help me analyze our sales data"</p>
                  <p><span className="font-semibold">Result:</span> Generic, surface-level response</p>
                  <p><span className="font-semibold">Business Value:</span> Limited, requires multiple iterations</p>
                </div>
              </div>
              
              <div className="bg-green-500/20 border-l-4 border-green-500 p-6 rounded-lg">
                <h2 className="text-3xl font-bold text-green-300 mb-4">✅ New Approach (GPT-5)</h2>
                <div className="space-y-3 text-xl text-gray-200">
                  <p><span className="font-semibold">Method:</span> Specification-driven prompts</p>
                  <p><span className="font-semibold">Example:</span> "Create a comprehensive sales analysis..."</p>
                  <p><span className="font-semibold">Result:</span> Professional-grade analysis with artifacts</p>
                  <p><span className="font-semibold">Business Value:</span> Board-ready output in one iteration</p>
                </div>
              </div>
            </div>

            {/* Activation Methods */}
            <div className="bg-blue-500/20 border border-blue-500/50 p-6 rounded-lg flex-1 min-h-0">
              <h2 className="text-4xl font-bold text-blue-300 mb-4">3 Ways to Activate Advanced Capabilities</h2>
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="gradient-accent p-4 rounded-lg mb-3">
                    <h3 className="text-2xl font-bold text-white mb-2">1. Model Routing</h3>
                  </div>
                  <p className="text-xl text-gray-200">Direct complex tasks to GPT-5 Pro automatically</p>
                </div>
                
                <div className="text-center">
                  <div className="gradient-accent p-4 rounded-lg mb-3">
                    <h3 className="text-2xl font-bold text-white mb-2">2. "Think Hard" Mode</h3>
                  </div>
                  <p className="text-xl text-gray-200">Activate deeper reasoning for critical decisions</p>
                </div>
                
                <div className="text-center">
                  <div className="gradient-accent p-4 rounded-lg mb-3">
                    <h3 className="text-2xl font-bold text-white mb-2">3. Specification Writing</h3>
                  </div>
                  <p className="text-xl text-gray-200">Define exactly what you need, not how to get it</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Facilitator Guide */}
          <div className="facilitator-notes">
            <h3 className="text-2xl font-bold mb-4 text-orange-300">Facilitator Guide</h3>
            <div className="space-y-4 text-base">
              <div>
                <h4 className="font-semibold text-orange-200">Timing: 25 minutes</h4>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Demo Setup:</h4>
                <p className="text-gray-200">Live comparison of old vs new approach using participant's business scenario.</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Interactive Elements:</h4>
                <ul className="text-gray-200 space-y-1">
                  <li>• Poll: "Who still uses ChatGPT like a search engine?"</li>
                  <li>• Show before/after examples</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Key Breakthrough Moment:</h4>
                <p className="text-gray-200 italic">"You're not asking for help anymore—you're delegating professional work."</p>
              </div>
              <div>
                <h4 className="font-semibold text-orange-200">Transition Setup:</h4>
                <p className="text-gray-200">Next slide shows hands-on practice with these three activation methods.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-6 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 1: Activation Methods • 25 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
