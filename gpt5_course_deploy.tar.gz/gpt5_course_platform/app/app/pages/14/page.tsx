


export default function Slide14() {
  return (
    <div className="slide-container flex flex-col h-full">
      <div className="grid grid-cols-[3fr_1fr] gap-4 flex-grow min-h-0">
        
        {/* Left Column */}
        <div className="flex flex-col gap-4 min-h-0">
          {/* Module Completion */}
          <div className="gradient-accent p-4 rounded-lg text-center">
            <h1 className="text-3xl font-bold text-white mb-3">Module 3: Data Architecture Complete</h1>
            <div className="grid grid-cols-4 gap-3 text-white">
              <div>
                <h3 className="text-base font-bold mb-1">✅ Mastered</h3>
                <p className="text-sm">400K token context optimization</p>
              </div>
              <div>
                <h3 className="text-base font-bold mb-1">✅ Learned</h3>
                <p className="text-sm">Canvas collaborative workflows</p>
              </div>
              <div>
                <h3 className="text-base font-bold mb-1">✅ Implemented</h3>
                <p className="text-sm">Memory-driven personalization</p>
              </div>
              <div>
                <h3 className="text-base font-bold mb-1">✅ Built</h3>
                <p className="text-sm">Multi-dimensional data structures</p>
              </div>
            </div>
            <div className="mt-3 bg-white/20 p-2 rounded">
              <h3 className="text-lg font-bold text-yellow-300 mb-1">Business Readiness</h3>
              <p className="text-sm text-white">Team equipped to transform organizational data architecture.</p>
            </div>
          </div>

          {/* Security & Implementation Row */}
          <div className="grid grid-cols-2 gap-4 flex-grow min-h-0">
            {/* Security Framework */}
            <div className="space-y-3 bg-gray-800/50 p-3 rounded-lg">
              <h2 className="text-2xl font-bold text-red-300">Data Security & Governance</h2>
              <div className="bg-red-500/20 p-2 rounded">
                <h3 className="text-lg font-bold text-red-300 mb-1">Key Risks</h3>
                <ul className="space-y-1 text-sm text-gray-200">
                  <li>• Sensitive data in large context windows</li>
                  <li>• Persistent business context in Memory</li>
                  <li>• Confidential info in Canvas documents</li>
                </ul>
              </div>
              <div className="bg-yellow-500/20 p-2 rounded">
                <h3 className="text-lg font-bold text-yellow-300 mb-1">Mitigation</h3>
                <ul className="space-y-1 text-sm text-gray-200">
                  <li>• Establish data classification policies</li>
                  <li>• Implement access controls for Memory</li>
                  <li>• Create Canvas sharing protocols</li>
                </ul>
              </div>
              <div className="gradient-accent p-2 rounded text-center">
                <h3 className="text-base font-bold text-white">Executive Responsibility</h3>
                <p className="text-sm text-white">Balance AI capability with data protection.</p>
              </div>
            </div>

            {/* Implementation Strategy */}
            <div className="space-y-3 bg-gray-800/50 p-3 rounded-lg">
              <h2 className="text-2xl font-bold teal-accent">Architecture Rollout</h2>
              <div className="space-y-2">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-2 rounded">
                  <h3 className="text-base font-bold text-green-300">Phase 1 (30d):</h3>
                  <p className="text-sm text-gray-200">Pilot with non-sensitive data</p>
                </div>
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-2 rounded">
                  <h3 className="text-base font-bold text-blue-300">Phase 2 (60d):</h3>
                  <p className="text-sm text-gray-200">Develop governance framework</p>
                </div>
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-2 rounded">
                  <h3 className="text-base font-bold text-purple-300">Phase 3 (90d):</h3>
                  <p className="text-sm text-gray-200">Scale with approved data types</p>
                </div>
              </div>
              <div className="bg-orange-500/20 p-2 rounded">
                <h3 className="text-lg font-bold text-orange-300 mb-1">Success Metrics</h3>
                <ul className="space-y-1 text-sm text-gray-200">
                  <li>• Faster AI-driven analysis</li>
                  <li>• Improved quality of insights</li>
                  <li>• Increased team adoption</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Facilitator Guide */}
        <div className="facilitator-notes bg-gray-800/50 p-3 rounded-lg flex flex-col">
          <h3 className="text-xl font-bold mb-3 text-orange-300 text-center">Facilitator Guide</h3>
          <div className="space-y-2 text-sm flex-grow">
            <div>
              <h4 className="font-semibold text-orange-200">Timing: 25 minutes total</h4>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200 mb-1">Discussion Points:</h4>
              <ul className="space-y-1 text-gray-200 list-disc list-inside">
                <li>Summarize key capabilities (10 min)</li>
                <li>Address security concerns (10 min)</li>
                <li>Transition to Module 4 (5 min)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Key Message:</h4>
              <p className="text-gray-200">Balance excitement for new capabilities with responsible, secure usage.</p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-200">Anticipated Q&A:</h4>
              <ul className="space-y-1 text-gray-200 list-disc list-inside">
                <li>Data governance policies</li>
                <li>Implementation timelines</li>
                <li>Security best practices</li>
              </ul>
            </div>
            <div className="mt-auto pt-3">
              <h4 className="font-semibold text-orange-200">Transition:</h4>
              <p className="text-gray-200">Module 4 will demonstrate high-value business applications.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-3 text-base text-gray-400">
        <div className="flex items-center">
          <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
        </div>
        <div className="module-progress">
          Module 3 Complete • Break: 10 minutes • Module 4: Business Applications
        </div>
      </div>
    </div>
  );
}
