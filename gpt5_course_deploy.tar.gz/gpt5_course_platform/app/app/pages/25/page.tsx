


export default function Slide25() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-3">
          <div className="gradient-accent p-2 rounded-lg inline-block mb-2">
            <h1 className="text-4xl font-bold text-white">Module 6</h1>
          </div>
          <h2 className="text-5xl font-bold mb-2 text-white">Organizational Implementation Strategy</h2>
          <p className="text-2xl text-gray-300 mb-1">1.5 Hours</p>
          <p className="text-3xl teal-accent font-semibold">Leading AI Transformation in Your Organization</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-rows-[auto_auto_1fr] gap-3 min-h-0">
          {/* Implementation Framework */}
          <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-gray-500/50 p-3 rounded-lg">
            <h2 className="text-2xl font-bold text-white mb-2 text-center">The GPT-5 Transformation Framework</h2>
            <div className="grid grid-cols-4 gap-2">
              <div className="bg-white/10 p-2 rounded text-center">
                <h3 className="text-lg font-bold text-green-300 mb-1">Phase 1 (30 days)</h3>
                <p className="text-sm text-gray-200">Executive Pilot: Leaders demo advanced capabilities.</p>
              </div>
              <div className="bg-white/10 p-2 rounded text-center">
                <h3 className="text-lg font-bold text-blue-300 mb-1">Phase 2 (60 days)</h3>
                <p className="text-sm text-gray-200">Department Champions: Train power users.</p>
              </div>
              <div className="bg-white/10 p-2 rounded text-center">
                <h3 className="text-lg font-bold text-purple-300 mb-1">Phase 3 (90 days)</h3>
                <p className="text-sm text-gray-200">Org-wide Rollout: Scale with governance.</p>
              </div>
              <div className="bg-white/10 p-2 rounded text-center">
                <h3 className="text-lg font-bold text-orange-300 mb-1">Success Metrics</h3>
                <ul className="text-xs text-gray-200 list-disc list-inside">
                  <li>Adoption rate</li>
                  <li>Quality improvement</li>
                  <li>ROI measurement</li>
                </ul>
              </div>
            </div>
            <div className="gradient-accent p-2 rounded text-center mt-2">
              <p className="text-lg font-bold text-white">Change Management: Focus on capability building, not tool replacement.</p>
            </div>
          </div>

          {/* Leadership Requirements */}
          <div className="bg-red-500/20 border border-red-500/50 p-3 rounded-lg">
            <h2 className="text-2xl font-bold text-red-300 mb-2 text-center">Executive Leadership for AI Transformation</h2>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <ul className="space-y-1 text-gray-200">
                <li><span className="font-bold text-red-200">Specificity Mandate:</span> Specify HOW AI was used.</li>
                <li><span className="font-bold text-red-200">Training Investment:</span> Boost quality assessment skills.</li>
                <li><span className="font-bold text-red-200">Failure Permission:</span> Encourage experimentation.</li>
              </ul>
              <ul className="space-y-1 text-gray-200">
                <li><span className="font-bold text-red-200">Use Case Definition:</span> Define new business applications.</li>
                <li><span className="font-bold text-red-200">Quality Standards:</span> Define good AI-generated work.</li>
                <li><span className="font-bold text-red-200">Cultural Shift:</span> Move to methodology & artifacts.</li>
              </ul>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-[2fr_1fr] gap-3 min-h-0">
            {/* Strategic Implementation */}
            <div className="flex flex-col space-y-2">
              <h2 className="text-2xl font-bold teal-accent">90-Day Organizational Rollout Plan</h2>
              <div className="grid grid-cols-2 gap-2 flex-1">
                <div className="bg-green-500/20 border-l-4 border-green-500 p-2 rounded">
                  <h3 className="text-base font-bold text-green-300">Week 1-4:</h3>
                  <p className="text-xs text-gray-200">Executive team masters spec writing.</p>
                </div>
                <div className="bg-blue-500/20 border-l-4 border-blue-500 p-2 rounded">
                  <h3 className="text-base font-bold text-blue-300">Week 5-8:</h3>
                  <p className="text-xs text-gray-200">Dept leaders build prompt libraries.</p>
                </div>
                <div className="bg-purple-500/20 border-l-4 border-purple-500 p-2 rounded">
                  <h3 className="text-base font-bold text-purple-300">Week 9-12:</h3>
                  <p className="text-xs text-gray-200">Pilot apps with success measurement.</p>
                </div>
                <div className="bg-orange-500/20 border-l-4 border-orange-500 p-2 rounded">
                  <h3 className="text-base font-bold text-orange-300">Month 2:</h3>
                  <p className="text-xs text-gray-200">Scale apps, develop governance.</p>
                </div>
                <div className="bg-red-500/20 border-l-4 border-red-500 p-2 rounded">
                  <h3 className="text-base font-bold text-red-300">Month 3:</h3>
                  <p className="text-xs text-gray-200">Org-wide training & knowledge sharing.</p>
                </div>
                <div className="bg-teal-500/20 border-l-4 border-teal-500 p-2 rounded">
                  <h3 className="text-base font-bold text-teal-300">Sustainability:</h3>
                  <p className="text-xs text-gray-200">Build internal expertise & CI processes.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="gradient-accent p-2 rounded text-center">
                  <h3 className="text-base font-bold text-white">Competitive Edge</h3>
                  <p className="text-xs text-white">Early adopters gain benefits.</p>
                </div>
                <div className="gradient-accent p-2 rounded text-center">
                  <h3 className="text-base font-bold text-white">ROI Tracking</h3>
                  <p className="text-xs text-white">Measure savings & impact.</p>
                </div>
              </div>
            </div>

            {/* Course Completion Guide */}
            <div className="facilitator-notes p-3 rounded-lg bg-gray-800/50">
              <h3 className="text-lg font-bold mb-2 text-orange-300">Course Completion Guide</h3>
              <div className="space-y-1 text-sm">
                <div>
                  <h4 className="font-semibold text-orange-200">Session: 90 min</h4>
                  <ul className="list-disc list-inside text-xs text-gray-200">
                    <li>Planning (30 min)</li>
                    <li>Action Plan (45 min)</li>
                    <li>Wrap-up (15 min)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Final Exercise:</h4>
                  <p className="text-xs text-gray-200">Create a 90-day transformation plan.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Resources:</h4>
                  <ul className="list-disc list-inside text-xs text-gray-200">
                    <li>Templates & Frameworks</li>
                    <li>Training Curricula</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Support:</h4>
                   <p className="text-xs text-gray-200">30-day coaching & community access.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-200">Success Validation:</h4>
                  <p className="text-xs text-gray-200 font-semibold">Leave with an actionable roadmap.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-2 text-sm text-gray-400">
          <div className="flex items-center space-x-2">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Complete: Executive GPT-5 Mastery Course • 13 Hours • 6 Modules
          </div>
        </div>
      </div>
    </div>
  );
}
