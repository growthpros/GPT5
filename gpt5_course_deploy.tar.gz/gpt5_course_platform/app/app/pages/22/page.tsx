


export default function Slide22() {
  return (
    <div className="slide-container">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-none text-center mb-6">
          <h1 className="text-5xl font-bold text-white mb-3">
            Live Application Building Demo
          </h1>
          <p className="text-3xl text-gray-300">From Excel to Interactive Business Dashboard in 15 Minutes</p>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-cols-[1fr_1fr] gap-8 min-h-0">
          {/* Live Demo Process */}
          <div className="space-y-4 flex flex-col">
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-gray-500/50 p-4 rounded-lg text-center">
              <h2 className="text-3xl font-bold text-white mb-2">Executive Project Dashboard</h2>
              <p className="text-xl text-gray-300">Source: Excel file with tasks, dates, and resources.</p>
            </div>
            
            <div className="space-y-3 flex-1 flex flex-col justify-around">
              <div className="bg-green-500/20 border-l-4 border-green-500 p-3 rounded">
                <h3 className="text-2xl font-bold text-green-300">Step 1: Define Requirements (2 min)</h3>
                <p className="text-lg text-gray-200">
                  <span className="font-semibold text-green-300">Needs:</span> Gantt chart, status overview, resource view.
                </p>
              </div>

              <div className="bg-blue-500/20 border-l-4 border-blue-500 p-3 rounded">
                <h3 className="text-2xl font-bold text-blue-300">Step 2: GPT-5 Generation (8 min)</h3>
                <p className="text-lg text-gray-200">
                  <span className="font-semibold text-blue-300">Process:</span> Natural language prompt → Full application code.
                </p>
              </div>

              <div className="bg-purple-500/20 border-l-4 border-purple-500 p-3 rounded">
                <h3 className="text-2xl font-bold text-purple-300">Step 3: Business Customization (5 min)</h3>
                <p className="text-lg text-gray-200">
                  <span className="font-semibold text-purple-300">Adjust:</span> Branding, key metrics, UI tweaks.
                </p>
              </div>
            </div>

            <div className="gradient-accent p-4 rounded-lg text-center">
              <h3 className="text-2xl font-bold text-white">Final Result:</h3>
              <p className="text-xl text-white">A professional, team-ready business application.</p>
            </div>
          </div>

          {/* Facilitator Guide */}
          <div className="facilitator-notes bg-gray-800/50 border border-gray-500/50 p-6 rounded-lg space-y-3">
            <h3 className="text-2xl font-bold text-center text-orange-300">Facilitator Demo Guide</h3>
            <div className="space-y-3 text-base text-gray-200">
                <p><span className="font-semibold text-orange-200">Total Time:</span> 40 minutes.</p>
                <p><span className="font-semibold text-orange-200">Setup:</span> Have Excel & GPT-5 interface ready.</p>
                <ul className="list-disc list-inside space-y-1">
                  <li><span className="font-semibold text-orange-200">Script:</span> Show Excel, state requirements, generate live, customize with audience input.</li>
                  <li><span className="font-semibold text-orange-200">Engagement:</span> Ask for feature ideas, let them suggest customizations.</li>
                  <li><span className="font-semibold text-orange-200">Troubleshooting:</span> If issues arise, frame it as part of the iterative process.</li>
                  <li><span className="font-semibold text-orange-200">Key Messages:</span> Highlight development speed, business-driven results, and IT independence.</li>
                  <li><span className="font-semibold text-orange-200">"Wow" Moments:</span> Showcase the functional Gantt chart and real-time data updates.</li>
                </ul>
                <p><span className="font-semibold text-orange-200">Transition:</span> "Next, we'll explore other application types..."</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none flex justify-between items-center mt-4 text-base text-gray-400">
          <div className="flex items-center">
            <span>© 2025 Growth Partner Pros. All Rights Reserved.</span>
          </div>
          <div className="module-progress">
            Module 5: Live Application Building • 40 minutes
          </div>
        </div>
      </div>
    </div>
  );
}
