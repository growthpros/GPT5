
import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const { email, password, firstName, lastName, inviteCode } = await request.json()

    if (!email || !password || !firstName) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User already exists' },
        { status: 400 }
      )
    }

    // If invite code is provided, validate it
    if (inviteCode) {
      const invite = await prisma.invitationCode.findUnique({
        where: { code: inviteCode }
      })

      if (!invite) {
        return NextResponse.json(
          { error: 'Invalid invitation code' },
          { status: 400 }
        )
      }

      if (invite.isUsed) {
        return NextResponse.json(
          { error: 'Invitation code has already been used' },
          { status: 400 }
        )
      }

      if (invite.expiresAt && invite.expiresAt < new Date()) {
        return NextResponse.json(
          { error: 'Invitation code has expired' },
          { status: 400 }
        )
      }

      if (invite.email && invite.email !== email) {
        return NextResponse.json(
          { error: 'This invitation code is for a different email address' },
          { status: 400 }
        )
      }

      // Mark invite as used
      await prisma.invitationCode.update({
        where: { code: inviteCode },
        data: {
          isUsed: true,
          usedBy: email,
          usedAt: new Date()
        }
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name: `${firstName} ${lastName || ''}`.trim(),
        invitedBy: inviteCode || null,
      }
    })

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      }
    })
  } catch (error) {
    console.error('Signup error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
