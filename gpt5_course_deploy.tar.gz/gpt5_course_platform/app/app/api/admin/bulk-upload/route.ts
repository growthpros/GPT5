
import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export const dynamic = 'force-dynamic'

function generateInviteCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = ''
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    const text = await file.text()
    const lines = text.split('\n').filter(line => line.trim())
    
    if (lines.length < 2) {
      return NextResponse.json({ error: 'CSV must have at least a header and one data row' }, { status: 400 })
    }

    const headers = lines[0].split(',').map(h => h.trim())
    const requiredHeaders = ['firstName', 'lastName', 'email']
    
    if (!requiredHeaders.every(h => headers.includes(h))) {
      return NextResponse.json({ 
        error: `CSV must have headers: ${requiredHeaders.join(', ')}` 
      }, { status: 400 })
    }

    const results = {
      success: true,
      processed: 0,
      created: 0,
      skipped: 0,
      errors: [] as string[],
      inviteCodes: [] as any[]
    }

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim())
      const userData: any = {}
      
      headers.forEach((header, index) => {
        userData[header] = values[index] || ''
      })

      results.processed++

      if (!userData.email || !userData.firstName) {
        results.errors.push(`Line ${i + 1}: Missing required fields`)
        continue
      }

      // Check if user already exists
      const existingUser = await prisma.user.findUnique({
        where: { email: userData.email }
      })

      if (existingUser) {
        results.skipped++
        continue
      }

      // Generate invitation code for new user
      let code = generateInviteCode()
      let attempts = 0
      while (attempts < 10) {
        const existing = await prisma.invitationCode.findUnique({
          where: { code }
        })
        if (!existing) break
        code = generateInviteCode()
        attempts++
      }

      if (attempts >= 10) {
        results.errors.push(`Line ${i + 1}: Could not generate unique invitation code`)
        continue
      }

      // Set expiration to 30 days from now
      const expiresAt = new Date()
      expiresAt.setDate(expiresAt.getDate() + 30)

      // Create invitation code
      await prisma.invitationCode.create({
        data: {
          code,
          email: userData.email,
          expiresAt,
          createdBy: session.user.email,
        }
      })

      results.created++
      results.inviteCodes.push({
        email: userData.email,
        code,
        name: `${userData.firstName} ${userData.lastName || ''}`.trim()
      })
    }

    return NextResponse.json(results)
  } catch (error) {
    console.error('Bulk upload error:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}
