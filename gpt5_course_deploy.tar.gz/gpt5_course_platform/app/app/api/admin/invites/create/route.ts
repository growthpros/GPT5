
import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export const dynamic = 'force-dynamic'

function generateInviteCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = ''
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { email } = await request.json()

    // Generate unique code
    let code = generateInviteCode()
    let attempts = 0
    while (attempts < 10) {
      const existing = await prisma.invitationCode.findUnique({
        where: { code }
      })
      if (!existing) break
      code = generateInviteCode()
      attempts++
    }

    if (attempts >= 10) {
      return NextResponse.json({ error: 'Could not generate unique code' }, { status: 500 })
    }

    // Set expiration to 30 days from now
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 30)

    const invite = await prisma.invitationCode.create({
      data: {
        code,
        email: email || null,
        expiresAt,
        createdBy: session.user.email,
      }
    })

    return NextResponse.json({ invite })
  } catch (error) {
    console.error('Error creating invite code:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
