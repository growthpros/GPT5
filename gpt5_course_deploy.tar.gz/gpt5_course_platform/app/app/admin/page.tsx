
'use client'
import { useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'
import { Users, UserPlus, Mail, BarChart3, Shield, Settings, Activity, Download, Upload } from 'lucide-react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface User {
  id: string
  name: string | null
  email: string
  role: string
  isActive: boolean
  createdAt: string
  lastLoginAt: string | null
}

interface InviteCode {
  id: string
  code: string
  email: string | null
  isUsed: boolean
  usedBy: string | null
  expiresAt: string | null
  createdAt: string
}

export default function AdminDashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [inviteCodes, setInviteCodes] = useState<InviteCode[]>([])
  const [activeTab, setActiveTab] = useState('users')
  const [loading, setLoading] = useState(true)
  const [newInviteEmail, setNewInviteEmail] = useState('')

  useEffect(() => {
    if (status === 'loading') return

    if (!session) {
      router.push('/auth/login')
      return
    }

    // Check if user is admin (you'll need to set this up)
    fetchUsers()
    fetchInviteCodes()
  }, [session, status])

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/users')
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchInviteCodes = async () => {
    try {
      const response = await fetch('/api/admin/invites')
      if (response.ok) {
        const data = await response.json()
        setInviteCodes(data.invites)
      }
    } catch (error) {
      console.error('Error fetching invite codes:', error)
    }
  }

  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const response = await fetch('/api/admin/users/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, isActive: !currentStatus })
      })
      
      if (response.ok) {
        fetchUsers() // Refresh the list
      }
    } catch (error) {
      console.error('Error toggling user status:', error)
    }
  }

  const createInviteCode = async () => {
    if (!newInviteEmail) return

    try {
      const response = await fetch('/api/admin/invites/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newInviteEmail })
      })
      
      if (response.ok) {
        setNewInviteEmail('')
        fetchInviteCodes()
      }
    } catch (error) {
      console.error('Error creating invite code:', error)
    }
  }

  const exportUsers = () => {
    const csv = [
      'Name,Email,Role,Status,Created,Last Login',
      ...users.map(user => 
        `"${user.name || ''}","${user.email}","${user.role}","${user.isActive ? 'Active' : 'Inactive'}","${new Date(user.createdAt).toLocaleDateString()}","${user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleDateString() : 'Never'}"`
      )
    ].join('\n')

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'course-users.csv'
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{backgroundColor: '#0A2044'}}>
        <div className="text-white">Loading Admin Dashboard...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">GPT-5 Course Admin</h1>
            <p className="text-gray-300">User Management & Analytics</p>
          </div>
          <div className="flex items-center space-x-2 text-white">
            <Shield className="h-5 w-5" />
            <span>Admin: {session?.user?.email}</span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-r from-blue-500/20 to-blue-600/20 border border-blue-500/30 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-300 text-sm">Total Users</p>
                <p className="text-white text-2xl font-bold">{users.length}</p>
              </div>
              <Users className="h-8 w-8 text-blue-400" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-500/20 to-green-600/20 border border-green-500/30 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-300 text-sm">Active Users</p>
                <p className="text-white text-2xl font-bold">{users.filter(u => u.isActive).length}</p>
              </div>
              <Activity className="h-8 w-8 text-green-400" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-500/20 to-orange-600/20 border border-orange-500/30 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-300 text-sm">Invite Codes</p>
                <p className="text-white text-2xl font-bold">{inviteCodes.length}</p>
              </div>
              <Mail className="h-8 w-8 text-orange-400" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 border border-purple-500/30 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Used Invites</p>
                <p className="text-white text-2xl font-bold">{inviteCodes.filter(i => i.isUsed).length}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-400" />
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-2 mb-8">
          {[
            { id: 'users', label: 'User Management', icon: Users },
            { id: 'invites', label: 'Invitation Codes', icon: UserPlus },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-orange-500 text-white'
                  : 'bg-white/10 text-gray-300 hover:bg-white/15'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        {activeTab === 'users' && (
          <div className="bg-white/5 rounded-lg p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">User Management</h2>
              <div className="flex space-x-3">
                <Link
                  href="/admin/bulk-upload"
                  className="flex items-center space-x-2 px-4 py-2 bg-orange-600 hover:bg-orange-700 rounded-lg transition-colors"
                >
                  <Upload className="h-4 w-4 text-white" />
                  <span className="text-white">Bulk Upload</span>
                </Link>
                <button
                  onClick={exportUsers}
                  className="flex items-center space-x-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors"
                >
                  <Download className="h-4 w-4 text-white" />
                  <span className="text-white">Export CSV</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-gray-600">
                    <th className="text-gray-300 pb-3">Name</th>
                    <th className="text-gray-300 pb-3">Email</th>
                    <th className="text-gray-300 pb-3">Role</th>
                    <th className="text-gray-300 pb-3">Status</th>
                    <th className="text-gray-300 pb-3">Created</th>
                    <th className="text-gray-300 pb-3">Last Login</th>
                    <th className="text-gray-300 pb-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-b border-gray-700">
                      <td className="text-white py-3">{user.name || 'N/A'}</td>
                      <td className="text-white py-3">{user.email}</td>
                      <td className="text-white py-3">
                        <span className={`px-2 py-1 rounded text-xs ${
                          user.role === 'admin' ? 'bg-red-500/20 text-red-300' : 'bg-blue-500/20 text-blue-300'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="text-white py-3">
                        <span className={`px-2 py-1 rounded text-xs ${
                          user.isActive ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'
                        }`}>
                          {user.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="text-gray-300 py-3">{new Date(user.createdAt).toLocaleDateString()}</td>
                      <td className="text-gray-300 py-3">{user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleDateString() : 'Never'}</td>
                      <td className="py-3">
                        <button
                          onClick={() => toggleUserStatus(user.id, user.isActive)}
                          className={`px-3 py-1 rounded text-xs transition-colors ${
                            user.isActive 
                              ? 'bg-red-600 hover:bg-red-700 text-white' 
                              : 'bg-green-600 hover:bg-green-700 text-white'
                          }`}
                        >
                          {user.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'invites' && (
          <div className="bg-white/5 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-6">Invitation Codes</h2>

            {/* Create New Invite */}
            <div className="bg-white/5 rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold text-white mb-4">Create New Invitation</h3>
              <div className="flex space-x-4">
                <input
                  type="email"
                  placeholder="Enter email address (optional)"
                  value={newInviteEmail}
                  onChange={(e) => setNewInviteEmail(e.target.value)}
                  className="flex-1 px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-orange-500"
                />
                <button
                  onClick={createInviteCode}
                  className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors"
                >
                  Generate Code
                </button>
              </div>
            </div>

            {/* Invite Codes Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-gray-600">
                    <th className="text-gray-300 pb-3">Code</th>
                    <th className="text-gray-300 pb-3">Email</th>
                    <th className="text-gray-300 pb-3">Status</th>
                    <th className="text-gray-300 pb-3">Used By</th>
                    <th className="text-gray-300 pb-3">Created</th>
                    <th className="text-gray-300 pb-3">Expires</th>
                  </tr>
                </thead>
                <tbody>
                  {inviteCodes.map((invite) => (
                    <tr key={invite.id} className="border-b border-gray-700">
                      <td className="text-white py-3 font-mono">{invite.code}</td>
                      <td className="text-white py-3">{invite.email || 'Any'}</td>
                      <td className="text-white py-3">
                        <span className={`px-2 py-1 rounded text-xs ${
                          invite.isUsed ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'
                        }`}>
                          {invite.isUsed ? 'Used' : 'Active'}
                        </span>
                      </td>
                      <td className="text-gray-300 py-3">{invite.usedBy || 'N/A'}</td>
                      <td className="text-gray-300 py-3">{new Date(invite.createdAt).toLocaleDateString()}</td>
                      <td className="text-gray-300 py-3">{invite.expiresAt ? new Date(invite.expiresAt).toLocaleDateString() : 'Never'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="bg-white/5 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-6">User Analytics</h2>
            <div className="text-gray-300">
              <p>Analytics features coming soon...</p>
              <p className="mt-2">This will include:</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>User login patterns</li>
                <li>Course progress tracking</li>
                <li>Most accessed content</li>
                <li>Time spent in course</li>
                <li>Completion rates</li>
              </ul>
            </div>
          </div>
        )}

        <div className="text-center mt-16 pt-8 border-t border-gray-700">
          <p className="text-xs text-gray-400">© 2025 Growth Partner Pros. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  )
}
