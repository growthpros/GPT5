
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Upload, Download, Users, AlertCircle, CheckCircle } from 'lucide-react'

export default function BulkUploadPage() {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [results, setResults] = useState<any>(null)
  const router = useRouter()

  const downloadTemplate = () => {
    const csv = 'firstName,lastName,email,role\nJohn,Doe,john.doe@company.com,user\nJane,Smith,jane.smith@company.com,user'
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'user-import-template.csv'
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0])
      setResults(null)
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/admin/bulk-upload', {
        method: 'POST',
        body: formData
      })

      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error('Upload error:', error)
      setResults({ success: false, error: 'Upload failed' })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <button
            onClick={() => router.push('/admin')}
            className="text-orange-400 hover:text-orange-300 mb-4"
          >
            ← Back to Admin Dashboard
          </button>
          <h1 className="text-4xl font-bold text-white mb-2">Bulk User Upload</h1>
          <p className="text-gray-300">Upload a CSV file to create multiple user accounts</p>
        </div>

        {/* Instructions */}
        <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-blue-300 mb-4">How to Use</h2>
          <ol className="text-blue-200 space-y-2 list-decimal list-inside">
            <li>Download the CSV template below</li>
            <li>Fill in user information (firstName, lastName, email, role)</li>
            <li>Upload the completed CSV file</li>
            <li>Review the results and invitation codes</li>
          </ol>
        </div>

        {/* Download Template */}
        <div className="bg-white/5 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Step 1: Download Template</h2>
          <button
            onClick={downloadTemplate}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Download CSV Template</span>
          </button>
        </div>

        {/* Upload File */}
        <div className="bg-white/5 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Step 2: Upload CSV File</h2>
          <div className="space-y-4">
            <div>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="block w-full text-gray-300 bg-gray-800 border border-gray-600 rounded-lg cursor-pointer focus:outline-none"
              />
            </div>
            {file && (
              <div className="flex items-center space-x-2 text-gray-300">
                <Users className="h-4 w-4" />
                <span>Selected: {file.name}</span>
              </div>
            )}
            <button
              onClick={handleUpload}
              disabled={!file || uploading}
              className="flex items-center space-x-2 px-6 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-600 text-white rounded-lg transition-colors"
            >
              <Upload className="h-4 w-4" />
              <span>{uploading ? 'Uploading...' : 'Upload Users'}</span>
            </button>
          </div>
        </div>

        {/* Results */}
        {results && (
          <div className="bg-white/5 rounded-lg p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Upload Results</h2>
            {results.success ? (
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-green-300">
                  <CheckCircle className="h-5 w-5" />
                  <span>Successfully processed {results.processed} users</span>
                </div>
                
                {results.created > 0 && (
                  <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
                    <p className="text-green-300 font-semibold">✓ Created {results.created} new users</p>
                  </div>
                )}

                {results.skipped > 0 && (
                  <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4">
                    <p className="text-yellow-300 font-semibold">⚠ Skipped {results.skipped} existing users</p>
                  </div>
                )}

                {results.errors?.length > 0 && (
                  <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4">
                    <p className="text-red-300 font-semibold mb-2">❌ Errors:</p>
                    <ul className="text-red-200 text-sm space-y-1">
                      {results.errors.map((error: string, index: number) => (
                        <li key={index}>• {error}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {results.inviteCodes?.length > 0 && (
                  <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
                    <p className="text-blue-300 font-semibold mb-2">📧 Invitation Codes Generated:</p>
                    <div className="max-h-60 overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-blue-500/30">
                            <th className="text-left text-blue-300 pb-2">Email</th>
                            <th className="text-left text-blue-300 pb-2">Invitation Code</th>
                          </tr>
                        </thead>
                        <tbody>
                          {results.inviteCodes.map((item: any, index: number) => (
                            <tr key={index} className="border-b border-blue-500/10">
                              <td className="text-blue-200 py-1">{item.email}</td>
                              <td className="text-blue-100 font-mono py-1">{item.code}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2 text-red-300">
                <AlertCircle className="h-5 w-5" />
                <span>{results.error || 'Upload failed'}</span>
              </div>
            )}
          </div>
        )}

        <div className="text-center mt-16 pt-8 border-t border-gray-700">
          <p className="text-xs text-gray-400">© 2025 Growth Partner Pros. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  )
}
