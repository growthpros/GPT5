

import Link from 'next/link';
import { ArrowLeft, BookOpen, Clock, Users, Target, CheckSquare, ArrowRight, Lightbulb, AlertTriangle, TrendingUp } from 'lucide-react';

export default function GuidebookPage() {
  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <Link href="/resources" className="inline-flex items-center text-teal-300 hover:text-teal-200 mb-6 transition-colors">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Resources
          </Link>
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-blue-500/20 to-teal-500/20 rounded-lg p-8 mb-8">
              <h1 className="text-5xl font-bold text-white mb-4">Participant Guidebook</h1>
              <p className="text-2xl text-gray-300 mb-4">Complete Reference for GPT-5 Executive Mastery</p>
              <div className="flex items-center justify-center space-x-8">
                <div className="flex items-center">
                  <BookOpen className="h-6 w-6 text-blue-300 mr-2" />
                  <span className="text-blue-300">6 Comprehensive Modules</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-6 w-6 text-teal-300 mr-2" />
                  <span className="text-teal-300">13 Hours Content</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-6 w-6 text-orange-300 mr-2" />
                  <span className="text-orange-300">Executive Level</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="bg-white/5 rounded-lg p-6 mb-12">
          <h2 className="text-2xl font-bold text-white mb-4">Quick Navigation</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <a href="#module1" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-red-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M1</span>
              </div>
              <span className="text-white text-sm text-center">Architecture Mastery</span>
            </a>
            <a href="#module2" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-orange-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M2</span>
              </div>
              <span className="text-white text-sm text-center">Advanced Prompting</span>
            </a>
            <a href="#module3" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-yellow-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M3</span>
              </div>
              <span className="text-white text-sm text-center">Data Architecture</span>
            </a>
            <a href="#module4" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-green-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M4</span>
              </div>
              <span className="text-white text-sm text-center">Business Applications</span>
            </a>
            <a href="#module5" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-blue-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M5</span>
              </div>
              <span className="text-white text-sm text-center">Kitchen Table Software</span>
            </a>
            <a href="#module6" className="flex flex-col items-center p-3 rounded-lg hover:bg-white/10 transition-colors">
              <div className="bg-purple-500 p-2 rounded-lg mb-2">
                <span className="text-white font-bold text-sm">M6</span>
              </div>
              <span className="text-white text-sm text-center">Implementation</span>
            </a>
          </div>
        </div>

        {/* Module 1: GPT-5 Architecture Mastery */}
        <div id="module1" className="mb-16">
          <div className="bg-gradient-to-r from-red-500/20 to-red-600/20 rounded-lg p-8 mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-red-500 p-4 rounded-lg mr-4">
                <Target className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-4xl font-bold text-white">Module 1: GPT-5 Architecture Mastery</h2>
                <p className="text-xl text-red-300">Understanding the Multi-Model Revolution • 2 Hours</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Target className="h-6 w-6 mr-2 text-red-300" />
                Learning Objectives
              </h3>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Understand GPT-5's unique multi-model architecture</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Master the art of model routing through prompting</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Learn the "think hard" activation technique</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Recognize when to use reasoning vs. non-reasoning modes</span>
                </li>
              </ul>
            </div>

            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Clock className="h-6 w-6 mr-2 text-red-300" />
                Key Activities
              </h3>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Live demonstration of GPT-5 vs. GPT-4 performance differences</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Hands-on practice with model routing techniques</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-red-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Interactive exercise: Transform conversational prompts into specifications</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/30 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
              <AlertTriangle className="h-6 w-6 mr-2 text-red-300" />
              Revolutionary Architecture Insight
            </h3>
            <div className="bg-red-500/20 rounded-lg p-6 mb-6">
              <h4 className="text-xl font-bold text-red-200 mb-3">Core Innovation</h4>
              <p className="text-lg text-white mb-4">GPT-5 is fundamentally different - it's <strong>multiple models bundled together</strong>, not a single model.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-semibold text-red-200 mb-2">The Challenge:</h5>
                  <ul className="space-y-2 text-gray-200">
                    <li>• Each query routes to different specialized models</li>
                    <li>• Performance varies dramatically based on routing</li>
                    <li>• Can be both best AND worst performing depending on approach</li>
                    <li>• Teams must learn to route queries effectively</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-red-200 mb-2">The Solution:</h5>
                  <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-4">
                    <p className="text-green-200 font-semibold mb-2">Critical Unlock:</p>
                    <p className="text-white">Tell the model to <span className="bg-green-500 px-2 py-1 rounded text-black font-bold">"think hard"</span> for complex problems - this is a hardcoded password that invokes thinking mode.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-lg p-6">
              <h4 className="text-xl font-bold text-white mb-3">GPT-5 Pro: Parallel Reasoning Engine</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h5 className="font-semibold text-blue-300 mb-2">Inference Time Compute</h5>
                  <p className="text-gray-200">Runs multiple parallel reasoning chains simultaneously</p>
                </div>
                <div>
                  <h5 className="font-semibold text-purple-300 mb-2">Expert Panel Simulation</h5>
                  <p className="text-gray-200">Thinks like a panel of experts debating internally before presenting unified answer</p>
                </div>
                <div>
                  <h5 className="font-semibold text-teal-300 mb-2">Correctness Focus</h5>
                  <p className="text-gray-200">Excels where parallel reasoning serves well and correctness matters critically</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-6">
            <h3 className="text-2xl font-bold text-white mb-4">Implementation Checklist</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-orange-300 mb-3">Immediate Actions:</h4>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Test "think hard" command with complex problems</span>
                  </li>
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Compare GPT-5 Pro vs standard GPT-5 performance</span>
                  </li>
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Identify business use cases needing parallel reasoning</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-teal-300 mb-3">Next Steps:</h4>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Document performance differences in your domain</span>
                  </li>
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Train team on model routing techniques</span>
                  </li>
                  <li className="flex items-center">
                    <input type="checkbox" className="mr-3 scale-125" />
                    <span className="text-gray-200">Create routing guidelines for your organization</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Module 2: Advanced Prompting & Specification Writing */}
        <div id="module2" className="mb-16">
          <div className="bg-gradient-to-r from-orange-500/20 to-yellow-500/20 rounded-lg p-8 mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 p-4 rounded-lg mr-4">
                <Lightbulb className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-4xl font-bold text-white">Module 2: Advanced Prompting & Specification Writing</h2>
                <p className="text-xl text-orange-300">From Conversations to Specifications • 2.5 Hours</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/30 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Lightbulb className="h-6 w-6 mr-2 text-orange-300" />
              The New Prompting Paradigm
            </h3>
            
            <div className="bg-yellow-500/20 rounded-lg p-6 mb-6">
              <h4 className="text-xl font-bold text-yellow-200 mb-4">Master Template for GPT-5 (6-Element Framework):</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-red-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">1</div>
                    <h5 className="font-bold text-red-300">TASK</h5>
                  </div>
                  <p className="text-gray-200 text-sm">Define the task as clearly as possible</p>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">2</div>
                    <h5 className="font-bold text-orange-300">DELIVERABLE</h5>
                  </div>
                  <p className="text-gray-200 text-sm">Define format, length, and audience</p>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-yellow-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">3</div>
                    <h5 className="font-bold text-yellow-300">ASSUMPTIONS</h5>
                  </div>
                  <p className="text-gray-200 text-sm">Specify assumptions in bullets</p>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-green-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">4</div>
                    <h5 className="font-bold text-green-300">NON-GOALS</h5>
                  </div>
                  <p className="text-gray-200 text-sm">Be clear about constraints and what NOT to do</p>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">5</div>
                    <h5 className="font-bold text-blue-300">TOOLS</h5>
                  </div>
                  <p className="text-gray-200 text-sm">What's allowed and forbidden</p>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-purple-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3">6</div>
                    <h5 className="font-bold text-purple-300">ACCEPTANCE</h5>
                  </div>
                  <p className="text-gray-200 text-sm">Specify success criteria</p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-lg p-6">
              <h4 className="text-xl font-bold text-white mb-4">Critical Prompting Elements:</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-semibold text-orange-300 mb-2">Specify Deliverables</h5>
                  <p className="text-gray-200 mb-3">Format, length, audience (prevents over-completion)</p>
                  
                  <h5 className="font-semibold text-blue-300 mb-2">State Context Assumptions</h5>
                  <p className="text-gray-200">Bind scope and timeline assumptions upfront</p>
                </div>
                <div>
                  <h5 className="font-semibold text-green-300 mb-2">Declare Tool Policies</h5>
                  <p className="text-gray-200 mb-3">Control when it can/cannot use web search or code</p>
                  
                  <h5 className="font-semibold text-purple-300 mb-2">Demand Artifacts</h5>
                  <p className="text-gray-200">Force the model to prove its work with supporting materials</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Target className="h-6 w-6 mr-2 text-orange-300" />
                Learning Objectives
              </h3>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Master the 6-element specification template</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Learn artifact-driven prompting techniques</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Understand tool policy management</span>
                </li>
                <li className="flex items-start">
                  <CheckSquare className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Develop organizational prompt libraries</span>
                </li>
              </ul>
            </div>

            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Clock className="h-6 w-6 mr-2 text-orange-300" />
                Key Activities
              </h3>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Workshop: Rewrite existing business prompts using new framework</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Practice session: Demanding artifacts and proof of work</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-orange-300 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Group exercise: Build company-specific prompt library</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-6">
            <h3 className="text-2xl font-bold text-white mb-4">Artifact-Driven Approach</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-orange-300 mb-3">Request These Artifacts:</h4>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <CheckSquare className="h-4 w-4 text-orange-300 mr-2" />
                    <span className="text-gray-200">Python workbooks showing methodology</span>
                  </li>
                  <li className="flex items-center">
                    <CheckSquare className="h-4 w-4 text-orange-300 mr-2" />
                    <span className="text-gray-200">Plain English summaries of rubrics used</span>
                  </li>
                  <li className="flex items-center">
                    <CheckSquare className="h-4 w-4 text-orange-300 mr-2" />
                    <span className="text-gray-200">Personas developed during analysis</span>
                  </li>
                  <li className="flex items-center">
                    <CheckSquare className="h-4 w-4 text-orange-300 mr-2" />
                    <span className="text-gray-200">Executive summaries WITH supporting evidence</span>
                  </li>
                </ul>
              </div>
              <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                <h4 className="font-semibold text-orange-300 mb-3">Why Artifacts Matter:</h4>
                <ul className="space-y-2 text-gray-200">
                  <li>• Forces the model to show its work</li>
                  <li>• Enables verification and validation</li>
                  <li>• Creates reusable methodology</li>
                  <li>• Builds organizational knowledge base</li>
                  <li>• Improves output quality and consistency</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Continue with remaining modules... */}
        <div className="text-center py-8">
          <div className="bg-teal-500/10 border border-teal-500/30 rounded-lg p-6">
            <h3 className="text-2xl font-bold text-white mb-4">More Modules Coming Soon</h3>
            <p className="text-gray-200 mb-6">Complete guidebook continues with:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
              <div>
                <h4 className="font-semibold text-yellow-300">Module 3:</h4>
                <p className="text-gray-300 text-sm">Data Architecture & Canvas Integration</p>
              </div>
              <div>
                <h4 className="font-semibold text-green-300">Module 4:</h4>
                <p className="text-gray-300 text-sm">Business Application Deep Dive</p>
              </div>
              <div>
                <h4 className="font-semibold text-blue-300">Module 5:</h4>
                <p className="text-gray-300 text-sm">Kitchen Table Software Revolution</p>
              </div>
              <div>
                <h4 className="font-semibold text-purple-300">Module 6:</h4>
                <p className="text-gray-300 text-sm">Organizational Implementation Strategy</p>
              </div>
            </div>
            <div className="mt-6">
              <div className="inline-flex items-center bg-gray-600 text-gray-300 px-6 py-3 rounded-lg">
                <BookOpen className="h-5 w-5 mr-2" />
                Complete Guidebook (Coming Soon)
                <ArrowRight className="h-5 w-5 ml-2" />
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-16 pt-8 border-t border-gray-600">
          <Link href="/resources" className="flex items-center text-teal-300 hover:text-teal-200 transition-colors">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Resources
          </Link>
          
          <Link href="/slide-resources" className="flex items-center text-orange-300 hover:text-orange-200 transition-colors">
            Next: Slide Resources
            <ArrowRight className="h-5 w-5 ml-2" />
          </Link>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-gray-300">© 2025 Growth Partner Pros. All Rights Reserved.</p>
          <p className="text-gray-400 mt-2">GPT-5 Executive Mastery Course - Participant Guidebook</p>
        </div>
      </div>
    </div>
  );
}
