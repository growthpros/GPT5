
'use client'
import { useState } from 'react'
import { ChevronRight, Users, TrendingUp, DollarSign, Settings, Heart, Crown, Target, Lightbulb, ArrowRight } from 'lucide-react'
import AuthHeader from '@/components/auth-header'

const businessRoles = [
  {
    id: 'marketing',
    title: 'Marketing Leaders',
    icon: TrendingUp,
    color: 'from-pink-500 to-rose-500',
    description: 'Campaign strategy, content creation, market analysis',
    useCases: [
      {
        title: 'Multi-Channel Campaign Strategy',
        scenario: 'Launch a new product across digital channels',
        prompt: `Think hard about this campaign strategy:

OBJECTIVE: Launch Q1 product across 5 digital channels
AUDIENCE: B2B decision makers, 35-55, $100K+ budget authority
PRODUCT: AI-powered analytics platform for enterprise
CONSTRAINTS: $500K budget, 90-day timeline, compliance requirements
DELIVERABLES: Channel strategy, content calendar, success metrics
CONTEXT: Competitive market with 3 major players, regulatory changes pending

Provide a comprehensive multi-channel strategy with specific tactics, budget allocation, and success metrics for each channel.`,
        expected: 'Comprehensive strategy with channel-specific tactics, budget breakdown, content themes, timing, and measurable KPIs',
        impact: 'Reduces campaign planning time by 80% while improving strategic depth'
      },
      {
        title: 'Customer Persona Deep Analysis',
        scenario: 'Develop detailed personas from customer data',
        prompt: `Using the 6-element framework, analyze customer segments:

SPECIFICATION: Create 3 detailed buyer personas
DATA SOURCE: Customer interviews, survey data, purchase patterns
TARGET OUTCOME: Actionable persona profiles with pain points, motivations, decision criteria
FORMAT: Persona cards with demographics, psychographics, journey maps
CONSTRAINTS: Based on actual data, not assumptions
VALIDATION: Include confidence levels and data sources for each insight

Generate comprehensive personas that marketing and sales can immediately use for targeting and messaging.`,
        expected: 'Detailed persona profiles with pain points, decision criteria, preferred channels, and messaging recommendations',
        impact: 'Improves campaign targeting effectiveness by 65%'
      }
    ]
  },
  {
    id: 'sales',
    title: 'Sales Executives',
    icon: Target,
    color: 'from-green-500 to-emerald-500',
    description: 'Deal strategy, prospect research, competitive analysis',
    useCases: [
      {
        title: 'Enterprise Deal Strategy',
        scenario: 'Complex 7-figure enterprise sales opportunity',
        prompt: `Think hard about this enterprise deal strategy:

OPPORTUNITY: $2.3M software implementation, 18-month sales cycle
STAKEHOLDERS: IT Director (technical), CFO (budget), CEO (vision)
COMPETITION: Two major competitors already presenting
CHALLENGES: Budget frozen until Q2, compliance requirements, integration complexity
YOUR ADVANTAGES: Existing relationship with IT Director, superior integration capabilities
TIMELINE: Final decision in 90 days

Develop a comprehensive sales strategy including stakeholder mapping, value proposition customization, competitive differentiation, and tactical timeline.`,
        expected: 'Detailed sales strategy with stakeholder approach, value props, competitive positioning, and 90-day action plan',
        impact: 'Increases enterprise deal close rate by 45%'
      },
      {
        title: 'Competitive Intelligence Analysis',
        scenario: 'Lost 3 recent deals to new competitor',
        prompt: `Using specification-driven analysis:

SITUATION: Lost 3 major deals to "InnovateTech Solutions" in past 60 days
DATA AVAILABLE: Win/loss interviews, competitor marketing materials, customer feedback
ANALYSIS NEEDED: Competitive positioning, pricing strategy, solution gaps
DELIVERABLE: Action plan to counter competitive threats
URGENCY: High - 5 more deals at risk this quarter
STAKEHOLDERS: Sales team, product management, executive leadership

Provide comprehensive competitive analysis with specific recommendations for sales messaging, product positioning, and tactical responses.`,
        expected: 'Competitive analysis with tactical responses, messaging adjustments, and risk mitigation strategies',
        impact: 'Improves competitive win rate by 35%'
      }
    ]
  },
  {
    id: 'finance',
    title: 'Finance Leaders',
    icon: DollarSign,
    color: 'from-blue-500 to-indigo-500',
    description: 'Financial modeling, risk assessment, strategic planning',
    useCases: [
      {
        title: 'Multi-Scenario Financial Modeling',
        scenario: 'M&A financial impact analysis',
        prompt: `Think hard about this acquisition analysis:

TARGET COMPANY: $50M revenue SaaS company, 35% growth rate
ACQUISITION PRICE: $200M (4x revenue multiple)
SYNERGIES: $15M annual cost savings, $25M revenue acceleration
INTEGRATION COSTS: $30M over 2 years
FINANCIAL STRUCTURE: 60% cash, 40% stock
SCENARIOS: Base case, optimistic (+20% synergies), pessimistic (-30% synergies)

Generate comprehensive financial models for all scenarios including NPV analysis, IRR calculations, sensitivity analysis, and risk assessment.`,
        expected: 'Complete financial models with NPV/IRR analysis, scenario planning, risk factors, and recommendation',
        impact: 'Reduces financial analysis time by 70% while improving accuracy'
      },
      {
        title: 'Cash Flow Optimization Strategy',
        scenario: 'Improve working capital efficiency',
        prompt: `Specification-driven cash flow analysis:

CURRENT STATE: $500M revenue, 45-day DSO, 30-day DPO, $50M inventory
TARGETS: Reduce DSO to 35 days, extend DPO to 40 days, optimize inventory by 20%
CONSTRAINTS: Maintain customer satisfaction, vendor relationships
TOOLS AVAILABLE: ERP system, factoring options, supply chain finance
TIMELINE: 12-month implementation
STAKEHOLDERS: Sales, procurement, operations, treasury

Develop comprehensive working capital optimization strategy with implementation roadmap and impact projections.`,
        expected: 'Working capital strategy with specific tactics, implementation timeline, and financial impact projections',
        impact: 'Improves cash flow by average of $15-25M annually'
      }
    ]
  },
  {
    id: 'operations',
    title: 'Operations Leaders',
    icon: Settings,
    color: 'from-orange-500 to-amber-500',
    description: 'Process optimization, supply chain, efficiency improvements',
    useCases: [
      {
        title: 'Supply Chain Risk Assessment',
        scenario: 'Global supply chain disruption planning',
        prompt: `Think hard about supply chain resilience:

CURRENT NETWORK: 15 suppliers across 8 countries, single-source for 3 critical components
RECENT DISRUPTIONS: COVID lockdowns, semiconductor shortage, Suez Canal blockage
BUSINESS IMPACT: $25M revenue loss, 45-day production delays, customer dissatisfaction
RISK FACTORS: Geopolitical tensions, climate events, economic volatility
CONSTRAINTS: Cost increases <10%, quality standards maintained
TIMELINE: 6-month resilience plan implementation

Develop comprehensive supply chain risk mitigation strategy with supplier diversification, inventory optimization, and contingency planning.`,
        expected: 'Risk assessment with mitigation strategies, supplier diversification plan, and contingency procedures',
        impact: 'Reduces supply chain risk by 60% while optimizing costs'
      },
      {
        title: 'Process Automation Strategy',
        scenario: 'Identify automation opportunities across operations',
        prompt: `Using the 6-element framework for automation analysis:

SCOPE: Manufacturing, logistics, customer service, quality control
CURRENT STATE: 40% manual processes, high error rates, capacity constraints
TECHNOLOGY OPTIONS: RPA, AI/ML, IoT sensors, robotic systems
INVESTMENT BUDGET: $5M over 24 months
SUCCESS METRICS: 30% cost reduction, 50% error reduction, 25% capacity increase
CONSTRAINTS: Union considerations, safety requirements, quality standards

Generate prioritized automation roadmap with ROI analysis, implementation timeline, and change management strategy.`,
        expected: 'Automation roadmap with ROI analysis, technology recommendations, and implementation strategy',
        impact: 'Achieves 25-35% operational efficiency improvements'
      }
    ]
  },
  {
    id: 'hr',
    title: 'HR Leaders',
    icon: Heart,
    color: 'from-purple-500 to-violet-500',
    description: 'Talent strategy, culture transformation, workforce planning',
    useCases: [
      {
        title: 'Strategic Workforce Planning',
        scenario: 'Scale team for 300% growth over 2 years',
        prompt: `Think hard about workforce scaling strategy:

CURRENT TEAM: 150 employees across 4 departments
GROWTH PLAN: 300% revenue growth requiring 450 total employees
CRITICAL ROLES: Engineering (60%), sales (25%), operations (15%)
CHALLENGES: Talent shortage, remote work preferences, budget constraints
LOCATION STRATEGY: Hybrid model, 3 office locations, global remote talent
TIMELINE: 24-month hiring plan with quarterly milestones

Develop comprehensive workforce strategy including hiring plans, compensation benchmarks, talent pipeline development, and organizational design.`,
        expected: 'Workforce plan with hiring timeline, compensation strategy, organizational design, and talent pipeline development',
        impact: 'Reduces time-to-hire by 50% while improving quality of candidates'
      },
      {
        title: 'Culture Transformation Initiative',
        scenario: 'Transform culture for digital-first organization',
        prompt: `Specification-driven culture transformation:

CURRENT CULTURE: Traditional, hierarchical, risk-averse, in-person focused
DESIRED CULTURE: Agile, innovative, data-driven, remote-friendly
BUSINESS DRIVERS: Digital transformation, competitive pressure, talent retention
EMPLOYEE FEEDBACK: 65% satisfaction, desire for flexibility, career development
CONSTRAINTS: $2M budget, 18-month timeline, minimal disruption to operations
STAKEHOLDERS: Executive team, middle management, employee resource groups

Create comprehensive culture transformation strategy with specific initiatives, success metrics, and change management approach.`,
        expected: 'Culture transformation plan with specific initiatives, metrics, communication strategy, and implementation roadmap',
        impact: 'Improves employee satisfaction by 40% and reduces turnover by 30%'
      }
    ]
  },
  {
    id: 'executive',
    title: 'C-Suite Executives',
    icon: Crown,
    color: 'from-red-500 to-pink-500',
    description: 'Strategic planning, digital transformation, board presentations',
    useCases: [
      {
        title: 'Digital Transformation Strategy',
        scenario: 'Lead industry transformation with AI-first approach',
        prompt: `Think hard about digital transformation leadership:

COMPANY: Traditional manufacturing, $2B revenue, 15,000 employees
INDUSTRY PRESSURE: Digital natives disrupting market, margin compression
TRANSFORMATION SCOPE: Operations, customer experience, business models, culture
INVESTMENT: $200M over 3 years with measurable ROI requirements
STAKEHOLDERS: Board of directors, investors, employees, customers, partners
TIMELINE: Board presentation in 30 days, implementation starts Q2

Develop comprehensive digital transformation strategy with AI integration, organizational change management, financial projections, and competitive positioning.`,
        expected: 'Comprehensive transformation strategy with AI roadmap, financial projections, risk assessment, and board-ready presentation',
        impact: 'Positions company as industry leader and improves competitive advantage by 2-3 years'
      },
      {
        title: 'Strategic Market Entry Analysis',
        scenario: 'Enter new geographic market with $100M investment',
        prompt: `Using specification-driven market analysis:

TARGET MARKET: European Union, $5B addressable market
INVESTMENT: $100M over 3 years (facilities, team, marketing, partnerships)
COMPETITION: 2 established players with 60% market share
REGULATORY: GDPR compliance, local partnership requirements
SUCCESS METRICS: $50M revenue by year 3, 15% market share, positive unit economics
RISK FACTORS: Currency fluctuation, regulatory changes, competitive response

Generate comprehensive market entry strategy with go-to-market approach, partnership strategy, financial projections, and risk mitigation plans.`,
        expected: 'Market entry strategy with go-to-market plan, partnership recommendations, financial models, and risk assessment',
        impact: 'Reduces market entry risk by 40% while accelerating revenue timeline by 12 months'
      }
    ]
  }
]

export default function UseCasesPage() {
  const [selectedRole, setSelectedRole] = useState('marketing')
  const [selectedUseCase, setSelectedUseCase] = useState(0)

  const currentRole = businessRoles.find(role => role.id === selectedRole)!
  const currentUseCase = currentRole.useCases[selectedUseCase]

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        <AuthHeader />
        
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">Business Role Use Cases</h1>
          <p className="text-xl text-gray-300">Real-world GPT-5 applications for every business function</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Role Selection */}
          <div className="lg:col-span-1">
            <h3 className="text-xl font-semibold text-white mb-4">Select Your Role</h3>
            <div className="space-y-2">
              {businessRoles.map((role) => {
                const IconComponent = role.icon
                return (
                  <button
                    key={role.id}
                    onClick={() => {
                      setSelectedRole(role.id)
                      setSelectedUseCase(0)
                    }}
                    className={`w-full text-left p-4 rounded-lg transition-all ${
                      selectedRole === role.id 
                        ? `bg-gradient-to-r ${role.color} text-white shadow-lg` 
                        : 'bg-white/10 text-gray-300 hover:bg-white/15'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <IconComponent className="h-5 w-5" />
                      <div>
                        <div className="font-semibold">{role.title}</div>
                        <div className="text-xs opacity-90">{role.description}</div>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Use Case Content */}
          <div className="lg:col-span-3">
            <div className="bg-white/5 rounded-lg p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${currentRole.color}`}>
                  <currentRole.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{currentRole.title}</h2>
                  <p className="text-gray-400">{currentRole.description}</p>
                </div>
              </div>

              {/* Use Case Tabs */}
              <div className="flex space-x-2 mb-6">
                {currentRole.useCases.map((useCase, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedUseCase(index)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      selectedUseCase === index
                        ? 'bg-orange-500 text-white'
                        : 'bg-white/10 text-gray-300 hover:bg-white/15'
                    }`}
                  >
                    Use Case {index + 1}
                  </button>
                ))}
              </div>

              {/* Use Case Details */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">{currentUseCase.title}</h3>
                  <p className="text-gray-300 mb-4">{currentUseCase.scenario}</p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-orange-300 mb-3">GPT-5 Prompt</h4>
                  <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
                    <pre className="text-gray-200 text-sm whitespace-pre-wrap font-mono">
                      {currentUseCase.prompt}
                    </pre>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-teal-300 mb-3">Expected Output</h4>
                  <p className="text-gray-300 bg-gray-800/50 rounded-lg p-4 border border-gray-600">
                    {currentUseCase.expected}
                  </p>
                </div>

                <div className="flex items-center space-x-3 p-4 bg-green-900/20 rounded-lg border border-green-700">
                  <Lightbulb className="h-5 w-5 text-green-400" />
                  <div>
                    <div className="font-semibold text-green-300">Business Impact</div>
                    <div className="text-green-200">{currentUseCase.impact}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-16 pt-8 border-t border-gray-700">
          <p className="text-xs text-gray-400">© 2025 Growth Partner Pros. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  )
}
