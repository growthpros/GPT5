

import Link from 'next/link';
import { ArrowLeft, FileText, Eye, BookOpen, ArrowRight, Clock, Users, Target, Lightbulb } from 'lucide-react';

export default function SlideResourcesPage() {
  const slideResources = [
    {
      id: 1,
      title: "Course Introduction & Overview",
      module: "Introduction",
      duration: "5 minutes",
      keyPoints: [
        "Sets expectations for 13-hour comprehensive course",
        "Emphasizes executive-level advanced capabilities", 
        "Positions as competitive advantage for business leaders",
        "Introduces the concept of 'leaping ahead of 99% of ChatGPT users'"
      ],
      detailedExplanation: "This opening slide establishes the premium positioning of the course and creates urgency around advanced GPT-5 capabilities. The focus on 'business executives' and 'strategic decision makers' reinforces this is not a basic ChatGPT tutorial but advanced techniques for leaders.",
      facilitatorNotes: "Emphasize the exclusive nature of advanced techniques. Poll audience about current GPT usage frustrations.",
      relatedResources: ["Module 1 Deep Dive", "Executive Applications Guide", "ROI Calculation Worksheet"]
    },
    {
      id: 2, 
      title: "GPT-5 Architecture Revolution",
      module: "Module 1",
      duration: "30 minutes",
      keyPoints: [
        "GPT-5 is multiple models bundled together, not a single model",
        "Performance varies dramatically based on query routing",
        "'Think hard' command invokes thinking mode for complex problems",
        "Understanding routing is critical for consistent results"
      ],
      detailedExplanation: "This foundational concept is the most important insight in the entire course. Unlike previous AI models, GPT-5's multi-model architecture means users must learn to route their queries to the appropriate specialized model. This explains why users experience inconsistent results - they're accidentally hitting different models.",
      facilitatorNotes: "Use live demonstration showing same prompt with and without 'think hard' command. Ask audience who has experienced inconsistent results.",
      relatedResources: ["Multi-Model Routing Guide", "'Think Hard' Command Examples", "Architecture Deep Dive"]
    },
    {
      id: 3,
      title: "Data Architecture Fundamentals", 
      module: "Module 3",
      duration: "25 minutes",
      keyPoints: [
        "400,000 token context window enables large dataset processing",
        "Clean data formatting (markdown/CSV) improves performance",
        "Multi-dimensional structure provides multiple analysis perspectives",
        "Cross-references enable temporal and relational analysis"
      ],
      detailedExplanation: "This slide introduces the data preparation strategies that unlock GPT-5's analytical capabilities. The focus on clean formatting and multi-dimensional structure sets up participants for the artifact-driven approaches covered later.",
      facilitatorNotes: "Show examples of well-formatted vs poorly formatted data. Demonstrate the difference in output quality.",
      relatedResources: ["Data Formatting Templates", "Multi-Dimensional Analysis Examples", "Context Window Optimization Guide"]
    },
    {
      id: 4,
      title: "Precision Prompting Practice Session",
      module: "Module 2", 
      duration: "20 minutes",
      keyPoints: [
        "Hands-on transformation of conversational prompts",
        "Application of 6-element specification framework",
        "Before/after quality comparison",
        "Building organizational prompt standards"
      ],
      detailedExplanation: "This practical session allows participants to immediately apply the 6-element framework to their own business prompts. The before/after comparison creates 'aha moments' about prompt quality.",
      facilitatorNotes: "Have participants work in pairs. Use real examples from their businesses. Share standout transformations with the group.",
      relatedResources: ["6-Element Framework Template", "Prompt Transformation Worksheet", "Before/After Examples"]
    },
    {
      id: 5,
      title: "Hands-On Practice Implementation",
      module: "Module 2",
      duration: "25 minutes", 
      keyPoints: [
        "Real-world application of prompting techniques",
        "Individual and group exercises",
        "Peer feedback and refinement",
        "Building confidence with new approaches"
      ],
      detailedExplanation: "Extended practice session that builds on the precision prompting foundation. Participants work with their own use cases to ensure relevance and immediate applicability.",
      facilitatorNotes: "Circulate during exercises. Help participants overcome specific challenges. Encourage sharing of unique applications.",
      relatedResources: ["Practice Exercise Templates", "Peer Review Guidelines", "Common Challenges & Solutions"]
    }
  ];

  return (
    <div className="min-h-screen" style={{backgroundColor: '#0A2044'}}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <Link href="/resources" className="inline-flex items-center text-teal-300 hover:text-teal-200 mb-6 transition-colors">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Resources
          </Link>
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg p-8 mb-8">
              <h1 className="text-5xl font-bold text-white mb-4">Slide Resources</h1>
              <p className="text-2xl text-gray-300 mb-4">Detailed Explanations for All 25 Presentation Slides</p>
              <div className="flex items-center justify-center space-x-8">
                <div className="flex items-center">
                  <FileText className="h-6 w-6 text-green-300 mr-2" />
                  <span className="text-green-300">Comprehensive Context</span>
                </div>
                <div className="flex items-center">
                  <Eye className="h-6 w-6 text-blue-300 mr-2" />
                  <span className="text-blue-300">Key Takeaways</span>
                </div>
                <div className="flex items-center">
                  <BookOpen className="h-6 w-6 text-orange-300 mr-2" />
                  <span className="text-orange-300">Related Resources</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="bg-white/5 rounded-lg p-6 mb-12">
          <h2 className="text-2xl font-bold text-white mb-4">Quick Navigation by Module</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="text-center">
              <div className="bg-orange-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">Intro</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 1</div>
            </div>
            <div className="text-center">
              <div className="bg-red-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">M1</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 2-4</div>
            </div>
            <div className="text-center">
              <div className="bg-yellow-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">M2</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 5-9</div>
            </div>
            <div className="text-center">
              <div className="bg-green-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">M3</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 10-14</div>
            </div>
            <div className="text-center">
              <div className="bg-blue-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">M4-5</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 15-21</div>
            </div>
            <div className="text-center">
              <div className="bg-purple-500 text-white p-2 rounded-lg mb-2">
                <span className="font-bold">M6</span>
              </div>
              <div className="text-gray-300 text-sm">Slides 22-25</div>
            </div>
          </div>
        </div>

        {/* Slide Resources Grid */}
        <div className="space-y-8">
          {slideResources.map((slide) => (
            <div key={slide.id} className="bg-white/5 border border-gray-600 rounded-lg p-8">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center">
                  <div className="bg-green-500 text-white w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg mr-4">
                    {slide.id}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">{slide.title}</h3>
                    <div className="flex items-center space-x-4">
                      <span className="text-green-300 font-medium">{slide.module}</span>
                      <div className="flex items-center text-gray-300">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{slide.duration}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <Link href={`/pages/${slide.id}?total=25`} className="flex items-center bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                  <Eye className="h-4 w-4 mr-2" />
                  View Slide
                </Link>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xl font-bold text-white mb-4 flex items-center">
                    <Target className="h-5 w-5 mr-2 text-blue-300" />
                    Key Points
                  </h4>
                  <ul className="space-y-2">
                    {slide.keyPoints.map((point, index) => (
                      <li key={index} className="flex items-start">
                        <div className="bg-blue-500 w-2 h-2 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <span className="text-gray-200">{point}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6">
                    <h4 className="text-lg font-bold text-white mb-3 flex items-center">
                      <Users className="h-5 w-5 mr-2 text-orange-300" />
                      Facilitator Notes
                    </h4>
                    <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                      <p className="text-gray-200 italic">{slide.facilitatorNotes}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-white mb-4 flex items-center">
                    <Lightbulb className="h-5 w-5 mr-2 text-yellow-300" />
                    Detailed Explanation
                  </h4>
                  <div className="bg-white/10 rounded-lg p-4 mb-6">
                    <p className="text-gray-200 leading-relaxed">{slide.detailedExplanation}</p>
                  </div>

                  <h4 className="text-lg font-bold text-white mb-3 flex items-center">
                    <BookOpen className="h-5 w-5 mr-2 text-purple-300" />
                    Related Resources
                  </h4>
                  <div className="space-y-2">
                    {slide.relatedResources.map((resource, index) => (
                      <div key={index} className="flex items-center">
                        <ArrowRight className="h-4 w-4 text-purple-300 mr-2" />
                        <span className="text-purple-200 hover:text-purple-100 cursor-pointer transition-colors">{resource}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Complete Resources Notice */}
        <div className="bg-gradient-to-r from-teal-500/20 to-green-500/20 rounded-lg p-8 mt-12">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-4">Complete Slide Resources</h3>
            <p className="text-gray-200 mb-6">
              This preview shows the detailed format for all 25 slides. The complete version includes comprehensive explanations,
              additional context, troubleshooting tips, and implementation guidance for every slide in the presentation.
            </p>
            <div className="flex justify-center space-x-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-teal-300 mb-1">25</div>
                <div className="text-gray-300">Total Slides</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-300 mb-1">13</div>
                <div className="text-gray-300">Hours Content</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300 mb-1">6</div>
                <div className="text-gray-300">Modules</div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-16 pt-8 border-t border-gray-600">
          <Link href="/guidebook" className="flex items-center text-teal-300 hover:text-teal-200 transition-colors">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Previous: Guidebook
          </Link>
          
          <Link href="/prompts" className="flex items-center text-orange-300 hover:text-orange-200 transition-colors">
            Next: ChatGPT Prompts
            <ArrowRight className="h-5 w-5 ml-2" />
          </Link>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-gray-300">© 2025 Growth Partner Pros. All Rights Reserved.</p>
          <p className="text-gray-400 mt-2">GPT-5 Executive Mastery Course - Slide Resources</p>
        </div>
      </div>
    </div>
  );
}
