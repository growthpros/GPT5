
'use client'
import { SessionProvider } from 'next-auth/react'
import { ReactNode, useState, useEffect } from 'react'

interface ProvidersProps {
  children: ReactNode
}

export default function Providers({ children }: ProvidersProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0A2044' }}>
        <div className="text-white">Loading...</div>
      </div>
    )
  }

  return (
    <SessionProvider>
      {children}
    </SessionProvider>
  )
}
