
'use client'
import { useSession, signOut } from 'next-auth/react'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Shield, Settings } from 'lucide-react'

export default function AuthHeader() {
  const { data: session, status } = useSession() || {}
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted || status === 'loading') {
    return null
  }

  if (!session) return null

  const isAdmin = (session.user as any)?.role === 'admin'

  return (
    <div className="flex justify-between items-center mb-6 p-4 bg-white/5 rounded-lg">
      <div>
        <p className="text-white">Welcome, {session.user?.name || session.user?.email}</p>
        <p className="text-gray-400 text-sm">GPT-5 Executive Mastery Course</p>
        {isAdmin && (
          <div className="flex items-center space-x-1 mt-1">
            <Shield className="h-3 w-3 text-orange-400" />
            <span className="text-orange-400 text-xs">Administrator</span>
          </div>
        )}
      </div>
      <div className="flex items-center space-x-3">
        {isAdmin && (
          <Link
            href="/admin"
            className="flex items-center space-x-2 px-3 py-2 text-sm text-orange-300 hover:text-orange-200 border border-orange-600 hover:border-orange-400 rounded-lg transition-colors"
          >
            <Settings className="h-4 w-4" />
            <span>Admin Panel</span>
          </Link>
        )}
        <button
          onClick={() => signOut()}
          className="px-4 py-2 text-sm text-gray-300 hover:text-white border border-gray-600 hover:border-gray-400 rounded-lg transition-colors"
        >
          Sign Out
        </button>
      </div>
    </div>
  )
}
