
import { PrismaClient } from '@prisma/client'
import 'dotenv/config'

const prisma = new PrismaClient()

async function setupAdmin() {
  try {
    // Make the test user an admin
    const testUser = await prisma.user.findUnique({
      where: { email: 'john@doe.com' }
    })

    if (testUser) {
      await prisma.user.update({
        where: { email: 'john@doe.com' },
        data: { role: 'admin' }
      })
      console.log('Test user is now an admin')
    }

    // You can also make your own email an admin
    // Replace 'your-email@example.com' with your actual email
    const yourEmail = 'admin@growthpartnerpros.com'
    const existingUser = await prisma.user.findUnique({
      where: { email: yourEmail }
    })

    if (existingUser) {
      await prisma.user.update({
        where: { email: yourEmail },
        data: { role: 'admin' }
      })
      console.log(`User ${yourEmail} is now an admin`)
    } else {
      console.log(`User ${yourEmail} not found. Create an account first, then run this script again.`)
    }

  } catch (error) {
    console.error('Error setting up admin:', error)
  } finally {
    await prisma.$disconnect()
  }
}

setupAdmin()
