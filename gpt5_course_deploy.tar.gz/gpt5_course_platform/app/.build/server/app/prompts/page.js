(()=>{var e={};e.id=7794,e.ids=[7794],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},6325:(e,s,t)=>{"use strict";t.r(s),t.d(s,{GlobalError:()=>n.a,__next_app__:()=>p,originalPathname:()=>m,pages:()=>d,routeModule:()=>u,tree:()=>c}),t(28902),t(14785),t(71363);var i=t(36576),a=t(72007),r=t(21818),n=t.n(r),o=t(88897),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);t.d(s,l);let c=["",{children:["prompts",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,28902)),"/home/ubuntu/gpt5_course_platform/app/app/prompts/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,14785)),"/home/ubuntu/gpt5_course_platform/app/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,71363,23)),"next/dist/client/components/not-found-error"]}],d=["/home/ubuntu/gpt5_course_platform/app/app/prompts/page.tsx"],m="/prompts/page",p={require:t,loadChunk:()=>Promise.resolve()},u=new i.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/prompts/page",pathname:"/prompts",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},33647:(e,s,t)=>{Promise.resolve().then(t.bind(t,49358)),Promise.resolve().then(t.bind(t,56444))},87133:(e,s,t)=>{Promise.resolve().then(t.t.bind(t,84114,23)),Promise.resolve().then(t.t.bind(t,28866,23)),Promise.resolve().then(t.t.bind(t,31324,23)),Promise.resolve().then(t.t.bind(t,83567,23)),Promise.resolve().then(t.t.bind(t,55996,23)),Promise.resolve().then(t.t.bind(t,10050,23))},55356:(e,s,t)=>{Promise.resolve().then(t.t.bind(t,95003,23))},49358:(e,s,t)=>{"use strict";t.d(s,{KeyboardNavigation:()=>a}),t(24383);var i=t(84374);function a(){return(0,i.useRouter)(),(0,i.useSearchParams)(),null}},56444:(e,s,t)=>{"use strict";t.d(s,{default:()=>n});var i=t(62901),a=t(84700),r=t(24383);function n({children:e}){let[s,t]=(0,r.useState)(!1);return s?i.jsx(a.SessionProvider,{children:e}):i.jsx("div",{className:"min-h-screen flex items-center justify-center",style:{backgroundColor:"#0A2044"},children:i.jsx("div",{className:"text-white",children:"Loading..."})})}},14785:(e,s,t)=>{"use strict";t.r(s),t.d(s,{default:()=>m,metadata:()=>d});var i=t(83537),a=t(57416),r=t.n(a);t(26148);var n=t(88895);let o=(0,n.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/keyboard-navigation.tsx#KeyboardNavigation`);var l=t(3995);let c=(0,n.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/providers.tsx#default`),d={title:"GPT-5 Executive Mastery Course - Growth Partner Pros",description:"Professional executive-level course for mastering GPT-5 advanced capabilities and business applications"};function m({children:e}){return i.jsx("html",{lang:"en",children:i.jsx("body",{className:`${r().className} text-white min-h-screen`,style:{backgroundColor:"#0A2044"},children:(0,i.jsxs)(c,{children:[i.jsx(l.Suspense,{fallback:null,children:i.jsx(o,{})}),e]})})})}},28902:(e,s,t)=>{"use strict";t.r(s),t.d(s,{default:()=>f});var i=t(83537),a=t(85168),r=t(48675),n=t(89004);let o=(0,n.Z)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]),l=(0,n.Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);var c=t(42662);let d=(0,n.Z)("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),m=(0,n.Z)("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]),p=(0,n.Z)("Building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]]);var u=t(93379);let h=(0,n.Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]),x=(0,n.Z)("Filter",[["polygon",{points:"22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",key:"1yg77f"}]]);var g=t(22932);let y=({title:e,category:s,description:t,prompt:a,useCase:n,tips:c,difficulty:d})=>(0,i.jsxs)("div",{className:"bg-white/5 border border-purple-500/30 rounded-lg p-6 mb-6",children:[(0,i.jsxs)("div",{className:"flex items-start justify-between mb-4",children:[(0,i.jsxs)("div",{className:"flex items-center",children:[i.jsx("div",{className:"bg-purple-500 p-2 rounded-lg mr-4",children:i.jsx(r.Z,{className:"h-6 w-6 text-white"})}),(0,i.jsxs)("div",{children:[i.jsx("h3",{className:"text-xl font-bold text-white mb-1",children:e}),(0,i.jsxs)("div",{className:"flex items-center space-x-4",children:[i.jsx("span",{className:"bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm font-medium",children:s}),i.jsx("span",{className:`px-3 py-1 rounded-full text-sm font-medium ${"Basic"===d?"bg-green-500/20 text-green-300":"Advanced"===d?"bg-orange-500/20 text-orange-300":"bg-red-500/20 text-red-300"}`,children:d})]})]})]}),(0,i.jsxs)("div",{className:"flex space-x-2",children:[i.jsx("button",{className:"bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-lg transition-colors",children:i.jsx(o,{className:"h-4 w-4"})}),i.jsx("button",{className:"bg-teal-500 hover:bg-teal-600 text-white p-2 rounded-lg transition-colors",children:i.jsx(l,{className:"h-4 w-4"})})]})]}),i.jsx("p",{className:"text-gray-200 mb-4",children:t}),(0,i.jsxs)("div",{className:"bg-gray-800 rounded-lg p-4 mb-4",children:[(0,i.jsxs)("div",{className:"flex items-center justify-between mb-2",children:[i.jsx("h4",{className:"font-semibold text-gray-300",children:"Prompt Template:"}),i.jsx("span",{className:"text-purple-300 text-sm",children:"Ready to Copy"})]}),i.jsx("pre",{className:"text-gray-200 text-sm whitespace-pre-wrap overflow-x-auto",children:a})]}),(0,i.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,i.jsxs)("div",{children:[i.jsx("h4",{className:"font-semibold text-yellow-300 mb-2",children:"Use Case Example:"}),i.jsx("p",{className:"text-gray-200 text-sm",children:n})]}),(0,i.jsxs)("div",{children:[i.jsx("h4",{className:"font-semibold text-green-300 mb-2",children:"Pro Tips:"}),i.jsx("p",{className:"text-gray-200 text-sm",children:c})]})]})]});function f(){return i.jsx("div",{className:"min-h-screen",style:{backgroundColor:"#0A2044"},children:(0,i.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-12",children:[(0,i.jsxs)("div",{className:"mb-12",children:[(0,i.jsxs)(a.default,{href:"/resources",className:"inline-flex items-center text-teal-300 hover:text-teal-200 mb-6 transition-colors",children:[i.jsx(c.Z,{className:"h-5 w-5 mr-2"}),"Back to Resources"]}),i.jsx("div",{className:"text-center",children:(0,i.jsxs)("div",{className:"bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg p-8 mb-8",children:[i.jsx("h1",{className:"text-5xl font-bold text-white mb-4",children:"ChatGPT Prompts Library"}),i.jsx("p",{className:"text-2xl text-gray-300 mb-4",children:"Ready-to-Use GPT-5 Templates & Advanced Techniques"}),(0,i.jsxs)("div",{className:"flex items-center justify-center space-x-8",children:[(0,i.jsxs)("div",{className:"flex items-center",children:[i.jsx(d,{className:"h-6 w-6 text-purple-300 mr-2"}),i.jsx("span",{className:"text-purple-300",children:"6-Element Framework"})]}),(0,i.jsxs)("div",{className:"flex items-center",children:[i.jsx(m,{className:"h-6 w-6 text-pink-300 mr-2"}),i.jsx("span",{className:"text-pink-300",children:'"Think Hard" Activation'})]}),(0,i.jsxs)("div",{className:"flex items-center",children:[i.jsx(p,{className:"h-6 w-6 text-blue-300 mr-2"}),i.jsx("span",{className:"text-blue-300",children:"Business Applications"})]})]})]})})]}),(0,i.jsxs)("div",{className:"bg-white/5 rounded-lg p-6 mb-12",children:[i.jsx("h2",{className:"text-2xl font-bold text-white mb-4",children:"Prompt Categories"}),(0,i.jsxs)("div",{className:"grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4",children:[(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-purple-500/10 border border-purple-500/30",children:[i.jsx("div",{className:"bg-purple-500 p-3 rounded-lg mb-2",children:i.jsx(u.Z,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Specification Framework"})]}),(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-pink-500/10 border border-pink-500/30",children:[i.jsx("div",{className:"bg-pink-500 p-3 rounded-lg mb-2",children:i.jsx(m,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Think Hard Activation"})]}),(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-blue-500/10 border border-blue-500/30",children:[i.jsx("div",{className:"bg-blue-500 p-3 rounded-lg mb-2",children:i.jsx(p,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Business Analysis"})]}),(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-green-500/10 border border-green-500/30",children:[i.jsx("div",{className:"bg-green-500 p-3 rounded-lg mb-2",children:i.jsx(h,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Strategic Planning"})]}),(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-orange-500/10 border border-orange-500/30",children:[i.jsx("div",{className:"bg-orange-500 p-3 rounded-lg mb-2",children:i.jsx(x,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Data Analysis"})]}),(0,i.jsxs)("div",{className:"flex flex-col items-center p-4 rounded-lg bg-teal-500/10 border border-teal-500/30",children:[i.jsx("div",{className:"bg-teal-500 p-3 rounded-lg mb-2",children:i.jsx(r.Z,{className:"h-6 w-6 text-white"})}),i.jsx("span",{className:"text-white font-medium text-center",children:"Creative Applications"})]})]})]}),(0,i.jsxs)("div",{className:"space-y-8",children:[i.jsx(y,{title:"6-Element Specification Framework",category:"Core Framework",difficulty:"Basic",description:"The foundational template that transforms conversational prompts into precise specifications for consistent GPT-5 results.",prompt:`TASK: [Define the task as clearly as possible]

DELIVERABLE: 
- Format: [Specify exact format - email, report, analysis, etc.]
- Length: [Specify word count, page count, or time limit]
- Audience: [Define who will consume this deliverable]

ASSUMPTIONS:
• [List key assumptions about context, timeline, scope]
• [Include any business context or constraints]
• [Specify data sources or information available]

NON-GOALS:
• [Be explicit about what NOT to do or include]
• [List any constraints or limitations]
• [Specify what's outside the scope]

TOOLS:
• Web search: [Allowed/Forbidden - be specific]
• Code execution: [Allowed/Forbidden - specify languages if allowed]
• File analysis: [Specify what types of files if any]

ACCEPTANCE CRITERIA:
• [Define specific success criteria]
• [List measurable outcomes]
• [Specify quality standards]`,useCase:"Use this framework for any business task requiring precision: strategic analysis, financial modeling, project planning, or content creation.",tips:"Always fill in ALL six elements. The more specific your deliverable and acceptance criteria, the better your results will be."}),i.jsx(y,{title:"Think Hard Activation for Complex Analysis",category:"Advanced Reasoning",difficulty:"Advanced",description:"Activates GPT-5's parallel reasoning mode for complex problems requiring deep analysis and multiple perspectives.",prompt:`I need you to think hard about this complex business problem.

PROBLEM: [Describe the complex business challenge]

THINK HARD INSTRUCTIONS:
• Use parallel reasoning to analyze from multiple perspectives
• Consider risk, growth, competitive, and operational lenses
• Show your reasoning process step by step
• Identify potential blind spots and counterarguments

ANALYSIS REQUEST:
1. Break down the problem into component parts
2. Analyze each component from different business perspectives
3. Identify interdependencies and potential conflicts
4. Synthesize insights into actionable recommendations

DELIVERABLE:
- Executive summary (3 bullet points)
- Detailed analysis with supporting reasoning
- Risk assessment with mitigation strategies
- Recommended action plan with timeline

ARTIFACTS REQUIRED:
• Decision framework used
• Risk/benefit matrix
• Implementation roadmap
• Success metrics definition`,useCase:"Perfect for strategic decisions, investment analysis, market entry strategies, or any complex business problem requiring thorough analysis.",tips:"The phrase 'think hard' is crucial - it's a hardcoded activation for GPT-5's reasoning mode. Always request artifacts to see the AI's methodology."}),i.jsx(y,{title:"Financial Modeling & Analysis",category:"Business Analysis",difficulty:"Advanced",description:"Comprehensive financial analysis using GPT-5 Pro's parallel reasoning capabilities for accuracy and thoroughness.",prompt:`TASK: Comprehensive financial analysis using GPT-5 Pro parallel reasoning

FINANCIAL DATA: [Attach financial statements, datasets, or provide context]

THINK HARD: Please analyze this financial information from multiple perspectives simultaneously:
• Profitability analysis (revenue, margins, efficiency)
• Liquidity analysis (cash flow, working capital)
• Leverage analysis (debt ratios, coverage ratios)
• Growth analysis (trends, sustainability)
• Market analysis (industry comparison, competitive position)

DELIVERABLE:
- Format: Executive financial report with supporting analysis
- Length: 3-page summary + detailed appendix
- Audience: C-suite executives and board members

ANALYSIS REQUIREMENTS:
• Cross-reference all financial statements for consistency
• Apply relevant accounting standards and industry benchmarks
• Identify potential discrepancies or red flags
• Compare performance across multiple time periods
• Benchmark against industry peers

ARTIFACTS REQUIRED:
• Ratio analysis workbook (Python/Excel)
• Trend analysis charts
• Industry comparison matrix
• Risk assessment framework
• Plain English summary of methodology

NON-GOALS:
• Do not provide investment advice
• Do not make predictions beyond reasonable forecasting
• Do not ignore any material discrepancies

ACCEPTANCE CRITERIA:
• All calculations must be verifiable and documented
• Analysis must address both strengths and weaknesses
• Recommendations must be actionable and prioritized`,useCase:"Perfect for due diligence, investment analysis, company valuations, budget reviews, or any financial decision-making process.",tips:"GPT-5 Pro's parallel reasoning excels at catching financial inconsistencies. Always request the methodology artifacts to verify approach."}),i.jsx(y,{title:"Strategic Market Analysis",category:"Strategic Planning",difficulty:"Advanced",description:"Comprehensive market analysis using parallel reasoning to synthesize multiple data sources and perspectives.",prompt:`TASK: Strategic market analysis with parallel reasoning synthesis

MARKET DATA: [Provide market research, customer data, competitive intelligence]

THINK HARD: Analyze this market opportunity from multiple strategic lenses:
• Market size and growth potential
• Competitive landscape and positioning
• Customer needs and behavior analysis
• Regulatory and economic factors
• Internal capabilities and resource requirements

DELIVERABLE:
- Format: Strategic market entry recommendations
- Length: Executive summary (1 page) + detailed analysis (5-7 pages)
- Audience: Executive leadership team and investors

SYNTHESIS REQUIREMENTS:
• Process all data sources simultaneously for patterns
• Identify market gaps and opportunities
• Assess competitive threats and advantages
• Evaluate market entry barriers and success factors
• Generate scenario-based strategic options

ARTIFACTS REQUIRED:
• Market sizing methodology and assumptions
• Competitive analysis matrix
• Customer persona profiles
• SWOT analysis framework
• Go-to-market strategy template
• Success metrics and KPI definitions

ASSUMPTIONS:
• [Specify time horizon for analysis]
• [Define geographic scope]
• [List available resources and constraints]

ACCEPTANCE CRITERIA:
• Recommendations must be data-driven and actionable
• Multiple strategic options with clear trade-offs
• Implementation roadmap with milestones
• Risk assessment with mitigation strategies`,useCase:"Ideal for market entry decisions, product launches, competitive positioning, M&A evaluation, or strategic planning initiatives.",tips:"Feed multiple data sources simultaneously. GPT-5's large context window can handle comprehensive market research data for better synthesis."}),i.jsx(y,{title:"Customer Success & Voice of Customer Analysis",category:"Business Analysis",difficulty:"Intermediate",description:"Synthesize customer feedback from multiple touchpoints to identify patterns and improvement opportunities.",prompt:`TASK: Comprehensive customer success analysis from multiple data sources

DATA SOURCES: [Attach support tickets, surveys, reviews, NPS data, customer interviews]

ANALYSIS FRAMEWORK:
• Customer satisfaction patterns and trends
• Pain point identification and categorization
• Product/service improvement opportunities
• Customer journey optimization points
• Success metrics and benchmarking

DELIVERABLE:
- Format: Customer insights report with action recommendations
- Length: Executive summary (3 bullets) + detailed findings (3-4 pages)
- Audience: Product, Customer Success, and Executive teams

PROCESSING REQUIREMENTS:
• Analyze sentiment patterns across all touchpoints
• Identify systemic vs. isolated issues
• Categorize feedback by customer segment/value
• Cross-reference with business metrics (retention, expansion)
• Generate prioritized improvement recommendations

ARTIFACTS REQUIRED:
• Customer sentiment analysis summary
• Issue categorization matrix
• Customer journey pain point map
• Improvement opportunity prioritization
• Success metrics tracking framework

NON-GOALS:
• Do not identify individual customers by name
• Do not make assumptions about customer intent without data
• Do not recommend solutions outside company capabilities

ACCEPTANCE CRITERIA:
• All insights must be supported by data evidence
• Recommendations must be prioritized by impact/effort
• Action plan must include success metrics and timeline`,useCase:"Perfect for product development, customer experience improvement, retention strategies, or service optimization initiatives.",tips:"Combine quantitative data (NPS, satisfaction scores) with qualitative feedback for comprehensive insights. Look for patterns across customer segments."}),i.jsx(y,{title:"Canvas + Memory Integration Workflow",category:"Advanced Workflow",difficulty:"Expert",description:"Leverage GPT-5's Canvas and Memory features for iterative document development and personalized AI assistance.",prompt:`CANVAS WORKFLOW: Iterative document development with memory integration

MEMORY ENCODING INSTRUCTIONS:
Please remember these preferences for future sessions:
• My communication style: [Direct/Detailed/Executive summary format]
• My industry context: [Specify industry and role]
• My typical deliverable preferences: [Format, length, style preferences]
• My decision-making framework: [How you evaluate options]

CANVAS DOCUMENT TYPE: [Strategic plan/Financial model/Project plan/etc.]

COLLABORATIVE DEVELOPMENT PROCESS:
1. Initial draft: Create foundation based on provided requirements
2. Section-by-section refinement: Focus on one section at a time
3. Cross-referencing: Ensure consistency across all sections
4. Executive polish: Final formatting and presentation optimization

ITERATIVE IMPROVEMENT FRAMEWORK:
• Draft → Review → Refine → Validate → Finalize
• Each iteration should incorporate feedback and new information
• Maintain version control and track changes
• Document assumptions and decision rationale

MEMORY-ENHANCED FEATURES:
• Apply my preferred analysis framework automatically
• Use my established terminology and communication style
• Reference previous projects and lessons learned
• Incorporate my industry knowledge and context

CANVAS SPECIFIC INSTRUCTIONS:
• Use collaborative editing for real-time refinement
• Maintain formatting consistency throughout
• Enable easy sharing and review by stakeholders
• Prepare export-ready versions in multiple formats

DELIVERABLE SPECIFICATIONS:
- Format: [Living document with version control]
- Collaboration: [Real-time editing with stakeholder access]
- Memory integration: [Personalized recommendations and style]
- Export options: [PDF, PPTX, DOCX as needed]`,useCase:"Ideal for strategic planning documents, business cases, project charters, or any collaborative document requiring iterative development.",tips:"Build your memory profile gradually. The AI will become more personalized and effective over time as it learns your preferences and context."})]}),(0,i.jsxs)("div",{className:"bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-lg p-8 mt-12",children:[i.jsx("h2",{className:"text-2xl font-bold text-white mb-6",children:"Quick Reference Guide"}),(0,i.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[(0,i.jsxs)("div",{className:"bg-white/10 rounded-lg p-6",children:[i.jsx("h3",{className:"text-lg font-bold text-purple-300 mb-3",children:"Essential Commands"}),(0,i.jsxs)("ul",{className:"space-y-2 text-gray-200",children:[(0,i.jsxs)("li",{children:[i.jsx("code",{className:"bg-gray-800 px-2 py-1 rounded text-sm",children:'"Think hard"'})," - Activates reasoning mode"]}),(0,i.jsxs)("li",{children:[i.jsx("code",{className:"bg-gray-800 px-2 py-1 rounded text-sm",children:'"Show your work"'})," - Demands methodology"]}),(0,i.jsxs)("li",{children:[i.jsx("code",{className:"bg-gray-800 px-2 py-1 rounded text-sm",children:'"Create artifact"'})," - Generates supporting materials"]}),(0,i.jsxs)("li",{children:[i.jsx("code",{className:"bg-gray-800 px-2 py-1 rounded text-sm",children:'"Multiple perspectives"'})," - Parallel analysis"]})]})]}),(0,i.jsxs)("div",{className:"bg-white/10 rounded-lg p-6",children:[i.jsx("h3",{className:"text-lg font-bold text-blue-300 mb-3",children:"Framework Elements"}),(0,i.jsxs)("ul",{className:"space-y-2 text-gray-200",children:[(0,i.jsxs)("li",{children:["1. ",i.jsx("strong",{children:"TASK"})," - Clear definition"]}),(0,i.jsxs)("li",{children:["2. ",i.jsx("strong",{children:"DELIVERABLE"})," - Format/audience"]}),(0,i.jsxs)("li",{children:["3. ",i.jsx("strong",{children:"ASSUMPTIONS"})," - Context/scope"]}),(0,i.jsxs)("li",{children:["4. ",i.jsx("strong",{children:"NON-GOALS"})," - Constraints"]}),(0,i.jsxs)("li",{children:["5. ",i.jsx("strong",{children:"TOOLS"})," - Allowed resources"]}),(0,i.jsxs)("li",{children:["6. ",i.jsx("strong",{children:"ACCEPTANCE"})," - Success criteria"]})]})]}),(0,i.jsxs)("div",{className:"bg-white/10 rounded-lg p-6",children:[i.jsx("h3",{className:"text-lg font-bold text-teal-300 mb-3",children:"Best Practices"}),(0,i.jsxs)("ul",{className:"space-y-2 text-gray-200",children:[i.jsx("li",{children:"• Always specify deliverable format"}),i.jsx("li",{children:"• Request supporting artifacts"}),i.jsx("li",{children:'• Use "think hard" for complex tasks'}),i.jsx("li",{children:"• Define success criteria clearly"}),i.jsx("li",{children:"• Leverage Canvas for collaboration"}),i.jsx("li",{children:"• Build Memory profile over time"})]})]})]})]}),(0,i.jsxs)("div",{className:"flex justify-between items-center mt-16 pt-8 border-t border-gray-600",children:[(0,i.jsxs)(a.default,{href:"/slide-resources",className:"flex items-center text-teal-300 hover:text-teal-200 transition-colors",children:[i.jsx(c.Z,{className:"h-5 w-5 mr-2"}),"Previous: Slide Resources"]}),(0,i.jsxs)(a.default,{href:"/exercises",className:"flex items-center text-orange-300 hover:text-orange-200 transition-colors",children:["Next: Exercises & Worksheets",i.jsx(g.Z,{className:"h-5 w-5 ml-2"})]})]}),(0,i.jsxs)("div",{className:"text-center mt-8",children:[i.jsx("p",{className:"text-gray-300",children:"\xa9 2025 Growth Partner Pros. All Rights Reserved."}),i.jsx("p",{className:"text-gray-400 mt-2",children:"GPT-5 Executive Mastery Course - ChatGPT Prompts Library"})]})]})})}},89004:(e,s,t)=>{"use strict";t.d(s,{Z:()=>l});var i=t(3995);let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),r=(...e)=>e.filter((e,s,t)=>!!e&&t.indexOf(e)===s).join(" ");var n={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let o=(0,i.forwardRef)(({color:e="currentColor",size:s=24,strokeWidth:t=2,absoluteStrokeWidth:a,className:o="",children:l,iconNode:c,...d},m)=>(0,i.createElement)("svg",{ref:m,...n,width:s,height:s,stroke:e,strokeWidth:a?24*Number(t)/Number(s):t,className:r("lucide",o),...d},[...c.map(([e,s])=>(0,i.createElement)(e,s)),...Array.isArray(l)?l:[l]])),l=(e,s)=>{let t=(0,i.forwardRef)(({className:t,...n},l)=>(0,i.createElement)(o,{ref:l,iconNode:s,className:r(`lucide-${a(e)}`,t),...n}));return t.displayName=`${e}`,t}},42662:(e,s,t)=>{"use strict";t.d(s,{Z:()=>i});let i=(0,t(89004).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},22932:(e,s,t)=>{"use strict";t.d(s,{Z:()=>i});let i=(0,t(89004).Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},48675:(e,s,t)=>{"use strict";t.d(s,{Z:()=>i});let i=(0,t(89004).Z)("Lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]])},93379:(e,s,t)=>{"use strict";t.d(s,{Z:()=>i});let i=(0,t(89004).Z)("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]])},85168:(e,s,t)=>{"use strict";t.d(s,{default:()=>a.a});var i=t(86236),a=t.n(i)},86236:(e,s,t)=>{"use strict";let{createProxy:i}=t(88895);e.exports=i("/opt/hostedapp/node/root/app/node_modules/next/dist/client/link.js")},26148:()=>{}};var s=require("../../webpack-runtime.js");s.C(e);var t=e=>s(s.s=e),i=s.X(0,[4372,9056,5003],()=>t(6325));module.exports=i})();