(()=>{var e={};e.id=4564,e.ids=[4564],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},64967:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>r.a,__next_app__:()=>p,originalPathname:()=>m,pages:()=>d,routeModule:()=>u,tree:()=>c}),i(87296),i(14785),i(71363);var s=i(36576),a=i(72007),n=i(21818),r=i.n(n),o=i(88897),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let c=["",{children:["wow-demos",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,87296)),"/home/ubuntu/gpt5_course_platform/app/app/wow-demos/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,14785)),"/home/ubuntu/gpt5_course_platform/app/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,71363,23)),"next/dist/client/components/not-found-error"]}],d=["/home/ubuntu/gpt5_course_platform/app/app/wow-demos/page.tsx"],m="/wow-demos/page",p={require:i,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/wow-demos/page",pathname:"/wow-demos",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},6214:(e,t,i)=>{Promise.resolve().then(i.bind(i,36487))},33647:(e,t,i)=>{Promise.resolve().then(i.bind(i,49358)),Promise.resolve().then(i.bind(i,56444))},87133:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,84114,23)),Promise.resolve().then(i.t.bind(i,28866,23)),Promise.resolve().then(i.t.bind(i,31324,23)),Promise.resolve().then(i.t.bind(i,83567,23)),Promise.resolve().then(i.t.bind(i,55996,23)),Promise.resolve().then(i.t.bind(i,10050,23))},36487:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>y});var s=i(62901),a=i(24383),n=i(71945);let r=(0,n.Z)("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]);var o=i(82063),l=i(64483);let c=(0,n.Z)("Rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]]);var d=i(87552),m=i(33901),p=i(27328);let u=(0,n.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);var h=i(49568),g=i(27849);let x=[{id:"parallel-reasoning",title:"GPT-5 Pro: Parallel Reasoning Engine",description:"Multiple expert perspectives analyzing the same problem simultaneously",icon:r,color:"from-purple-500 to-indigo-500",complexity:"Advanced",timeToValue:"5 minutes",businessValue:"Strategic Decision Making",demo:{scenario:"Should we acquire TechStartup Inc. for $50M?",prompt:`Think hard - I need multiple expert perspectives on this acquisition:

ACQUISITION TARGET: TechStartup Inc.
PRICE: $50M (4x revenue)
THEIR METRICS: $12.5M ARR, 40% growth, 85% gross margins
STRATEGIC FIT: AI/ML capabilities we lack
INTEGRATION RISK: Different tech stack, 50-person team

I need perspectives from:
1. Financial analyst (ROI, valuation, cash flow impact)
2. Technology strategist (integration complexity, IP value)  
3. HR executive (cultural fit, retention risk)
4. Market analyst (competitive positioning, timing)
5. Risk manager (potential downsides, mitigation)

Provide each perspective with specific reasoning and recommendations.`,expectedOutput:`**FINANCIAL ANALYST PERSPECTIVE:**
- Valuation is reasonable at 4x ARR given 40% growth
- Payback period: 3.2 years assuming maintained growth
- Cash flow positive by month 18 post-acquisition
- Recommendation: PROCEED with $45M counter-offer

**TECHNOLOGY STRATEGIST PERSPECTIVE:**  
- AI/ML capabilities worth $15M+ in development savings
- Integration complexity moderate (6-9 months)
- IP portfolio includes 3 pending patents
- Recommendation: PROCEED - strategic value exceeds price

**HR EXECUTIVE PERSPECTIVE:**
- Cultural assessment shows 70% compatibility
- Key talent retention risk: CTO and 3 senior engineers
- Integration cost: $2M for retention packages
- Recommendation: PROCEED with enhanced retention plan

**MARKET ANALYST PERSPECTIVE:**
- Market timing excellent - AI adoption accelerating
- Competitive response likely from 2 major players
- Customer overlap: 15% synergy opportunities
- Recommendation: PROCEED quickly to prevent competitive acquisition

**RISK MANAGER PERSPECTIVE:**
- Technology risk: Medium (different architecture)
- Execution risk: High (complex integration)
- Market risk: Low (proven demand)  
- Recommendation: PROCEED with phased integration plan`,impact:"Provides comprehensive analysis that would typically require 5 separate meetings and 2 weeks of analysis"}},{id:"think-hard-activation",title:'"Think Hard" Activation for Complex Problems',description:"Unlock GPT-5's deepest reasoning capabilities for mission-critical decisions",icon:o.Z,color:"from-yellow-500 to-orange-500",complexity:"Expert",timeToValue:"10 minutes",businessValue:"Critical Problem Solving",demo:{scenario:"Our top client is threatening to leave due to service issues",prompt:`Think hard about this client retention crisis:

CRITICAL CLIENT: GlobalCorp (30% of revenue, $15M annually)
THREAT: Considering competitor switch in 30 days
ISSUES: 
- Service uptime 94% (SLA: 99.5%)
- Response times 2x slower than promised
- 3 major incidents in Q4
- Account team turnover (3 reps in 6 months)

CONSTRAINTS:
- Cannot afford to lose this client
- Infrastructure upgrades need 90 days
- Limited budget for immediate fixes
- New account team needs training

STAKEHOLDERS:
- Their CTO (technical concerns)
- Their CFO (cost/value analysis)  
- Their operations team (daily users)
- Our CEO (strategic relationship)

I need a comprehensive save strategy that addresses technical issues, relationship repair, and long-term stability. Consider both immediate actions and strategic solutions.`,expectedOutput:`**IMMEDIATE ACTIONS (Next 7 Days):**
1. Executive Escalation: CEO-to-CEO call within 48 hours
2. Technical Strike Team: Deploy 3 senior engineers full-time
3. Dedicated Account Pod: VP of Customer Success + Senior Engineer
4. SLA Credit: Proactive $500K service credit for Q4 issues
5. War Room: Daily calls until stability achieved

**30-DAY RECOVERY PLAN:**
- Infrastructure hotfixes: Load balancing improvements (Week 1)
- Response time optimization: Database query optimization (Week 2)  
- Monitoring enhancement: Real-time alerting system (Week 3)
- Relationship rebuilding: On-site technical review (Week 4)

**STAKEHOLDER-SPECIFIC APPROACH:**
- CTO: Joint technical roadmap, direct engineering contact
- CFO: ROI analysis showing value vs. switching costs
- Operations: Training sessions, process improvements
- Our CEO: Strategic partnership expansion discussion

**LONG-TERM STRATEGY:**
- Premium Support Tier: Dedicated resources for top clients
- Infrastructure Modernization: $2M investment over 6 months  
- Account Management Excellence: New hiring and training program
- Proactive Communication: Monthly business reviews

**SUCCESS METRICS:**
- Uptime improvement to 99.8% within 60 days
- Response time reduction of 70% within 30 days
- Client satisfaction score increase from 6 to 9+
- Contract renewal with 2-year extension

**RISK MITIGATION:**
- Backup plan: Interim fixes if infrastructure delays occur
- Communication plan: Weekly executive updates
- Escalation protocol: If client feedback deteriorates`,impact:"Creates comprehensive crisis response strategy that addresses technical, relationship, and strategic dimensions simultaneously"}},{id:"canvas-memory",title:"Canvas + Memory: Persistent Business Intelligence",description:"Build evolving knowledge base that remembers context across sessions",icon:l.Z,color:"from-green-500 to-teal-500",complexity:"Intermediate",timeToValue:"15 minutes",businessValue:"Continuous Intelligence",demo:{scenario:"Building persistent competitive intelligence system",prompt:`Create a Canvas document for our competitive intelligence on "DataFlow Analytics":

COMPETITOR: DataFlow Analytics
LAST UPDATED: [Current Session]
INTELLIGENCE TYPE: Strategic Analysis

Please create sections for:
1. Company Overview & Recent Changes
2. Product Portfolio & Roadmap  
3. Pricing Strategy & Market Position
4. Strengths & Weaknesses Analysis
5. Customer Feedback & Win/Loss Intel
6. Strategic Threats & Opportunities
7. Recommended Counter-Strategies

INSTRUCTIONS: 
- Use Memory to recall any previous discussions about DataFlow
- Update this Canvas whenever new competitive intelligence is gathered
- Make this a living document that evolves with new information
- Include confidence levels for each piece of intelligence

START WITH: Recent news that DataFlow raised $50M Series C and acquired CustomerMetrics Inc.`,expectedOutput:`**CANVAS DOCUMENT CREATED: DataFlow Analytics Competitive Intelligence**

**1. COMPANY OVERVIEW & RECENT CHANGES**
- Founded 2018, $120M total funding (including new $50M Series C)
- Recent acquisition: CustomerMetrics Inc. ($15M, customer analytics)
- Team size: ~300 employees (up from 200 in Q3)
- Leadership: New VP of Enterprise Sales hired from Salesforce
*Confidence: High (public information)*

**2. PRODUCT PORTFOLIO & ROADMAP**
- Core Platform: Real-time data analytics (direct competitor)
- New Addition: Customer journey analytics (from acquisition)
- Roadmap Intel: AI/ML predictive capabilities (Q2 2025 launch)
- Integration Focus: Expanding Salesforce/HubSpot connectors
*Confidence: Medium (based on job postings and customer interviews)*

**3. PRICING STRATEGY & MARKET POSITION**
- Enterprise: $50K+ annual contracts (20% below our pricing)
- Mid-market: Aggressive penetration pricing
- Position: "Democratizing enterprise analytics"
- Recent Change: Added consumption-based pricing tier
*Confidence: High (from recent competitive deals)*

**MEMORY INTEGRATION ACTIVATED**
*This document will automatically update as new intelligence is gathered across sessions, building comprehensive competitive understanding over time.*

**Next Steps:**
1. Weekly intelligence gathering from win/loss interviews
2. Monitor their hiring patterns for product direction clues
3. Track customer feedback on review sites
4. Update pricing intelligence from sales team`,impact:"Creates persistent competitive intelligence that builds over time, eliminating duplicate research and maintaining institutional knowledge"}},{id:"kitchen-table-software",title:"Kitchen Table Software Creation",description:"Build custom business applications in minutes, not months",icon:c,color:"from-blue-500 to-cyan-500",complexity:"Beginner",timeToValue:"20 minutes",businessValue:"Rapid Application Development",demo:{scenario:"Sales team needs custom lead scoring and pipeline management tool",prompt:`I need you to build a complete lead scoring and pipeline management application:

REQUIREMENTS:
- Lead scoring algorithm based on company size, budget, timeline, authority
- Pipeline stages: Prospect → Qualified → Demo → Proposal → Negotiation → Closed
- Automated follow-up reminders based on stage and last activity
- Revenue forecasting with probability weighting
- Rep performance dashboard with key metrics
- Mobile-friendly interface for field sales

BUSINESS RULES:
- Lead scores: 0-100 scale based on weighted criteria
- Follow-up cadence: Prospects (3 days), Qualified (1 week), Demo (3 days)
- Revenue forecast: Stage probability \xd7 Deal value \xd7 Confidence factor
- Rep metrics: Conversion rates, average deal size, cycle time

TECHNICAL REQUIREMENTS:
- Web-based application (HTML/CSS/JavaScript)
- Local storage for data (no database required initially)
- Responsive design for mobile/tablet use
- Export capabilities for reporting

Build the complete application with HTML, CSS, and JavaScript code that I can immediately deploy and use.`,expectedOutput:`**COMPLETE LEAD SCORING & PIPELINE APPLICATION**

*[GPT-5 would generate complete, functional code including:]*

**1. HTML Structure (index.html)**
- Lead entry forms with all required fields
- Pipeline kanban board interface  
- Rep dashboard with performance metrics
- Mobile-responsive navigation

**2. CSS Styling (styles.css)**
- Professional business theme with Growth Partner Pros colors
- Responsive grid layouts for different screen sizes
- Interactive elements with hover states
- Clean, executive-friendly design

**3. JavaScript Functionality (app.js)**
- Lead scoring algorithm with weighted calculations
- Drag-and-drop pipeline management
- Automated follow-up reminder system
- Revenue forecasting calculations
- Local storage data persistence
- Export functionality for CSV/PDF reports

**4. Business Logic Implementation**
- Company Size Scoring: Enterprise (40pts), Mid-market (25pts), SMB (10pts)
- Budget Authority: Decision maker (30pts), Influencer (15pts), User (5pts)
- Timeline Scoring: Immediate (20pts), 3 months (15pts), 6+ months (5pts)
- Pipeline Probabilities: Prospect (10%), Qualified (25%), Demo (50%), etc.

**5. Deployment Instructions**
- Simple file structure for immediate web hosting
- Configuration options for customization
- User guide for sales team adoption

**IMMEDIATE BUSINESS VALUE:**
- Replace expensive CRM for small teams
- Custom scoring based on YOUR criteria
- No monthly subscription fees
- Fully customizable for business needs`,impact:"Eliminates need for expensive CRM software and months of development time, creating custom solution in minutes"}},{id:"artifact-driven",title:"Artifact-Driven Results with Proof of Work",description:"Demand tangible deliverables and supporting evidence for every request",icon:d.Z,color:"from-red-500 to-pink-500",complexity:"Advanced",timeToValue:"30 minutes",businessValue:"Comprehensive Analysis",demo:{scenario:"Market entry strategy for European expansion",prompt:`I need comprehensive market entry analysis for European expansion with complete artifacts:

MARKET: European Union (focus on Germany, France, UK)
INVESTMENT: $25M over 18 months  
TARGET: $100M revenue by year 3
PRODUCT: B2B SaaS platform (currently US-only)

REQUIRED ARTIFACTS:
1. Market sizing spreadsheet with TAM/SAM/SOM calculations
2. Competitive landscape matrix with detailed profiles
3. Go-to-market strategy document with tactical timeline
4. Financial projections model (P&L, cash flow, unit economics)
5. Risk assessment matrix with mitigation strategies
6. Regulatory compliance checklist (GDPR, local requirements)
7. Partnership strategy framework with target partner profiles
8. Hiring plan with roles, timeline, and budget allocation
9. Marketing strategy with channel priorities and budget
10. Success metrics dashboard template

Each artifact must be:
- Immediately usable (ready-to-implement)
- Data-driven with sources and assumptions
- Executive-presentation ready
- Customizable for different scenarios

Provide complete, professional-quality deliverables that I can present to the board next week.`,expectedOutput:`**ARTIFACT 1: MARKET SIZING SPREADSHEET**
*Complete Excel-compatible model with:*
- TAM: €85B (EU B2B SaaS market)
- SAM: €12B (our addressable segment)  
- SOM: €240M (realistic 2% capture rate)
- Country breakdowns with growth rates
- Source citations and methodology notes

**ARTIFACT 2: COMPETITIVE LANDSCAPE MATRIX** 
*Comprehensive analysis including:*
- 8 major competitors with detailed profiles
- Feature comparison matrix (40+ capabilities)
- Pricing analysis and positioning map
- Competitive strengths/weaknesses assessment
- Market share estimates and growth trends

**ARTIFACT 3: GO-TO-MARKET STRATEGY**
*90-page strategy document covering:*
- Phase 1: Market entry (Months 1-6)
- Phase 2: Scale operations (Months 7-12)  
- Phase 3: Market leadership (Months 13-18)
- Channel strategy and partner ecosystem
- Customer acquisition playbook

**ARTIFACT 4: FINANCIAL PROJECTIONS MODEL**
*Complete 5-year financial model:*
- Monthly cash flow for first 24 months
- Unit economics by market segment
- Scenario analysis (base, optimistic, pessimistic)
- ROI calculations and payback period
- Break-even analysis by market

**[Additional 6 artifacts with similar detail level...]**

**EXECUTIVE SUMMARY DASHBOARD**
*One-page visual summary showing:*
- Investment required: $25M over 18 months
- Revenue potential: $100M by year 3 (achievable)
- Break-even: Month 22
- ROI: 285% by year 5
- Key risks and mitigation strategies
- Go/No-go recommendation with rationale`,impact:"Provides board-ready analysis package that would typically require 3 months of consulting work and cost $250K+"}},{id:"data-architecture",title:"400K Context: Massive Dataset Analysis",description:"Process enormous datasets that would crash traditional systems",icon:m.Z,color:"from-indigo-500 to-purple-500",complexity:"Expert",timeToValue:"45 minutes",businessValue:"Big Data Insights",demo:{scenario:"Analyze 5 years of customer data to predict churn and optimize retention",prompt:`I'm uploading our complete customer dataset (400K records, 5 years of data):

DATASET INCLUDES:
- Customer demographics (age, company size, industry, location)
- Usage patterns (login frequency, feature usage, support tickets)
- Financial data (subscription value, payment history, upgrades/downgrades)
- Engagement metrics (email opens, webinar attendance, community participation)
- Support interactions (ticket volume, satisfaction scores, resolution time)
- Contract details (start date, renewal history, cancellation data)

ANALYSIS REQUIRED:
1. Churn prediction model with accuracy metrics
2. Customer lifetime value segmentation  
3. Retention strategy recommendations by segment
4. Product usage patterns that indicate risk
5. Optimal intervention timing and methods
6. ROI projections for retention investments

DELIVERABLES:
- Executive dashboard showing key insights
- Predictive model with risk scoring
- Segmented retention playbooks
- Implementation roadmap with priorities
- Success metrics and monitoring plan

Process the entire dataset and provide comprehensive analysis that our data science team has been working on for 6 months.`,expectedOutput:`**DATASET PROCESSING COMPLETE**
*Successfully analyzed 400,000 customer records across 847 variables*

**KEY INSIGHTS DISCOVERED:**
1. **Churn Prediction Model (91.3% accuracy)**
   - Primary indicators: 40% usage drop + missed renewal call
   - Secondary signals: Support ticket surge + feature usage decline
   - Early warning: 73 days average before actual churn

2. **Customer Segmentation Analysis**
   - Champions (15%): High value, high engagement, 2% churn rate
   - Loyalists (35%): Steady usage, 8% churn rate  
   - At-Risk (25%): Declining engagement, 34% churn rate
   - Lost Cause (25%): Minimal usage, 67% churn rate

3. **Retention Strategy by Segment**
   - Champions: VIP program, beta access, advisory board
   - Loyalists: Upsell opportunities, success stories, referrals
   - At-Risk: Proactive outreach, usage optimization, training
   - Lost Cause: Win-back campaigns, pricing incentives

**PREDICTIVE MODEL OUTPUT:**
- 2,847 customers at high churn risk (next 90 days)
- Retention investment ROI: $4.2M potential save vs $800K cost
- Optimal intervention: 45-60 days before predicted churn
- Success probability: 68% retention with targeted intervention

**EXECUTIVE DASHBOARD:**
*Visual summary showing segment health, churn trends, intervention opportunities, and projected ROI from retention initiatives*`,impact:"Processes 5 years of data in minutes vs. months, providing insights that typically require dedicated data science team"}}];function y(){let[e,t]=(0,a.useState)("parallel-reasoning"),[i,n]=(0,a.useState)(!1),r=x.find(t=>t.id===e);return s.jsx("div",{className:"min-h-screen",style:{backgroundColor:"#0A2044"},children:(0,s.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-12",children:[s.jsx(g.default,{}),(0,s.jsxs)("div",{className:"text-center mb-12",children:[s.jsx("h1",{className:"text-5xl font-bold text-white mb-4",children:"WOW Demonstration Gallery"}),s.jsx("p",{className:"text-xl text-gray-300",children:"Experience GPT-5's most powerful capabilities in action"})]}),(0,s.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-4 gap-8",children:[(0,s.jsxs)("div",{className:"lg:col-span-1",children:[s.jsx("h3",{className:"text-xl font-semibold text-white mb-4",children:"Choose Demo"}),s.jsx("div",{className:"space-y-3",children:x.map(i=>{let a=i.icon;return s.jsx("button",{onClick:()=>t(i.id),className:`w-full text-left p-4 rounded-lg transition-all ${e===i.id?`bg-gradient-to-r ${i.color} text-white shadow-lg transform scale-105`:"bg-white/10 text-gray-300 hover:bg-white/15"}`,children:(0,s.jsxs)("div",{className:"flex items-start space-x-3",children:[s.jsx(a,{className:"h-6 w-6 mt-1 flex-shrink-0"}),(0,s.jsxs)("div",{children:[s.jsx("div",{className:"font-semibold text-sm",children:i.title}),s.jsx("div",{className:"text-xs opacity-90 mt-1",children:i.description}),(0,s.jsxs)("div",{className:"flex items-center space-x-2 mt-2",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-white/20 rounded",children:i.complexity}),s.jsx("span",{className:"text-xs px-2 py-1 bg-white/20 rounded",children:i.timeToValue})]})]})]})},i.id)})})]}),s.jsx("div",{className:"lg:col-span-3",children:(0,s.jsxs)("div",{className:"bg-white/5 rounded-lg p-8",children:[s.jsx("div",{className:"flex items-start justify-between mb-8",children:(0,s.jsxs)("div",{className:"flex items-start space-x-4",children:[s.jsx("div",{className:`p-4 rounded-lg bg-gradient-to-r ${r.color}`,children:s.jsx(r.icon,{className:"h-8 w-8 text-white"})}),(0,s.jsxs)("div",{children:[s.jsx("h2",{className:"text-3xl font-bold text-white mb-2",children:r.title}),s.jsx("p",{className:"text-gray-400 text-lg mb-4",children:r.description}),(0,s.jsxs)("div",{className:"flex items-center space-x-6",children:[(0,s.jsxs)("div",{className:"flex items-center space-x-2",children:[s.jsx(o.Z,{className:"h-4 w-4 text-yellow-400"}),(0,s.jsxs)("span",{className:"text-sm text-gray-300",children:["Complexity: ",r.complexity]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-2",children:[s.jsx(d.Z,{className:"h-4 w-4 text-green-400"}),(0,s.jsxs)("span",{className:"text-sm text-gray-300",children:["Time to Value: ",r.timeToValue]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-2",children:[s.jsx(m.Z,{className:"h-4 w-4 text-blue-400"}),(0,s.jsxs)("span",{className:"text-sm text-gray-300",children:["Business Value: ",r.businessValue]})]})]})]})]})}),s.jsx("div",{className:"mb-8",children:(0,s.jsxs)("div",{className:"bg-orange-900/20 border border-orange-500/30 rounded-lg p-6",children:[(0,s.jsxs)("div",{className:"flex items-center space-x-2 mb-3",children:[s.jsx(p.Z,{className:"h-5 w-5 text-orange-400"}),s.jsx("h3",{className:"text-xl font-semibold text-orange-300",children:"Demo Scenario"})]}),s.jsx("p",{className:"text-gray-200 text-lg",children:r.demo.scenario})]})}),(0,s.jsxs)("div",{className:"mb-8",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[s.jsx("h3",{className:"text-xl font-semibold text-white",children:"GPT-5 Prompt"}),(0,s.jsxs)("button",{onClick:()=>n(!i),className:"flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/15 rounded-lg transition-colors",children:[(0,s.jsxs)("span",{className:"text-gray-300",children:[i?"Collapse":"Expand"," Prompt"]}),s.jsx(u,{className:`h-4 w-4 text-gray-300 transition-transform ${i?"rotate-90":""}`})]})]}),s.jsx("div",{className:"bg-gray-900/50 rounded-lg border border-gray-700",children:s.jsx("div",{className:"p-4",children:s.jsx("pre",{className:`text-gray-200 text-sm whitespace-pre-wrap font-mono ${i?"":"line-clamp-6"}`,children:r.demo.prompt})})})]}),(0,s.jsxs)("div",{className:"mb-8",children:[s.jsx("h3",{className:"text-xl font-semibold text-teal-300 mb-4",children:"Expected GPT-5 Output"}),s.jsx("div",{className:"bg-teal-900/10 border border-teal-500/30 rounded-lg p-6",children:s.jsx("pre",{className:"text-gray-200 text-sm whitespace-pre-wrap",children:r.demo.expectedOutput})})]}),s.jsx("div",{className:"bg-green-900/20 border border-green-500/30 rounded-lg p-6",children:(0,s.jsxs)("div",{className:"flex items-start space-x-3",children:[s.jsx(h.Z,{className:"h-6 w-6 text-green-400 mt-1"}),(0,s.jsxs)("div",{children:[s.jsx("h4",{className:"text-lg font-semibold text-green-300 mb-2",children:"Business Impact"}),s.jsx("p",{className:"text-green-100",children:r.demo.impact})]})]})})]})})]}),s.jsx("div",{className:"text-center mt-16 pt-8 border-t border-gray-700",children:s.jsx("p",{className:"text-xs text-gray-400",children:"\xa9 2025 Growth Partner Pros. All Rights Reserved."})})]})})}},27849:(e,t,i)=>{"use strict";i.d(t,{default:()=>c});var s=i(62901),a=i(84700),n=i(24383),r=i(62392),o=i(44928),l=i(67935);function c(){let{data:e,status:t}=(0,a.useSession)()||{},[i,c]=(0,n.useState)(!1);if(!i||"loading"===t||!e)return null;let d=e.user?.role==="admin";return(0,s.jsxs)("div",{className:"flex justify-between items-center mb-6 p-4 bg-white/5 rounded-lg",children:[(0,s.jsxs)("div",{children:[(0,s.jsxs)("p",{className:"text-white",children:["Welcome, ",e.user?.name||e.user?.email]}),s.jsx("p",{className:"text-gray-400 text-sm",children:"GPT-5 Executive Mastery Course"}),d&&(0,s.jsxs)("div",{className:"flex items-center space-x-1 mt-1",children:[s.jsx(o.Z,{className:"h-3 w-3 text-orange-400"}),s.jsx("span",{className:"text-orange-400 text-xs",children:"Administrator"})]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-3",children:[d&&(0,s.jsxs)(r.default,{href:"/admin",className:"flex items-center space-x-2 px-3 py-2 text-sm text-orange-300 hover:text-orange-200 border border-orange-600 hover:border-orange-400 rounded-lg transition-colors",children:[s.jsx(l.Z,{className:"h-4 w-4"}),s.jsx("span",{children:"Admin Panel"})]}),s.jsx("button",{onClick:()=>(0,a.signOut)(),className:"px-4 py-2 text-sm text-gray-300 hover:text-white border border-gray-600 hover:border-gray-400 rounded-lg transition-colors",children:"Sign Out"})]})]})}},49358:(e,t,i)=>{"use strict";i.d(t,{KeyboardNavigation:()=>a}),i(24383);var s=i(84374);function a(){return(0,s.useRouter)(),(0,s.useSearchParams)(),null}},56444:(e,t,i)=>{"use strict";i.d(t,{default:()=>r});var s=i(62901),a=i(84700),n=i(24383);function r({children:e}){let[t,i]=(0,n.useState)(!1);return t?s.jsx(a.SessionProvider,{children:e}):s.jsx("div",{className:"min-h-screen flex items-center justify-center",style:{backgroundColor:"#0A2044"},children:s.jsx("div",{className:"text-white",children:"Loading..."})})}},71945:(e,t,i)=>{"use strict";i.d(t,{Z:()=>l});var s=i(24383);let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((e,t,i)=>!!e&&i.indexOf(e)===t).join(" ");var r={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let o=(0,s.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:i=2,absoluteStrokeWidth:a,className:o="",children:l,iconNode:c,...d},m)=>(0,s.createElement)("svg",{ref:m,...r,width:t,height:t,stroke:e,strokeWidth:a?24*Number(i)/Number(t):i,className:n("lucide",o),...d},[...c.map(([e,t])=>(0,s.createElement)(e,t)),...Array.isArray(l)?l:[l]])),l=(e,t)=>{let i=(0,s.forwardRef)(({className:i,...r},l)=>(0,s.createElement)(o,{ref:l,iconNode:t,className:n(`lucide-${a(e)}`,i),...r}));return i.displayName=`${e}`,i}},33901:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("ChartColumn",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]])},64483:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},49568:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]])},27328:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]])},67935:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},44928:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]])},87552:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]])},82063:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]])},62392:(e,t,i)=>{"use strict";i.d(t,{default:()=>a.a});var s=i(95003),a=i.n(s)},14785:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>m,metadata:()=>d});var s=i(83537),a=i(57416),n=i.n(a);i(26148);var r=i(88895);let o=(0,r.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/keyboard-navigation.tsx#KeyboardNavigation`);var l=i(3995);let c=(0,r.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/providers.tsx#default`),d={title:"GPT-5 Executive Mastery Course - Growth Partner Pros",description:"Professional executive-level course for mastering GPT-5 advanced capabilities and business applications"};function m({children:e}){return s.jsx("html",{lang:"en",children:s.jsx("body",{className:`${n().className} text-white min-h-screen`,style:{backgroundColor:"#0A2044"},children:(0,s.jsxs)(c,{children:[s.jsx(l.Suspense,{fallback:null,children:s.jsx(o,{})}),e]})})})}},87296:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>s});let s=(0,i(88895).createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/app/wow-demos/page.tsx#default`)},26148:()=>{}};var t=require("../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),s=t.X(0,[4372,9056,5003],()=>i(64967));module.exports=s})();