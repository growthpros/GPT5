(()=>{var e={};e.id=1820,e.ids=[1820],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},43402:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>r.a,__next_app__:()=>m,originalPathname:()=>p,pages:()=>d,routeModule:()=>u,tree:()=>c}),i(38106),i(14785),i(71363);var s=i(36576),a=i(72007),n=i(21818),r=i.n(n),o=i(88897),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let c=["",{children:["prompt-templates",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,38106)),"/home/ubuntu/gpt5_course_platform/app/app/prompt-templates/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,14785)),"/home/ubuntu/gpt5_course_platform/app/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,71363,23)),"next/dist/client/components/not-found-error"]}],d=["/home/ubuntu/gpt5_course_platform/app/app/prompt-templates/page.tsx"],p="/prompt-templates/page",m={require:i,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/prompt-templates/page",pathname:"/prompt-templates",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},51746:(e,t,i)=>{Promise.resolve().then(i.bind(i,58597))},33647:(e,t,i)=>{Promise.resolve().then(i.bind(i,49358)),Promise.resolve().then(i.bind(i,56444))},87133:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,84114,23)),Promise.resolve().then(i.t.bind(i,28866,23)),Promise.resolve().then(i.t.bind(i,31324,23)),Promise.resolve().then(i.t.bind(i,83567,23)),Promise.resolve().then(i.t.bind(i,55996,23)),Promise.resolve().then(i.t.bind(i,10050,23))},58597:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>v});var s=i(62901),a=i(24383),n=i(32317),r=i(82063),o=i(64483),l=i(87552),c=i(66843),d=i(67935),p=i(71945);let m=(0,p.Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]),u=(0,p.Z)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);var h=i(27849);let g=[{id:"specification-driven",title:"Specification-Driven Prompting",icon:n.Z,color:"from-blue-500 to-indigo-500",description:"Six-element framework for precise, professional results",templates:[{name:"Complete 6-Element Template",description:"Master template with all six specification elements",prompt:`[OBJECTIVE]: [Clearly state what you want to achieve]

[SCOPE]: [Define boundaries, what's included/excluded]

[DELIVERABLE]: [Specify exact format and content of output]

[CONSTRAINTS]: [List limitations, requirements, restrictions]

[CONTEXT]: [Provide background information and relevant details]

[SUCCESS CRITERIA]: [Define how to measure successful completion]

[YOUR SPECIFIC REQUEST HERE]`},{name:"Business Strategy Template",description:"Specification framework optimized for strategic planning",prompt:`OBJECTIVE: Develop comprehensive business strategy for [SITUATION]
SCOPE: [Time horizon], [Market segments], [Business units]
DELIVERABLE: Strategic plan document with executive summary, detailed strategy, financial projections, implementation roadmap
CONSTRAINTS: Budget of $[AMOUNT], timeline of [TIMEFRAME], regulatory requirements, competitive landscape
CONTEXT: [Company background], [Market conditions], [Current challenges], [Available resources]
SUCCESS CRITERIA: [Specific metrics], [Approval criteria], [Implementation milestones]

Analyze the situation and provide the complete strategic plan.`},{name:"Problem-Solving Template",description:"Systematic approach to complex business problems",prompt:`OBJECTIVE: Solve [SPECIFIC PROBLEM] and provide actionable solution
SCOPE: [Affected departments/processes], [Impact boundaries], [Stakeholder groups]
DELIVERABLE: Problem analysis, root cause identification, solution recommendations with implementation steps
CONSTRAINTS: [Time limitations], [Budget constraints], [Resource availability], [Organizational limitations]
CONTEXT: [Problem background], [Previous attempts], [Current impact], [Stakeholder perspectives]
SUCCESS CRITERIA: [Problem resolution metrics], [Success indicators], [Acceptance criteria]

Provide comprehensive problem analysis and solution strategy.`}]},{id:"think-hard",title:'"Think Hard" Activation',description:"Unlock GPT-5's deepest reasoning for complex challenges",icon:r.Z,color:"from-yellow-500 to-orange-500",templates:[{name:"Crisis Management Template",description:"For urgent, high-stakes business situations",prompt:`Think hard about this critical situation:

CRISIS: [Describe the urgent situation]
IMPACT: [Business/financial/operational impact]
TIMELINE: [How much time to resolve]
STAKEHOLDERS: [Who is affected/involved]
CONSTRAINTS: [Limitations and restrictions]
RISKS: [Potential consequences if not handled well]

I need comprehensive crisis management strategy including:
1. Immediate actions (next 24-48 hours)
2. Short-term stabilization plan
3. Long-term recovery strategy
4. Communication plan for stakeholders
5. Risk mitigation measures
6. Lessons learned and prevention

This is mission-critical - provide your most thorough analysis.`},{name:"Strategic Decision Template",description:"For complex decisions requiring deep analysis",prompt:`Think hard about this strategic decision:

DECISION: [What needs to be decided]
OPTIONS: [Available alternatives]
STAKES: [What's at risk/what can be gained]
TIMEFRAME: [Decision timeline]
STAKEHOLDERS: [Who is impacted by the decision]
UNKNOWNS: [Key uncertainties and information gaps]

Provide comprehensive analysis including:
- Thorough evaluation of each option
- Risk/benefit analysis with probabilities
- Scenario planning for different outcomes
- Stakeholder impact assessment
- Implementation considerations
- Recommendation with detailed reasoning

This decision will shape our future - give me your deepest insights.`},{name:"Innovation Challenge Template",description:"For breakthrough thinking and creative solutions",prompt:`Think hard about this innovation challenge:

CHALLENGE: [Innovation problem or opportunity]
CURRENT STATE: [What exists today]
DESIRED OUTCOME: [What success looks like]
CONSTRAINTS: [Technical, financial, market limitations]
PRECEDENTS: [What others have tried]
RESOURCES: [Available capabilities and assets]

I need breakthrough thinking that goes beyond conventional approaches:
1. Challenge fundamental assumptions
2. Explore unconventional solutions
3. Identify breakthrough opportunities
4. Consider system-level changes
5. Propose novel approaches
6. Assess feasibility and impact

Push the boundaries of conventional thinking - what's truly possible?`}]},{id:"canvas-integration",title:"Canvas + Memory Integration",description:"Build persistent, evolving knowledge systems",icon:o.Z,color:"from-green-500 to-teal-500",templates:[{name:"Knowledge Base Creation",description:"Create persistent knowledge systems that grow over time",prompt:`Create a Canvas document for [KNOWLEDGE DOMAIN]:

TITLE: [Descriptive title for the knowledge base]
PURPOSE: [What this knowledge base will accomplish]
SCOPE: [What topics/areas it will cover]
UPDATE FREQUENCY: [How often it should be refreshed]

Please create sections for:
1. [Section 1 - Key concepts and definitions]
2. [Section 2 - Current state analysis]
3. [Section 3 - Trends and developments]
4. [Section 4 - Best practices and lessons learned]
5. [Section 5 - Action items and next steps]
6. [Section 6 - Resources and references]

MEMORY INTEGRATION:
- Use Memory to recall related discussions from previous sessions
- Update this Canvas whenever new relevant information is shared
- Make this a living document that evolves with new insights
- Include confidence levels and source attribution

Initialize with: [Starting information or recent developments]`},{name:"Project Management Canvas",description:"Persistent project tracking and evolution",prompt:`Create a Canvas for project: "[PROJECT NAME]"

PROJECT OVERVIEW:
- Objective: [Project goals]
- Timeline: [Start and end dates]
- Budget: [Financial constraints]
- Stakeholders: [Key people involved]

Canvas Sections:
1. Project Charter & Objectives
2. Current Status & Progress
3. Key Milestones & Timeline
4. Risk Register & Mitigation
5. Resource Allocation & Budget
6. Stakeholder Communication
7. Lessons Learned & Adaptations
8. Next Actions & Decisions

MEMORY INSTRUCTIONS:
- Remember all project discussions and decisions
- Update status automatically based on our conversations
- Track changes and evolution over time
- Alert me to potential issues based on historical patterns

Start with current project status: [Current situation]`}]},{id:"artifact-driven",title:"Artifact-Driven Prompting",description:"Demand tangible deliverables with proof of work",icon:l.Z,color:"from-purple-500 to-pink-500",templates:[{name:"Comprehensive Analysis Template",description:"Request complete analysis with multiple deliverables",prompt:`I need comprehensive analysis on [TOPIC] with complete artifacts:

ANALYSIS SCOPE: [What needs to be analyzed]
BUSINESS CONTEXT: [Why this analysis is needed]
TIMELINE: [When results are needed]
AUDIENCE: [Who will use these results]

REQUIRED ARTIFACTS:
1. Executive Summary (2-page overview)
2. Detailed Analysis Report (15-20 pages)
3. Data Visualization Dashboard
4. Financial Impact Model (Excel/spreadsheet)
5. Risk Assessment Matrix
6. Implementation Roadmap
7. Success Metrics Framework
8. Stakeholder Communication Plan
9. Resource Requirements Summary
10. Appendices with supporting data

Each artifact must be:
- Immediately usable and professional quality
- Data-driven with sources and methodology
- Executive-presentation ready
- Customizable for different scenarios
- Include confidence levels and assumptions

Provide complete, actionable deliverables that demonstrate thorough analysis.`},{name:"Strategic Planning Artifacts",description:"Complete strategic planning deliverable package",prompt:`Create comprehensive strategic planning package for [INITIATIVE]:

STRATEGIC CONTEXT: [Business situation and opportunity]
PLANNING HORIZON: [Time period being planned]
INVESTMENT LEVEL: [Available resources]
SUCCESS DEFINITION: [What victory looks like]

DELIVERABLE ARTIFACTS:
1. Strategic Vision & Mission Statement
2. Market Analysis & Competitive Landscape
3. SWOT Analysis with Strategic Implications  
4. Strategic Objectives & Key Results (OKRs)
5. Initiative Portfolio & Prioritization
6. Resource Allocation & Budget Plan
7. Implementation Timeline with Milestones
8. Risk Management & Contingency Plans
9. Performance Metrics & KPI Dashboard
10. Communication & Change Management Plan

QUALITY STANDARDS:
- Board-presentation ready
- Actionable with specific next steps
- Quantified wherever possible
- Risk-assessed with mitigation strategies
- Aligned with organizational capabilities

Deliver complete strategic planning suite that can be immediately implemented.`}]},{id:"business-roles",title:"Business Role Templates",description:"Specialized prompts for different business functions",icon:c.Z,color:"from-indigo-500 to-purple-500",templates:[{name:"Marketing Executive Template",description:"Strategic marketing analysis and planning",prompt:`As a seasoned Marketing Executive, analyze [MARKETING CHALLENGE]:

MARKET CONTEXT: [Industry, competitive landscape, customer segments]
BUSINESS GOALS: [Revenue targets, growth objectives, brand goals]
CURRENT SITUATION: [Marketing performance, channels, team capabilities]
CONSTRAINTS: [Budget limitations, timeline, regulatory requirements]

Provide executive-level marketing strategy including:
1. Market opportunity assessment with TAM/SAM/SOM
2. Customer segmentation and persona development
3. Competitive positioning and differentiation strategy
4. Multi-channel marketing mix with budget allocation
5. Customer acquisition and retention strategies
6. Brand positioning and messaging framework
7. Marketing technology stack recommendations
8. Performance metrics and ROI measurement
9. Team structure and capability requirements
10. Implementation roadmap with quick wins

Focus on strategies that drive measurable business growth and competitive advantage.`},{name:"Sales Leader Template",description:"Sales strategy and performance optimization",prompt:`As an experienced Sales Leader, develop strategy for [SALES CHALLENGE]:

SALES CONTEXT: [Market size, deal types, sales cycle, competition]
PERFORMANCE GAPS: [Current vs. target performance, specific issues]
TEAM SITUATION: [Sales team size, experience, territories, tools]
BUSINESS PRESSURE: [Revenue targets, timeline, stakeholder expectations]

Provide comprehensive sales strategy covering:
1. Sales process optimization and methodology
2. Territory planning and coverage model
3. Lead generation and pipeline development
4. Sales enablement and training programs
5. Compensation and incentive structure
6. Sales technology and CRM optimization
7. Performance management and coaching
8. Competitive positioning and battle cards
9. Customer success and expansion strategies
10. Sales forecasting and pipeline management

Emphasize strategies that accelerate revenue growth and improve win rates.`},{name:"Operations Executive Template",description:"Operational efficiency and process optimization",prompt:`As a senior Operations Executive, optimize [OPERATIONAL CHALLENGE]:

OPERATIONAL CONTEXT: [Current processes, systems, team structure, performance metrics]
EFFICIENCY GAPS: [Where operations are falling short, bottlenecks, waste areas]
RESOURCE CONSTRAINTS: [Budget, staffing, technology, time limitations]
BUSINESS IMPACT: [How operational issues affect business performance]

Develop comprehensive operational strategy including:
1. Process mapping and optimization opportunities
2. Technology and automation recommendations
3. Resource allocation and capacity planning
4. Quality management and continuous improvement
5. Supply chain and vendor management optimization
6. Performance metrics and KPI framework
7. Change management and team development
8. Risk management and business continuity
9. Cost optimization and efficiency gains
10. Scaling strategies for growth

Focus on solutions that improve efficiency, reduce costs, and enable scalable growth.`}]},{id:"advanced-techniques",title:"Advanced GPT-5 Techniques",description:"Cutting-edge prompting strategies for power users",icon:d.Z,color:"from-red-500 to-orange-500",templates:[{name:"Multi-Perspective Analysis",description:"Get multiple expert viewpoints simultaneously",prompt:`I need multiple expert perspectives on [COMPLEX ISSUE]:

SITUATION: [Describe the complex situation or decision]
STAKEHOLDERS: [Who is affected or involved]
IMPLICATIONS: [Why this matters and potential impacts]
CONSTRAINTS: [Limitations and requirements]

Please provide analysis from these expert perspectives:
1. [Expert Type 1] - Focus on [their primary concerns]
2. [Expert Type 2] - Focus on [their primary concerns]  
3. [Expert Type 3] - Focus on [their primary concerns]
4. [Expert Type 4] - Focus on [their primary concerns]
5. [Expert Type 5] - Focus on [their primary concerns]

For each perspective, provide:
- Their primary concerns and priorities
- Their analysis of the situation
- Their recommended approach
- Risks they would highlight
- Success metrics they would use

Conclude with synthesis of insights and integrated recommendations.`},{name:"Scenario Planning Template",description:"Comprehensive future scenario analysis",prompt:`Develop scenario planning analysis for [STRATEGIC SITUATION]:

BASE CASE ASSUMPTIONS: [Current trajectory and likely outcomes]
KEY UNCERTAINTIES: [Major variables that could change]
TIME HORIZON: [Planning period]
DECISION CONTEXT: [What decisions this will inform]

Create four scenarios:

SCENARIO 1: Optimistic Case
- Key assumptions: [Best-case variables]
- Probability: [Estimated likelihood]
- Implications: [What this means for business]
- Strategic responses: [How to capitalize]

SCENARIO 2: Pessimistic Case  
- Key assumptions: [Worst-case variables]
- Probability: [Estimated likelihood]
- Implications: [Risks and challenges]
- Strategic responses: [How to mitigate]

SCENARIO 3: Wild Card Case
- Key assumptions: [Unexpected disruptions]
- Probability: [Estimated likelihood] 
- Implications: [Game-changing impacts]
- Strategic responses: [How to adapt]

SCENARIO 4: Status Quo Plus
- Key assumptions: [Incremental changes]
- Probability: [Estimated likelihood]
- Implications: [Gradual evolution]
- Strategic responses: [How to stay competitive]

Provide strategic recommendations that work across multiple scenarios.`}]}];function v(){let[e,t]=(0,a.useState)("specification-driven"),[i,n]=(0,a.useState)(0),[r,o]=(0,a.useState)(null),c=g.find(t=>t.id===e),d=c.templates[i],p=(e,t)=>{navigator.clipboard.writeText(e),o(t),setTimeout(()=>o(null),2e3)};return s.jsx("div",{className:"min-h-screen",style:{backgroundColor:"#0A2044"},children:(0,s.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-12",children:[s.jsx(h.default,{}),(0,s.jsxs)("div",{className:"text-center mb-12",children:[s.jsx("h1",{className:"text-5xl font-bold text-white mb-4",children:"Universal Prompt Templates"}),s.jsx("p",{className:"text-xl text-gray-300",children:"Master GPT-5 with proven prompt frameworks and templates"})]}),(0,s.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-4 gap-8",children:[(0,s.jsxs)("div",{className:"lg:col-span-1",children:[s.jsx("h3",{className:"text-xl font-semibold text-white mb-4",children:"Template Categories"}),s.jsx("div",{className:"space-y-2",children:g.map(i=>{let a=i.icon;return s.jsx("button",{onClick:()=>{t(i.id),n(0)},className:`w-full text-left p-4 rounded-lg transition-all ${e===i.id?`bg-gradient-to-r ${i.color} text-white shadow-lg`:"bg-white/10 text-gray-300 hover:bg-white/15"}`,children:(0,s.jsxs)("div",{className:"flex items-start space-x-3",children:[s.jsx(a,{className:"h-6 w-6 mt-1 flex-shrink-0"}),(0,s.jsxs)("div",{children:[s.jsx("div",{className:"font-semibold text-sm",children:i.title}),s.jsx("div",{className:"text-xs opacity-90 mt-1",children:i.description})]})]})},i.id)})})]}),s.jsx("div",{className:"lg:col-span-3",children:(0,s.jsxs)("div",{className:"bg-white/5 rounded-lg p-6",children:[(0,s.jsxs)("div",{className:"flex items-center space-x-3 mb-6",children:[s.jsx("div",{className:`p-3 rounded-lg bg-gradient-to-r ${c.color}`,children:s.jsx(c.icon,{className:"h-6 w-6 text-white"})}),(0,s.jsxs)("div",{children:[s.jsx("h2",{className:"text-2xl font-bold text-white",children:c.title}),s.jsx("p",{className:"text-gray-400",children:c.description})]})]}),s.jsx("div",{className:"flex flex-wrap gap-2 mb-6",children:c.templates.map((e,t)=>s.jsx("button",{onClick:()=>n(t),className:`px-4 py-2 rounded-lg font-medium transition-all ${i===t?"bg-orange-500 text-white":"bg-white/10 text-gray-300 hover:bg-white/15"}`,children:e.name},t))}),(0,s.jsxs)("div",{className:"space-y-6",children:[(0,s.jsxs)("div",{children:[(0,s.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[s.jsx("h3",{className:"text-xl font-semibold text-white",children:d.name}),(0,s.jsxs)("button",{onClick:()=>p(d.prompt,d.name),className:"flex items-center space-x-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors",children:[r===d.name?s.jsx(m,{className:"h-4 w-4 text-white"}):s.jsx(u,{className:"h-4 w-4 text-white"}),s.jsx("span",{className:"text-white text-sm",children:r===d.name?"Copied!":"Copy Template"})]})]}),s.jsx("p",{className:"text-gray-300 mb-4",children:d.description})]}),(0,s.jsxs)("div",{children:[s.jsx("h4",{className:"text-lg font-semibold text-orange-300 mb-3",children:"Template"}),s.jsx("div",{className:"bg-gray-900/50 rounded-lg p-4 border border-gray-700",children:s.jsx("pre",{className:"text-gray-200 text-sm whitespace-pre-wrap font-mono",children:d.prompt})})]}),s.jsx("div",{className:"bg-blue-900/20 border border-blue-500/30 rounded-lg p-4",children:(0,s.jsxs)("div",{className:"flex items-start space-x-3",children:[s.jsx(l.Z,{className:"h-5 w-5 text-blue-400 mt-1"}),(0,s.jsxs)("div",{children:[s.jsx("div",{className:"font-semibold text-blue-300 mb-1",children:"Usage Tips"}),(0,s.jsxs)("div",{className:"text-blue-200 text-sm",children:["specification-driven"===e&&"Replace bracketed placeholders with your specific requirements. The six-element structure ensures comprehensive, professional results.","think-hard"===e&&'Use for complex, high-stakes situations requiring deep analysis. The "Think hard" activation unlocks GPT-5\'s most sophisticated reasoning.',"canvas-integration"===e&&"These templates create persistent documents that evolve over time. Perfect for ongoing projects and knowledge management.","artifact-driven"===e&&"Demand specific deliverables and proof of work. Results in comprehensive analysis packages ready for executive presentation.","business-roles"===e&&"Tailored for specific business functions. Use the role-specific lens to get targeted, actionable recommendations.","advanced-techniques"===e&&"Power user techniques for complex analysis. Combine multiple approaches for comprehensive strategic insights."]})]})]})})]})]})})]}),s.jsx("div",{className:"text-center mt-16 pt-8 border-t border-gray-700",children:s.jsx("p",{className:"text-xs text-gray-400",children:"\xa9 2025 Growth Partner Pros. All Rights Reserved."})})]})})}},27849:(e,t,i)=>{"use strict";i.d(t,{default:()=>c});var s=i(62901),a=i(84700),n=i(24383),r=i(62392),o=i(44928),l=i(67935);function c(){let{data:e,status:t}=(0,a.useSession)()||{},[i,c]=(0,n.useState)(!1);if(!i||"loading"===t||!e)return null;let d=e.user?.role==="admin";return(0,s.jsxs)("div",{className:"flex justify-between items-center mb-6 p-4 bg-white/5 rounded-lg",children:[(0,s.jsxs)("div",{children:[(0,s.jsxs)("p",{className:"text-white",children:["Welcome, ",e.user?.name||e.user?.email]}),s.jsx("p",{className:"text-gray-400 text-sm",children:"GPT-5 Executive Mastery Course"}),d&&(0,s.jsxs)("div",{className:"flex items-center space-x-1 mt-1",children:[s.jsx(o.Z,{className:"h-3 w-3 text-orange-400"}),s.jsx("span",{className:"text-orange-400 text-xs",children:"Administrator"})]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-3",children:[d&&(0,s.jsxs)(r.default,{href:"/admin",className:"flex items-center space-x-2 px-3 py-2 text-sm text-orange-300 hover:text-orange-200 border border-orange-600 hover:border-orange-400 rounded-lg transition-colors",children:[s.jsx(l.Z,{className:"h-4 w-4"}),s.jsx("span",{children:"Admin Panel"})]}),s.jsx("button",{onClick:()=>(0,a.signOut)(),className:"px-4 py-2 text-sm text-gray-300 hover:text-white border border-gray-600 hover:border-gray-400 rounded-lg transition-colors",children:"Sign Out"})]})]})}},49358:(e,t,i)=>{"use strict";i.d(t,{KeyboardNavigation:()=>a}),i(24383);var s=i(84374);function a(){return(0,s.useRouter)(),(0,s.useSearchParams)(),null}},56444:(e,t,i)=>{"use strict";i.d(t,{default:()=>r});var s=i(62901),a=i(84700),n=i(24383);function r({children:e}){let[t,i]=(0,n.useState)(!1);return t?s.jsx(a.SessionProvider,{children:e}):s.jsx("div",{className:"min-h-screen flex items-center justify-center",style:{backgroundColor:"#0A2044"},children:s.jsx("div",{className:"text-white",children:"Loading..."})})}},71945:(e,t,i)=>{"use strict";i.d(t,{Z:()=>l});var s=i(24383);let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((e,t,i)=>!!e&&i.indexOf(e)===t).join(" ");var r={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let o=(0,s.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:i=2,absoluteStrokeWidth:a,className:o="",children:l,iconNode:c,...d},p)=>(0,s.createElement)("svg",{ref:p,...r,width:t,height:t,stroke:e,strokeWidth:a?24*Number(i)/Number(t):i,className:n("lucide",o),...d},[...c.map(([e,t])=>(0,s.createElement)(e,t)),...Array.isArray(l)?l:[l]])),l=(e,t)=>{let i=(0,s.forwardRef)(({className:i,...r},l)=>(0,s.createElement)(o,{ref:l,iconNode:t,className:n(`lucide-${a(e)}`,i),...r}));return i.displayName=`${e}`,i}},64483:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},32317:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},67935:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},44928:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]])},87552:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]])},66843:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},82063:(e,t,i)=>{"use strict";i.d(t,{Z:()=>s});let s=(0,i(71945).Z)("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]])},62392:(e,t,i)=>{"use strict";i.d(t,{default:()=>a.a});var s=i(95003),a=i.n(s)},14785:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>p,metadata:()=>d});var s=i(83537),a=i(57416),n=i.n(a);i(26148);var r=i(88895);let o=(0,r.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/keyboard-navigation.tsx#KeyboardNavigation`);var l=i(3995);let c=(0,r.createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/components/providers.tsx#default`),d={title:"GPT-5 Executive Mastery Course - Growth Partner Pros",description:"Professional executive-level course for mastering GPT-5 advanced capabilities and business applications"};function p({children:e}){return s.jsx("html",{lang:"en",children:s.jsx("body",{className:`${n().className} text-white min-h-screen`,style:{backgroundColor:"#0A2044"},children:(0,s.jsxs)(c,{children:[s.jsx(l.Suspense,{fallback:null,children:s.jsx(o,{})}),e]})})})}},38106:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>s});let s=(0,i(88895).createProxy)(String.raw`/home/ubuntu/gpt5_course_platform/app/app/prompt-templates/page.tsx#default`)},26148:()=>{}};var t=require("../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),s=t.X(0,[4372,9056,5003],()=>i(43402));module.exports=s})();